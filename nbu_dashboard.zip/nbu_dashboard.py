"""
NBU Backup CTS Dashboard — REDESIGN v3.0 (clean rewrite, all fixes applied)
"""

import json, sqlite3, logging
from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import dash
import tinyllama_engine as _tl
from dash import dcc, html, dash_table, Input, Output, State, ctx, ALL
import dash_bootstrap_components as dbc

# ══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════
DB_UNIFIED  = "/usr/nbu-cts-v2/db/nbu_unified.db"
DB_MEDIA    = "/usr/nbu-cts-v2/db/nbu_unified.db"  # media_metrics_unified is in same DB
DB_LAG      = "/usr/nbu-cts/db/duplication_lag.db"
DB_DISKPOOL = "/usr/nbu-cts/db/diskpool.db"
DB_3RDSITE  = "/usr/nbu-cts/db/thirdsite.db"
DB_CATALOG  = "/usr/nbu-cts/db/catalog_backup_health.db"
DB_AIRGAP   = "/usr/nbu-cts/db/airgap_slp.db"
SLA_THRESH  = 100
BRAND       = "#1a3c5e"
SSL_CERT    = "/usr/nbu-cts-v2/ssl/cert.pem"
SSL_KEY     = "/usr/nbu-cts-v2/ssl/key.pem"
PORT        = 8060

QUICK_QUERIES = [
    ("📊", "Fleet health overview — all servers"),
    ("📉", "Which servers have a duplication queue breach today?"),
    ("📉", "Show duplication queue history for india servers"),
    ("💽", "Show top 10 storage pools by capacity usage"),
    ("💽", "Which storage pools are critical today?"),
    ("🌐", "Summarise External Airgap Vault dedup efficiency per server"),
    ("🌐", "Which servers have immutable retention below 30 days?"),
    ("📋", "Show catalog backup health for all servers"),
    ("📋", "Which servers have delayed catalog backups?"),
    ("🔒", "Show Internal Airgap Vault replication status for all servers"),
    ("🔒", "Which servers have a vault retention breach?"),
    ("🖥️", "Show full report for cpcinp1cbkms"),
    ("🤖", "Show all anomalies detected in the last 7 days"),
    ("📧", "Generate daily fleet digest"),
]



# ── Contextual query suggestions by intent ────────────────────────────────────
INTENT_SUGGESTIONS = {
    "lag": [
        ("📉", "Show duplication queue history for india servers last 7 days"),
        ("📉", "Which servers have queue breach today?"),
        ("📉", "Compare lag for india servers last 14 days"),
        ("📉", "Show duplication queue for cpcinp1cbkms last 7 days"),
        ("📉", "Show lag trend for all servers this month"),
        ("📉", "Which server has the highest queue depth?"),
    ],
    "diskpool": [
        ("💽", "Show storage pool history for cpcinp1cbkms last 14 days"),
        ("💽", "Which storage pools are critical today?"),
        ("💽", "Show top 10 storage pools by capacity usage"),
        ("💽", "Compare storage pool usage for india servers"),
        ("💽", "Which servers have storage pools above 85%?"),
    ],
    "3rdsite": [
        ("🌐", "Show external airgap vault for cpcinp1cbkms last month"),
        ("🌐", "Which servers have immutable retention below 30 days?"),
        ("🌐", "Summarise external airgap dedup efficiency per server"),
        ("🌐", "Compare external vault WORM days for india servers"),
        ("🌐", "Show external airgap vault history for all prod servers"),
    ],
    "catalog": [
        ("📋", "Show catalog health for india servers last 7 days"),
        ("📋", "Which servers have delayed catalog backups?"),
        ("📋", "Show catalog health history for cpcinp1cbkms last 14 days"),
        ("📋", "Which servers have catalog anomalies?"),
        ("📋", "Show backup health index for all servers"),
    ],
    "airgap": [
        ("🔒", "Show internal airgap vault for cpcinp1cbkms last 7 days"),
        ("🔒", "Which servers have vault retention breach?"),
        ("🔒", "Show vault retention compliance for india servers"),
        ("🔒", "Compare internal airgap vault status for all servers"),
        ("🔒", "Show airgap backlog trend last 14 days"),
    ],
    "server_full": [
        ("🖥️", "Why is cpcinp1cbkms critical?"),
        ("📉", "Show lag for cpcinp1cbkms last 7 days"),
        ("💽", "Show storage pools for cpcinp1cbkms last 14 days"),
        ("📋", "Show catalog health for cpcinp1cbkms last 7 days"),
        ("🔒", "Show internal airgap vault for cpcinp1cbkms last 7 days"),
    ],
    "temporal": [
        ("📊", "Compare lag for india servers last 14 days"),
        ("📊", "Show fleet health overview"),
        ("📉", "Show duplication queue for all prod servers last 7 days"),
        ("💽", "Show storage pool history for cpcinp1cbkms last 14 days"),
        ("🔒", "Show internal airgap vault history last 7 days"),
    ],
    "fleet": [
        ("📊", "Which servers are critical today?"),
        ("📉", "Show duplication queue for india servers"),
        ("💽", "Which storage pools are near full?"),
        ("📋", "Show catalog backup health for all servers"),
        ("🔒", "Show vault retention compliance summary"),
    ],
}
INTENT_SUGGESTIONS["rag_fallback"] = INTENT_SUGGESTIONS["fleet"]
INTENT_SUGGESTIONS["digest"]       = INTENT_SUGGESTIONS["fleet"]

# ══════════════════════════════════════════════════════════════════════════════
# LOGGING
# ══════════════════════════════════════════════════════════════════════════════
from logging.handlers import TimedRotatingFileHandler
LOG_DIR = Path("/usr/nbu-cts/logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)
log_fmt = logging.Formatter('%(asctime)s [%(levelname)-8s] %(name)s: %(message)s', '%Y-%m-%d %H:%M:%S')
fh = TimedRotatingFileHandler(LOG_DIR/"dashboard.log", when='midnight', backupCount=30, encoding='utf-8')
fh.setFormatter(log_fmt); fh.setLevel(logging.INFO); fh.suffix = "%Y-%m-%d"
ch = logging.StreamHandler(); ch.setFormatter(log_fmt); ch.setLevel(logging.INFO)
logging.basicConfig(level=logging.INFO, handlers=[fh, ch])
logger = logging.getLogger("nbu_dashboard")

# Chat persistence
# Phase 3 — Export and email
try:
    from nbu_report_mailer import (
        get_tab_csv, build_tab_html, send_tab_report,
        send_daily_digest,
    )
    _MAILER_LOADED = True
except Exception as _me:
    _MAILER_LOADED = False
    import logging as _log
    _log.getLogger("nbu_dashboard").warning(f"Mailer not loaded: {_me}")

# Phase 2 — Intelligence modules
try:
    from narrative_engine import (
        lag_narrative, lag_temporal_narrative,
        diskpool_narrative, ext_vault_narrative,
        int_vault_narrative, catalog_narrative,
        fleet_narrative, cross_report_rca,
        no_data_response, daily_digest_narrative,
    )
    from vaultix_agent import (
        resolve_server as _resolve_server,
        get_full_server_data, build_server_narrative,
        temporal_answer as _temporal_answer,
        rank_servers_by, compare_servers,
        SERVER_ALIASES,
    )
    _INTELLIGENCE_LOADED = True
except Exception as _ie:
    _INTELLIGENCE_LOADED = False
    import logging as _log
    _log.getLogger("nbu_dashboard").warning(f"Intelligence modules not loaded: {_ie}")

try:
    from nbu_unified_db import save_chat_message as _save_chat
except Exception:
    _save_chat = None
logger.info("NBU-CTS Dashboard v3.0 — logging initialized")

# ══════════════════════════════════════════════════════════════════════════════
# DATABASE HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def qdf(db, sql, params=()):
    try:
        con = sqlite3.connect(db)
        df  = pd.read_sql_query(sql, con, params=params)
        con.close()
        return df
    except Exception as e:
        logger.error(f"qdf [{Path(db).name}]: {e}")
        return pd.DataFrame()

def scalar(db, sql, params=()):
    try:
        con = sqlite3.connect(db); v = con.execute(sql, params).fetchone(); con.close()
        return v[0] if v else None
    except Exception as e:
        logger.error(f"scalar: {e}"); return None

def qrow(db, sql, params=()):
    try:
        con = sqlite3.connect(db); con.row_factory = sqlite3.Row
        row = con.execute(sql, params).fetchone(); con.close()
        return dict(row) if row else None
    except Exception as e:
        logger.error(f"qrow: {e}"); return None

# ══════════════════════════════════════════════════════════════════════════════
# DESIGN HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _status_color(status):
    s = str(status).upper()
    if s in ("CRITICAL","ERROR","QUEUE BREACH","VAULT BREACH","FAILED","LOW"): return "danger"
    if s in ("WARNING","NEAR LIMIT","DELAYED","MODERATE","WORKING"):       return "warning"
    if s in ("SUCCESS","OK","HEALTHY","COMPLETED","GOOD"):               return "success"
    return "secondary"

def _pct_color(pct):
    if pct >= 85: return "#E24B4A"
    if pct >= 70: return "#EF9F27"
    return "#639922"

def _lag_color(val):
    if val > SLA_THRESH:       return "#E24B4A"
    if val > SLA_THRESH * 0.8: return "#EF9F27"
    return "#639922"

def pill(text, color=None):
    color = color or _status_color(text)
    cmap = {
        "danger":    ("#fff0f0","#c0392b"),
        "warning":   ("#fff8ec","#b7770d"),
        "success":   ("#f0faf0","#2d7a2d"),
        "info":      ("#e8f0fe","#1a3c5e"),
        "secondary": ("#f4f4f4","#555"),
    }
    bg, fg = cmap.get(color, cmap["secondary"])
    return html.Span(text, style={
        "background": bg, "color": fg,
        "padding": "2px 8px", "borderRadius": "8px",
        "fontSize": "10px", "fontWeight": "500",
        "whiteSpace": "nowrap", "display": "inline-block"
    })

def mini_bar(pct, width=52):
    color = _pct_color(pct)
    return html.Div([
        html.Div(style={
            "width": f"{width}px", "height": "5px",
            "background": "#e0e0e0", "borderRadius": "3px", "overflow": "hidden",
            "display": "inline-block", "verticalAlign": "middle", "marginRight": "5px"
        }, children=[html.Div(style={
            "width": f"{min(pct,100)}%", "height": "100%",
            "background": color, "borderRadius": "3px"
        })]),
        html.Span(f"{pct:.1f}%", style={"fontSize": "10px", "fontWeight": "500", "color": color})
    ], style={"display": "flex", "alignItems": "center"})

def kpi_card(label, value, accent=BRAND, sub=""):
    return html.Div([
        html.Div(label, style={"fontSize":"10px","color":"#888","marginBottom":"4px"}),
        html.Div(str(value), style={"fontSize":"20px","fontWeight":"500","color":accent,"lineHeight":"1"}),
        html.Div(sub, style={"fontSize":"10px","color":"#888","marginTop":"3px"}) if sub else html.Span()
    ], style={"background":"#f7f8fa","borderRadius":"8px","padding":"10px 13px","borderLeft":f"3px solid {accent}"})

def date_banner(label, value, extra=""):
    try:
        icon = "🟢" if str(value)[:10] == datetime.now().strftime("%Y-%m-%d") else "🔵"
        bg, fg = "#e8f0fe", "#1a3c5e"
    except:
        icon, bg, fg = "⚠️", "#fff8ec", "#b7770d"
    return html.Div([
        html.Span(icon, style={"marginRight":"6px"}),
        html.Strong(f"{label}: "),
        html.Span(str(value)[:19] if value else "No data"),
        html.Span(f"  {extra}", style={"fontSize":"10px","color":"#888","marginLeft":"8px"}) if extra else html.Span()
    ], style={"background":bg,"color":fg,"borderRadius":"6px","padding":"6px 12px",
              "fontSize":"11px","marginBottom":"14px","display":"flex","alignItems":"center"})

def rich_table(headers, rows):
    th_style = {"padding":"5px 10px","fontSize":"9px","color":"#888",
                "borderBottom":"0.5px solid #e0e0e0","fontWeight":"400",
                "textTransform":"uppercase","letterSpacing":"0.5px","textAlign":"left"}
    def td_style(bg=None):
        s = {"padding":"6px 10px","fontSize":"10px","borderBottom":"0.5px solid #e8e8e8","verticalAlign":"middle"}
        if bg: s["background"] = bg
        return s
    def row_bg(row):
        if isinstance(row, tuple) and len(row)==3 and row[0]=="_color":
            return row[1], row[2]
        return None, row
    head = html.Tr([html.Th(h, style=th_style) for h in headers])
    body_rows = []
    for row in rows:
        bg, cells = row_bg(row)
        body_rows.append(html.Tr([html.Td(c, style=td_style(bg)) for c in cells]))
    return html.Div(html.Table([html.Thead(head), html.Tbody(body_rows)],
        style={"width":"100%","borderCollapse":"collapse"}),
        style={"overflowX":"auto","borderRadius":"8px","border":"0.5px solid #e0e0e0","marginTop":"8px"})

def resp_header(icon, title, sub=""):
    return html.Div([
        html.Span(icon, style={"fontSize":"13px","marginRight":"7px"}),
        html.Span(title, style={"fontSize":"12px","fontWeight":"500"}),
        html.Span(sub, style={"fontSize":"10px","color":"#888","marginLeft":"auto"}) if sub else html.Span()
    ], style={"display":"flex","alignItems":"center","marginBottom":"10px"})

def resp_kpis(items):
    cards = []
    for label, value, color in items:
        cards.append(html.Div([
            html.Div(label, style={"fontSize":"9px","color":"#888"}),
            html.Div(str(value), style={"fontSize":"16px","fontWeight":"500","color":color,"marginTop":"2px"})
        ], style={"background":"#f7f8fa","borderRadius":"6px","padding":"7px 10px","flex":"1"}))
    return html.Div(cards, style={"display":"flex","gap":"8px","marginBottom":"10px"})

# ══════════════════════════════════════════════════════════════════════════════
# TAB 0: HOME
# ══════════════════════════════════════════════════════════════════════════════
def _fleet_timeline_iframe(avail_dates, selected, lag_total, rv_total, rv_pct, cat_ok, total_srv):
    """Executive timeline date selector for fleet overview."""
    import json as _json, sqlite3 as _sq

    # Get per-date KPIs for tooltip
    try:
        con = _sq.connect(DB_UNIFIED)
        date_kpis = {}
        for d in avail_dates[:60]:
            lag = con.execute(
                "SELECT COALESCE(SUM(total),0) FROM lag_history WHERE date=?", (d,)
            ).fetchone()[0]
            vault = con.execute(
                "SELECT ROUND(COALESCE(SUM(used_tb),0),1) FROM diskpool_daily WHERE diskpool_group='Recovery Vault' AND run_date=?",
                (d,)
            ).fetchone()[0]
            cats = con.execute(
                """SELECT COUNT(*) FROM (
                    SELECT server_id, catalog_status FROM catalog_health c1
                    WHERE checked_at=(SELECT MAX(checked_at) FROM catalog_health
                                      WHERE server_id=c1.server_id AND checked_at<=? || ' 23:59:59')
                ) WHERE catalog_status='ERROR'""",
                (d,)
            ).fetchone()[0]
            date_kpis[d] = {"lag":int(lag or 0),"vault":float(vault or 0),"cat_err":int(cats or 0)}
        con.close()
    except:
        date_kpis = {}

    dates_js = _json.dumps([{
        "d": d,
        "lag": date_kpis.get(d,{}).get("lag",0),
        "vault": date_kpis.get(d,{}).get("vault",0),
        "cat_err": date_kpis.get(d,{}).get("cat_err",0),
        "breach": date_kpis.get(d,{}).get("vault",0) > 773.5,
        "selected": d == selected,
    } for d in avail_dates[:60]])

    cjs = (Path("/usr/nbu-cts-v2/assets/chart.umd.js")
           .read_text() if Path("/usr/nbu-cts-v2/assets/chart.umd.js").exists() else "")

    html_src = """<!DOCTYPE html><html><head>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,sans-serif;}
body{background:transparent;padding:0;}
.wrap{padding:4px 2px 8px;}
.lbl{font-size:10px;text-transform:uppercase;letter-spacing:0.6px;color:#64748b;margin-bottom:8px;font-weight:500;}
.tl-row{display:flex;align-items:center;gap:0;overflow-x:auto;padding-bottom:2px;scrollbar-width:none;}
.tl-row::-webkit-scrollbar{display:none;}
.seg{flex:1;height:1px;background:#e2e8f0;min-width:6px;max-width:24px;}
.dot-wrap{display:flex;flex-direction:column;align-items:center;cursor:pointer;padding:0 1px;}
.dot{width:9px;height:9px;border-radius:50%;background:#e2e8f0;transition:all 0.15s;flex-shrink:0;}
.dlbl{font-size:9px;color:#94a3b8;margin-top:4px;white-space:nowrap;}
.dot-wrap:hover .dot{transform:scale(1.5);}
.dot-wrap.sel .dot{background:#185FA5;width:13px;height:13px;border:2.5px solid #E6F1FB;box-shadow:0 0 0 3px #185FA520;}
.dot-wrap.sel .dlbl{color:#185FA5;font-weight:700;font-size:10px;}
.dot-wrap.breach .dot{background:#E24B4A;}
.dot-wrap.breach .dlbl{color:#A32D2D;}
.dot-wrap.warn .dot{background:#EF9F27;}
.dot-wrap.latest .dot{background:#639922;}
.dot-wrap.latest .dlbl{color:#3B6D11;}
.nav{width:26px;height:26px;border-radius:50%;border:0.5px solid #e2e8f0;background:#fff;
     cursor:pointer;font-size:13px;color:#64748b;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.nav:hover{background:#f0f4fa;color:#185FA5;}
.card{background:#f8fafc;border:0.5px solid #e2e8f0;border-radius:10px;padding:10px 14px;
      margin-top:10px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;}
.kpis{display:flex;gap:20px;flex-wrap:wrap;}
.kpi-v{font-size:17px;font-weight:500;line-height:1;}
.kpi-l{font-size:10px;color:#64748b;margin-top:2px;}
.tag{font-size:9px;padding:2px 7px;border-radius:4px;font-weight:500;display:inline-block;margin-left:6px;}
</style>
</head><body>
<div class="wrap">
  <div class="lbl">Fleet data snapshot — select date</div>
  <div style="display:flex;align-items:center;gap:6px;">
    <button class="nav" onclick="pg(-1)">&#8249;</button>
    <div class="tl-row" id="tl"></div>
    <button class="nav" onclick="pg(1)">&#8250;</button>
  </div>
  <div class="card" id="info-card">
    <div>
      <div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:#64748b;margin-bottom:3px;">Selected</div>
      <div style="font-size:15px;font-weight:500;color:#1e3a5f;" id="sel-d">—</div>
      <div style="font-size:11px;color:#64748b;margin-top:2px;" id="sel-sub">—</div>
    </div>
    <div class="kpis">
      <div><div class="kpi-v" id="kv-lag" style="color:#E24B4A;">—</div><div class="kpi-l">Dup queue</div></div>
      <div><div class="kpi-v" id="kv-vault" style="color:#185FA5;">—</div><div class="kpi-l">Vault used</div></div>
      <div><div class="kpi-v" id="kv-cat" style="color:#3B6D11;">—</div><div class="kpi-l">Catalog errors</div></div>
    </div>
  </div>
</div>
<script>
var DATA=""" + dates_js + """;
var PAGE=7, offset=0;
var selIdx=0;
for(var i=0;i<DATA.length;i++){if(DATA[i].selected){selIdx=i;break;}}

function fmt(d){
  var dt=new Date(d+"T00:00:00");
  var M=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return dt.getDate()+" "+M[dt.getMonth()];
}
function fmtFull(d){
  var dt=new Date(d+"T00:00:00");
  var M=["January","February","March","April","May","June",
         "July","August","September","October","November","December"];
  return dt.getDate()+" "+M[dt.getMonth()]+" "+dt.getFullYear();
}

function render(){
  var tl=document.getElementById("tl");
  tl.innerHTML="";
  var slice=DATA.slice(offset,offset+PAGE);
  slice.forEach(function(item,i){
    if(i>0){var s=document.createElement("div");s.className="seg";tl.appendChild(s);}
    var w=document.createElement("div");
    var cls="dot-wrap"+(DATA.indexOf(item)===selIdx?" sel":"")+(item.breach?" breach":item.vault>600?" warn":"")+(i===0&&offset===0?" latest":"");
    w.className=cls;
    w.innerHTML='<div class="dot"></div><div class="dlbl">'+fmt(item.d)+'</div>';
    w.onclick=(function(it,idx){return function(){selectDate(it,idx);};})(item,DATA.indexOf(item));
    tl.appendChild(w);
  });
  updateCard(DATA[selIdx]);
}

function selectDate(item,idx){
  selIdx=idx;
  render();
  // Notify parent Dash app via postMessage
  window.parent.postMessage({type:"fleet_date",date:item.d},"*");
}

function updateCard(item){
  if(!item)return;
  document.getElementById("sel-d").textContent=fmtFull(item.d);
  var sub=item.breach?"⚠ Vault above 85% on this date":
          (selIdx===0?"Today · latest snapshot":"Historical snapshot");
  document.getElementById("sel-sub").textContent=sub;
  document.getElementById("kv-lag").textContent=(item.lag||0).toLocaleString();
  document.getElementById("kv-lag").style.color=item.lag>10000?"#E24B4A":item.lag>1000?"#854F0B":"#3B6D11";
  document.getElementById("kv-vault").textContent=(item.vault||0)+" TB";
  document.getElementById("kv-vault").style.color=item.breach?"#E24B4A":item.vault>600?"#854F0B":"#185FA5";
  document.getElementById("kv-cat").textContent=item.cat_err||0;
  document.getElementById("kv-cat").style.color=item.cat_err>0?"#E24B4A":"#3B6D11";
}

function pg(dir){
  offset=Math.max(0,Math.min(DATA.length-PAGE,offset+dir*PAGE));
  render();
}
render();
</script>
<script>
function resizeIframe() {
  var h = document.body.scrollHeight;
  window.parent.document.getElementById("media-iframe").style.height = (h + 20) + "px";
}
window.addEventListener("load", resizeIframe);
window.addEventListener("resize", resizeIframe);
// Also resize after filter
var origFilter = window.filter;
window.filter = function(state, btn) {
  origFilter(state, btn);
  setTimeout(resizeIframe, 50);
};
</script>
</body></html>"""

    return html.Div([
        html.Iframe(
            srcDoc=html_src,
            style={"width":"100%","border":"none","height":"155px"},
            id="fleet-timeline-iframe",
        ),
    ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px",
              "background":"#fff","marginBottom":"12px","overflow":"hidden"})


def tab_home(selected_date=None):
    """Fleet Overview — Executive dashboard."""
    import sqlite3 as _sq
    from datetime import date as _date, timedelta as _td

    try:
        con = _sq.connect(DB_UNIFIED)

        # Available dates + selected date
        avail_dates = [r[0] for r in con.execute(
            "SELECT DISTINCT date FROM lag_history ORDER BY date DESC LIMIT 90"
        ).fetchall()]
        use_date = selected_date if selected_date and selected_date in avail_dates                    else (avail_dates[0] if avail_dates else None)

        # Fleet server data — date-aware query
        servers = con.execute("""
            WITH lag_d AS (
                SELECT s.id as sid, s.name, s.country, s.platform,
                       COALESCE(lh.total,0) as lag_total,
                       COALESCE(lh.above_sla,0) as lag_above_sla
                FROM servers s
                LEFT JOIN lag_history lh ON lh.server_id=s.id AND lh.date=?
            ),
            dp_d AS (
                SELECT server_id,
                       SUM(CASE WHEN health='CRITICAL' THEN 1 ELSE 0 END) as critical_pools,
                       SUM(CASE WHEN health='WARNING'  THEN 1 ELSE 0 END) as warning_pools,
                       COUNT(*) as total_pools
                FROM diskpool_daily
                WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily WHERE run_date<=?)
                GROUP BY server_id
            ),
            ts_d AS (
                SELECT ts1.server_id,
                       COALESCE(ROUND(ts1.total_data_tb,2),0) as ts_total_tb,
                       COALESCE(ROUND(ts1.avg_dedup_percent,1),0) as ts_dedup_pct,
                       COALESCE(ts1.max_worm_days,0) as ts_worm_days
                FROM thirdsite_summary ts1
                WHERE ts1.report_date=(
                    SELECT MAX(report_date) FROM thirdsite_summary
                    WHERE server_id=ts1.server_id AND report_date<=?)
            ),
            cat_d AS (
                SELECT c1.server_id,
                       c1.catalog_status as cat_status,
                       COALESCE(ROUND(c1.health_score,1),0) as cat_health_score
                FROM catalog_health c1
                WHERE c1.checked_at=(
                    SELECT MAX(checked_at) FROM catalog_health
                    WHERE server_id=c1.server_id AND checked_at<=? || ' 23:59:59')
            ),
            ag_d AS (
                SELECT a1.server_id,
                       a1.status as ag_status,
                       COALESCE(a1.replication_active,0) as ag_repl_active
                FROM airgap_replication a1
                WHERE a1.checked_at=(
                    SELECT MAX(checked_at) FROM airgap_replication
                    WHERE server_id=a1.server_id AND checked_at<=? || ' 23:59:59')
            )
            SELECT l.name, l.country, l.platform,
                   l.lag_total, l.lag_above_sla,
                   COALESCE(d.critical_pools,0),
                   COALESCE(d.warning_pools,0),
                   COALESCE(d.total_pools,0),
                   COALESCE(t.ts_total_tb,0),
                   COALESCE(t.ts_dedup_pct,0),
                   COALESCE(t.ts_worm_days,0),
                   COALESCE(c.cat_status,'—'),
                   COALESCE(c.cat_health_score,0),
                   COALESCE(a.ag_status,'—'),
                   COALESCE(a.ag_repl_active,0),
                   0
            FROM lag_d l
            LEFT JOIN dp_d  d ON d.server_id=l.sid
            LEFT JOIN ts_d  t ON t.server_id=l.sid
            LEFT JOIN cat_d c ON c.server_id=l.sid
            LEFT JOIN ag_d  a ON a.server_id=l.sid
            ORDER BY l.lag_total DESC
        """, (use_date, use_date, use_date, use_date, use_date)).fetchall()

        # Media server summary per master
        media = con.execute("""
            SELECT master_name,
                   COUNT(*) as total,
                   SUM(CASE WHEN ai_status='HIGH_LOAD' THEN 1 ELSE 0 END) as hl,
                   SUM(CASE WHEN ai_status='ANOMALY'   THEN 1 ELSE 0 END) as an,
                   SUM(backup_jobs) as bj,
                   ROUND(SUM(data_tb),1) as dtb
            FROM media_metrics_unified m1
            WHERE timestamp=(SELECT MAX(m2.timestamp)
                             FROM media_metrics_unified m2
                             WHERE m2.media_server=m1.media_server)
            GROUP BY master_name ORDER BY hl DESC, an DESC
        """).fetchall()

        # Backup jobs latest
        bj_latest = con.execute("""
            SELECT MAX(report_date), SUM(total_jobs),
                   SUM(success_jobs), SUM(failed_jobs),
                   ROUND(AVG(CASE WHEN total_jobs>0 THEN success_rate END),1)
            FROM backup_jobs_summary
            WHERE report_date=(SELECT MAX(report_date) FROM backup_jobs_summary
                               WHERE report_date IN (
                                   SELECT DISTINCT report_date FROM backup_jobs_summary
                                   WHERE total_jobs > 0
                               ))
        """).fetchone()

        # Recovery vault
        rv_latest = con.execute(
            "SELECT MAX(run_date) FROM diskpool_daily WHERE diskpool_group='Recovery Vault'"
        ).fetchone()[0] or '—'
        rv_total = con.execute(
            "SELECT ROUND(SUM(used_tb),1) FROM diskpool_daily WHERE diskpool_group='Recovery Vault' AND run_date=?",
            (rv_latest,)
        ).fetchone()[0] or 0
        rv_days_over = con.execute("""
            SELECT COUNT(*) FROM (
                SELECT SUM(used_tb) as v FROM diskpool_daily
                WHERE diskpool_group='Recovery Vault' GROUP BY run_date
            ) WHERE v>910
        """).fetchone()[0]

        # Diskpool fleet
        dp_fleet = con.execute("""
            SELECT COUNT(*),
                   SUM(CASE WHEN status='Down'        THEN 1 ELSE 0 END),
                   SUM(CASE WHEN health='CRITICAL'    THEN 1 ELSE 0 END),
                   SUM(CASE WHEN health='WARNING'     THEN 1 ELSE 0 END)
            FROM diskpool_daily
            WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily)
        """).fetchone()

        # Lag trend (14 days)
        trend = con.execute("""
            SELECT date, SUM(total) FROM lag_history
            GROUP BY date ORDER BY date DESC LIMIT 14
        """).fetchall()

        con.close()
    except Exception as e:
        return html.Div(f"Fleet data unavailable: {e}",
                        style={"padding":"24px","color":"#E24B4A"})

    # ── Computed fleet stats ───────────────────────────────────────────────
    # Column order: 0:server_name 1:country 2:platform 3:lag_total
    # 4:lag_above_sla 5:critical_pools 6:warning_pools 7:total_pools
    # 8:ts_total_tb 9:ts_dedup_pct 10:ts_worm_days 11:cat_status
    # 12:cat_health_score 13:ag_status 14:ag_repl_active 15:ag_weekly_ok
    total        = len(servers)
    lag_total_v  = sum(int(r[3] or 0) for r in servers)
    above_sla    = sum(1 for r in servers if int(r[3] or 0) > 100)  # servers with >100 images in queue
    cat_errors   = sum(1 for r in servers if r[11] == "ERROR")
    cat_ok       = total - cat_errors
    ag_down      = sum(1 for r in servers if r[13] in ("Not Working",""))
    ts_total_tb  = round(sum(float(r[8] or 0) for r in servers), 1)
    ms_total     = sum(r[1] for r in media)
    ms_hl        = sum(r[2] for r in media)
    ms_an        = sum(r[3] for r in media)
    dp_total, dp_down, dp_crit, dp_warn = dp_fleet
    rv_pct       = round(rv_total/910*100, 1) if rv_total else 0
    LICENSE      = 910.0
    THRESHOLD    = 910.0 * 0.85

    # Next Saturday
    today = _date.today()
    days_to_sat = (5 - today.weekday()) % 7 or 7
    next_sat = today + _td(days=days_to_sat)
    next_sat_str = next_sat.strftime("Sat %d %b")

    # Colors
    s_rv  = "#A32D2D" if rv_total>LICENSE else "#854F0B" if rv_total>THRESHOLD else "#185FA5"

    def _b(txt, cls):
        colors = {
            "ok":   ("#f0fdf4","#3B6D11"),
            "warn": ("#FAEEDA","#854F0B"),
            "err":  ("#FCEBEB","#A32D2D"),
            "info": ("#E6F1FB","#185FA5"),
            "nt":   ("#f8fafc","#64748b"),
        }
        bg, fg = colors.get(cls, ("#f8fafc","#64748b"))
        return html.Span(txt, style={
            "fontSize":"10px","padding":"2px 7px","borderRadius":"4px",
            "fontWeight":"500","background":bg,"color":fg,
            "display":"inline-block","whiteSpace":"nowrap"
        })

    def _kpi(label, val, sub, color="#1e3a5f", left_color=None):
        style = {"background":"#f8fafc","borderRadius":"8px","padding":"11px 12px"}
        if left_color:
            style["borderLeft"] = f"3px solid {left_color}"
            style["borderRadius"] = "0 8px 8px 0"
        return html.Div([
            html.Div(label, style={"fontSize":"10px","textTransform":"uppercase",
                                   "letterSpacing":"0.5px","color":"#64748b","marginBottom":"4px"}),
            html.Div(str(val), style={"fontSize":"21px","fontWeight":"500",
                                       "lineHeight":"1","color":color}),
            html.Div(sub, style={"fontSize":"11px","color":"#64748b","marginTop":"3px"}),
        ], style=style)

    def _srv_status(r):
        """Determine overall server status. r: (srv,country,platform,lag,above_sla,crit,warn,pools,ts_tb,dedup,worm,cat_st,cat_score,ag_st,ag_active,ag_wk)"""
        if r[11] == "ERROR": return _b("ERROR","err")
        if int(r[5] or 0) > 0: return _b("CRIT","err")
        if r[13] == "Not Working": return _b("WATCH","warn")
        if int(r[6] or 0) > 0: return _b("WATCH","warn")
        if int(r[3] or 0) > 5000: return _b("WATCH","warn")
        return _b("OK","ok")

    def _row_bg(r):
        if r[11] == "ERROR" or int(r[5] or 0) > 0: return "#FCEBEB"
        if r[13] == "Not Working" or int(r[3] or 0) > 5000: return "#FAEEDA"
        return "#fff"

    def _bar(pct, color="#185FA5"):
        w = min(100, max(0, pct))
        return html.Div(html.Div(style={"width":f"{w}%","height":"100%",
                                         "background":color,"borderRadius":"2px"}),
                        style={"width":"100%","height":"5px","background":"#e2e8f0",
                               "borderRadius":"2px","overflow":"hidden","marginTop":"3px"})

    def _action(severity, title, sub):
        c = "#E24B4A" if severity=="err" else "#EF9F27"
        bg = "#FCEBEB" if severity=="err" else "#FAEEDA"
        tc = "#A32D2D" if severity=="err" else "#854F0B"
        return html.Div([
            html.Div(title, style={"fontSize":"11px","fontWeight":"500",
                                    "color":tc}),
            html.Div(sub, style={"fontSize":"10px","color":"#64748b","marginTop":"2px"}),
        ], style={"borderLeft":f"3px solid {c}","borderRadius":"0 6px 6px 0",
                  "padding":"7px 10px","marginBottom":"7px","background":bg})

    th = {"padding":"5px 8px","textAlign":"left","fontSize":"10px",
          "textTransform":"uppercase","letterSpacing":"0.4px","fontWeight":"500",
          "color":"#64748b","background":"#f8fafc","borderBottom":"0.5px solid #e2e8f0"}
    thr = {**th,"textAlign":"right"}
    thc = {**th,"textAlign":"center"}

    # ── KPI strip ─────────────────────────────────────────────────────────
    kpi_strip = html.Div([
        _kpi("Dup queue", f"{lag_total_v:,}", "fleet total images",
             "#A32D2D" if lag_total_v>10000 else "#854F0B" if lag_total_v>1000 else "#3B6D11",
             left_color="#E24B4A" if lag_total_v>10000 else None),
        _kpi("Above SLA", above_sla, "servers >100 images",
             "#A32D2D" if above_sla>0 else "#3B6D11"),
        _kpi("Media servers", ms_total, f"{ms_hl} high-load · {ms_an} anomaly",
             "#854F0B" if ms_hl>0 or ms_an>5 else "#1e3a5f"),
        _kpi("Storage pools", dp_total or 0, f"{dp_crit or 0} critical · {dp_down or 0} down",
             "#A32D2D" if (dp_crit or 0)>0 else "#854F0B" if (dp_warn or 0)>0 else "#1e3a5f"),
        _kpi("Recovery vault", f"{rv_total} TB", f"{rv_pct}% of 910 TB",
             s_rv, left_color="#185FA5"),
        _kpi("Catalog", f"{cat_ok}/{total}", f"{cat_errors} error",
             "#A32D2D" if cat_errors>0 else "#3B6D11"),
        _kpi("3rd-site vault", f"{ts_total_tb} TB",
             f"{int(scalar(DB_UNIFIED, 'SELECT COALESCE(SUM(dup_not_started),0) FROM thirdsite_summary WHERE report_date=(SELECT MAX(report_date) FROM thirdsite_summary)') or 0):,} pending images",
             "#854F0B" if int(scalar(DB_UNIFIED, 'SELECT COALESCE(SUM(dup_not_started),0) FROM thirdsite_summary WHERE report_date=(SELECT MAX(report_date) FROM thirdsite_summary)') or 0)>0 else "#185FA5"),
        _kpi("Airgap", f"{ag_down} down" if ag_down>0 else "All active",
             f"{ag_down} server(s) not working",
             "#A32D2D" if ag_down>0 else "#3B6D11"),
    ], style={"display":"grid","gridTemplateColumns":"repeat(auto-fit,minmax(110px,1fr))",
              "gap":"8px","marginBottom":"12px"})

    # ── Vault license bar ──────────────────────────────────────────────────
    bar_pct = min(100, rv_pct)
    bar_c   = "#E24B4A" if rv_total>LICENSE else "#EF9F27" if rv_total>THRESHOLD else "#185FA5"
    vault_bar = html.Div([
        html.Div([
            html.Span("Recovery vault license",
                      style={"fontSize":"10px","textTransform":"uppercase",
                             "letterSpacing":"0.5px","color":"#64748b","fontWeight":"500"}),
            html.Span(f"{rv_total} / 910 TB · {rv_pct}% · {rv_days_over} days over license historically",
                      style={"fontSize":"11px","color":"#64748b"}),
        ], style={"display":"flex","justifyContent":"space-between","marginBottom":"5px"}),
        html.Div([
            html.Div(style={"width":f"{bar_pct}%","height":"100%",
                           "background":bar_c,"borderRadius":"3px"}),
            html.Div(style={"position":"absolute","top":"0","left":"85%",
                           "width":"1.5px","height":"100%",
                           "background":"#E24B4A","opacity":"0.8"}),
        ], style={"height":"7px","background":"#e2e8f0","borderRadius":"3px",
                  "overflow":"hidden","position":"relative"}),
        html.Div(["0",
                  html.Span("85% = 773.5 TB",style={"color":"#A32D2D"}),
                  "910 TB"],
                 style={"display":"flex","justifyContent":"space-between",
                        "fontSize":"10px","color":"#64748b","marginTop":"2px"}),
    ], style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 14px",
              "marginBottom":"12px"})

    # ── Server matrix ──────────────────────────────────────────────────────
    max_lag = max((int(r[3] or 0) for r in servers), default=1)
    srv_rows = []
    shown = 0
    for r in servers:
        srv     = r[0]
        country = r[1]
        platform= r[2]
        lag     = int(r[3] or 0)
        crit    = int(r[5] or 0)
        warn    = int(r[6] or 0)
        ts_tb   = float(r[8] or 0)
        cat_st  = r[11] or "—"
        ag_st   = r[13] or "—"
        lag_pct = min(100, lag/max(max_lag,1)*100) if max_lag>0 else 0
        lag_c = "#E24B4A" if lag>10000 else "#EF9F27" if lag>1000 else "#185FA5"
        cat_b = _b("ERROR","err") if cat_st=="ERROR" else _b("OK","ok")
        ts_b  = _b(f"{ts_tb:.0f} TB","info") if ts_tb>0 else _b("—","nt")
        dp_b  = _b("CRIT","err") if crit>0 else _b("WARN","warn") if warn>0 else _b("OK","ok")
        ag_b  = _b("DOWN","err") if ag_st=="Not Working" else                 _b("ACTIVE","ok") if ag_st in ("Working","Completed") else _b("—","nt")
        # media for this server
        ms = next((m for m in media if m[0]==srv), None)
        ms_txt = f"{ms[1]} · {ms[2]}H {ms[3]}A" if ms else "—"
        ms_c = "#A32D2D" if ms and ms[2]>0 else "#854F0B" if ms and ms[3]>3 else "#64748b"

        srv_rows.append(html.Tr([
            html.Td(srv.replace("cbkms",""),
                    style={"padding":"6px 8px","fontFamily":"monospace",
                           "fontSize":"10px","fontWeight":"500"}),
            html.Td(f"{country} · {platform}",
                    style={"padding":"6px 8px","fontSize":"10px","color":"#64748b"}),
            html.Td([
                html.Span(f"{lag:,}",
                          style={"fontWeight":"500","color":lag_c,"fontSize":"11px"}),
                _bar(lag_pct, lag_c),
            ], style={"padding":"6px 8px","textAlign":"right","width":"100px"}),
            html.Td(cat_b,  style={"padding":"6px 8px","textAlign":"center"}),
            html.Td(ts_b,   style={"padding":"6px 8px","textAlign":"center"}),
            html.Td(dp_b,   style={"padding":"6px 8px","textAlign":"center"}),
            html.Td(ag_b,   style={"padding":"6px 8px","textAlign":"center"}),
            html.Td(html.Span(ms_txt,style={"color":ms_c,"fontSize":"10px"}),
                    style={"padding":"6px 8px","textAlign":"right"}),
            html.Td(_srv_status(r), style={"padding":"6px 8px","textAlign":"center"}),
        ], style={"borderBottom":"0.5px solid #f1f5f9","background":_row_bg(r)}))
        shown += 1

    srv_matrix = html.Div([
        html.Div([
            html.Span("Server status matrix",
                      style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f"}),
            html.Span(f"sorted by dup queue · {total} servers",
                      style={"fontSize":"10px","color":"#64748b"}),
        ], style={"display":"flex","justifyContent":"space-between","alignItems":"center",
                  "padding":"10px 14px","borderBottom":"0.5px solid #e2e8f0"}),
        html.Table([
            html.Thead(html.Tr([
                html.Th("Server",style=th),html.Th("Region",style=th),
                html.Th("Dup queue",style=thr),html.Th("Catalog",style=thc),
                html.Th("3rd-site",style=thc),html.Th("Storage",style=thc),
                html.Th("Airgap",style=thc),html.Th("Media srv",style=thr),
                html.Th("Status",style=thc),
            ])),
            html.Tbody(srv_rows),
        ], style={"width":"100%","borderCollapse":"collapse"}),
    ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px",
              "overflow":"hidden","background":"#fff","marginBottom":"12px"})

    # ── Media servers ──────────────────────────────────────────────────────
    ms_rows = []
    for m in media[:8]:
        hl_c = "#A32D2D" if m[2]>0 else "#854F0B" if m[3]>3 else "#64748b"
        ms_rows.append(html.Tr([
            html.Td(m[0].replace("cbkms",""),
                    style={"padding":"5px 8px","fontFamily":"monospace","fontSize":"10px"}),
            html.Td(str(m[1]),style={"padding":"5px 8px","textAlign":"right","fontSize":"10px"}),
            html.Td(html.Span(f"{m[2]}H {m[3]}A",style={"color":hl_c,"fontWeight":"500"}),
                    style={"padding":"5px 8px","textAlign":"right","fontSize":"10px"}),
            html.Td(f"{m[5]}",style={"padding":"5px 8px","textAlign":"right",
                                      "fontSize":"10px","fontWeight":"500","color":"#185FA5"}),
        ], style={"borderBottom":"0.5px solid #f1f5f9"}))
    if len(media)>8:
        ms_rows.append(html.Tr(html.Td(f"+ {len(media)-8} more servers",
                                        colSpan=4,
                                        style={"padding":"5px 8px","textAlign":"center",
                                               "fontSize":"10px","color":"#64748b"})))

    media_panel = html.Div([
        html.Div(f"Media servers — {ms_total} total",
                 style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"10px"}),
        html.Table([
            html.Thead(html.Tr([
                html.Th("Master",style=th),html.Th("Total",style=thr),
                html.Th("H / A",style=thr),html.Th("Data TB",style=thr),
            ])),
            html.Tbody(ms_rows),
        ], style={"width":"100%","borderCollapse":"collapse",
                  "border":"0.5px solid #e2e8f0","borderRadius":"8px","overflow":"hidden"}),
        html.Div("H = High-load · A = Anomaly",
                 style={"fontSize":"10px","color":"#94a3b8","marginTop":"6px"}),
    ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px",
              "padding":"14px","background":"#fff"})

    # ── Backup jobs ────────────────────────────────────────────────────────
    bj_date, bj_total, bj_ok, bj_fail, bj_rate = bj_latest or ('—',0,0,0,0)
    bj_has_data = bj_total and bj_total > 0
    if bj_has_data:
        bj_content = html.Div([
            html.Div([
                html.Div([html.Div("Total jobs",style={"fontSize":"10px","color":"#64748b"}),
                          html.Div(str(bj_total),style={"fontSize":"18px","fontWeight":"500"})],
                         style={"background":"#f8fafc","borderRadius":"8px","padding":"8px 10px"}),
                html.Div([html.Div("Success",style={"fontSize":"10px","color":"#64748b"}),
                          html.Div(str(bj_ok),style={"fontSize":"18px","fontWeight":"500","color":"#3B6D11"})],
                         style={"background":"#f8fafc","borderRadius":"8px","padding":"8px 10px"}),
                html.Div([html.Div("Failed",style={"fontSize":"10px","color":"#64748b"}),
                          html.Div(str(bj_fail),style={"fontSize":"18px","fontWeight":"500",
                                                        "color":"#A32D2D" if bj_fail else "#64748b"})],
                         style={"background":"#f8fafc","borderRadius":"8px","padding":"8px 10px"}),
                html.Div([html.Div("Success rate",style={"fontSize":"10px","color":"#64748b"}),
                          html.Div(f"{bj_rate}%",style={"fontSize":"18px","fontWeight":"500",
                                                          "color":"#3B6D11" if (bj_rate or 0)>=95 else "#854F0B"})],
                         style={"background":"#f8fafc","borderRadius":"8px","padding":"8px 10px"}),
            ], style={"display":"grid","gridTemplateColumns":"1fr 1fr","gap":"6px"}),
            html.Div(f"Report date: {bj_date}",
                     style={"fontSize":"10px","color":"#94a3b8","marginTop":"8px"}),
        ])
    else:
        bj_content = html.Div([
            html.Div([
                html.Div("No backup jobs recorded yet today",
                         style={"fontSize":"11px","fontWeight":"500","color":"#854F0B","marginBottom":"4px"}),
                html.Div(f"Last report: {bj_date}. Jobs sync after backup window closes (typically post-midnight).",
                         style={"fontSize":"10px","color":"#64748b"}),
            ], style={"background":"#E6F1FB","borderRadius":"8px","padding":"10px 12px","marginBottom":"10px"}),
            html.Div([
                html.Div([html.Div("Schedule",style={"fontSize":"10px","color":"#64748b"}),
                          html.Div("Daily incr",style={"fontSize":"13px","fontWeight":"500","marginTop":"2px"})],
                         style={"background":"#f8fafc","borderRadius":"8px","padding":"8px 10px"}),
                html.Div([html.Div("Full backup",style={"fontSize":"10px","color":"#64748b"}),
                          html.Div("Sat 18:00",style={"fontSize":"13px","fontWeight":"500","marginTop":"2px"})],
                         style={"background":"#f8fafc","borderRadius":"8px","padding":"8px 10px"}),
                html.Div([html.Div("Next full",style={"fontSize":"10px","color":"#64748b"}),
                          html.Div(next_sat_str,style={"fontSize":"13px","fontWeight":"500",
                                                        "color":"#185FA5","marginTop":"2px"})],
                         style={"background":"#f8fafc","borderRadius":"8px","padding":"8px 10px"}),
                html.Div([html.Div("3rd-site",style={"fontSize":"10px","color":"#64748b"}),
                          html.Div("Full only",style={"fontSize":"13px","fontWeight":"500","marginTop":"2px"})],
                         style={"background":"#f8fafc","borderRadius":"8px","padding":"8px 10px"}),
            ], style={"display":"grid","gridTemplateColumns":"1fr 1fr","gap":"6px"}),
        ])

    bj_panel = html.Div([
        html.Div("Backup jobs",
                 style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"10px"}),
        bj_content,
    ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px",
              "padding":"14px","background":"#fff"})

    # ── Actions needed ─────────────────────────────────────────────────────
    actions = []
    if (dp_crit or 0) > 0:
        actions.append(_action("err","IMMEDIATE — storage pool critical",
                               f"{dp_crit} pool(s) ≥85% full · run bpexpdate to free space"))
    if cat_errors > 0:
        err_srvs = [r[0].replace("cbkms","") for r in servers if r[11]=="ERROR"]
        actions.append(_action("err",f"ERROR — catalog ({', '.join(err_srvs)})",
                               "Catalog backup ERROR · health score 0/100"))
    if rv_total > THRESHOLD:
        lbl = "BREACH" if rv_total>LICENSE else "ABOVE 85%"
        actions.append(_action("warn" if rv_total<=LICENSE else "err",
                               f"{'IMMEDIATE' if rv_total>LICENSE else 'MONITOR'} — Recovery vault {lbl}",
                               f"{rv_total}/{LICENSE:.0f} TB · {rv_days_over} days over license · watch next full backup"))
    if ag_down > 0:
        ag_srvs = [r[0].replace("cbkms","") for r in servers if r[13]=="Not Working"]
        actions.append(_action("warn",f"MONITOR — airgap not working ({', '.join(ag_srvs)})",
                               "nbstlutil failed · replication not active"))
    if ms_hl > 0 or ms_an > 5:
        top_ms = next((m for m in media if m[2]>0 or m[3]>3), None)
        if top_ms:
            actions.append(_action("warn",
                                   f"WATCH — {top_ms[0].replace('cbkms','')} media servers",
                                   f"{top_ms[2]} HIGH_LOAD · {top_ms[3]} ANOMALY detected"))
    if not actions:
        actions.append(html.Div("All systems operational",
                                style={"fontSize":"11px","color":"#3B6D11","padding":"10px",
                                       "background":"#f0fdf4","borderRadius":"6px","textAlign":"center"}))

    actions_panel = html.Div([
        html.Div("Actions needed",
                 style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"10px"}),
        html.Div(actions),
    ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px",
              "padding":"14px","background":"#fff"})

    # ── Region health ──────────────────────────────────────────────────────
    REGIONS = [
        ("India · On-Prem",  "cpcinp1/2, cpcind1/2",
         any(r[0] in ("cpcinp1cbkms","cpcinp2cbkms","cpcind1cbkms","cpcind2cbkms")
             and (r[11]=="ERROR" or int(r[5] or 0)>0) for r in servers),
         any(r[0] in ("cpcinp1cbkms","cpcinp2cbkms","cpcind1cbkms","cpcind2cbkms")
             and int(r[3] or 0)>1000 for r in servers)),
        ("Azure India",      "cazinp1cbkms",
         next((r[11]=="ERROR" for r in servers if r[0]=="cazinp1cbkms"),False),
         next((r[13]=="Not Working" for r in servers if r[0]=="cazinp1cbkms"),False)),
        ("OCI India",        "cocinp1cbkms",
         next((r[11]=="ERROR" for r in servers if r[0]=="cocinp1cbkms"),False),
         False),
        ("US",               "cazusp1, cpcusp1",
         any(r[0] in ("cazusp1cbkms","cpcusp1cbkms") and r[11]=="ERROR" for r in servers),
         False),
        ("Europe",           "cpceup1, cpcfrp1, cpcgep1",
         any(r[0] in ("cpceup1cbkms","cpcfrp1cbkms","cpcgep1cbkms") and r[11]=="ERROR" for r in servers),
         False),
        ("APAC",             "cpcphp1, cpcchp1",
         any(r[0] in ("cpcphp1cbkms","cpcchp1cbkms") and r[11]=="ERROR" for r in servers),
         False),
        ("GCP UK",           "cgcukp1cbkms",
         next((r[11]=="ERROR" for r in servers if r[0]=="cgcukp1cbkms"),False),
         False),
    ]

    def _region_card(name, subs, is_err, is_warn):
        if is_err:
            bg,bc,cls = "#FCEBEB","#E24B4A","err"
        elif is_warn:
            bg,bc,cls = "#FAEEDA","#EF9F27","warn"
        else:
            bg,bc,cls = "#f8fafc","#e2e8f0","ok"
        return html.Div([
            html.Div([
                html.Div(name,style={"fontSize":"11px","fontWeight":"500"}),
                html.Div(subs,style={"fontSize":"10px","color":"#64748b","marginTop":"1px"}),
            ]),
            _b("ERROR" if is_err else "WATCH" if is_warn else "OK", cls),
        ], style={"display":"flex","justifyContent":"space-between","alignItems":"center",
                  "background":bg,"border":f"0.5px solid {bc}","borderRadius":"8px",
                  "padding":"8px 12px"})

    region_panel = html.Div([
        html.Div("Region health",
                 style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"10px"}),
        html.Div([_region_card(*r) for r in REGIONS],
                 style={"display":"grid","gridTemplateColumns":"repeat(auto-fit,minmax(160px,1fr))",
                        "gap":"8px"}),
    ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px",
              "padding":"14px","background":"#fff","marginBottom":"12px"})

    # ── Assemble ───────────────────────────────────────────────────────────
    date_opts = [{"label": d + (" (latest)" if i==0 else ""), "value": d}
                 for i, d in enumerate(avail_dates[:60])]
    return html.Div([
        # Header
        html.Div([
            html.Div([
                html.Div("Fleet overview",
                         style={"fontSize":"15px","fontWeight":"500","color":"#1e3a5f"}),
                html.Div(f"{total} master servers · {ms_total} media servers · 6 regions · Showing: {use_date}",
                         style={"fontSize":"11px","color":"#64748b","marginTop":"2px"}),
            ]),
            html.Div([
                html.Div([
                    html.Span("Snapshot:",
                              style={"fontSize":"11px","color":"#64748b",
                                     "marginRight":"6px","whiteSpace":"nowrap",
                                     "fontWeight":"500"}),
                    html.Span(use_date,
                              id="fleet-date-display",
                              style={"fontSize":"11px","color":"#185FA5",
                                     "fontWeight":"600","marginRight":"6px"}),
                ], style={"display":"flex","alignItems":"center"}),
                _b(f"{sum(1 for r in servers if r[11]!='ERROR' and int(r[5] or 0)==0 and int(r[3] or 0)<1000 and r[13]!='Not Working')} healthy","ok"),
                _b(f"{sum(1 for r in servers if int(r[3] or 0)>1000 or r[13]=='Not Working')} watch","warn"),
                _b(f"{cat_errors} error","err") if cat_errors>0 else None,
                _b(f"Next full: {next_sat_str}","nt"),
            ], style={"display":"flex","gap":"5px","flexWrap":"wrap","alignItems":"center"}),
        ], style={"display":"flex","justifyContent":"space-between","alignItems":"center",
                  "marginBottom":"14px","flexWrap":"wrap","gap":"8px"}),

        _fleet_timeline_iframe(avail_dates, use_date,
                               lag_total_v, rv_total, rv_pct,
                               cat_ok, total),
        kpi_strip,
        vault_bar,
        srv_matrix,

        # 3-column bottom
        html.Div([media_panel, bj_panel, actions_panel],
                 style={"display":"grid","gridTemplateColumns":"1fr 1fr 1fr",
                        "gap":"12px","marginBottom":"12px"}),

        region_panel,

        html.Div(
            f"DB: {today.isoformat()} · {total} servers · {ms_total} media servers · Next full: {next_sat_str} 18:00",
            style={"fontSize":"10px","color":"#94a3b8","textAlign":"right"}),
    ], style={"padding":"16px"})


def tab_lag(master_f='all'):
    _lag_where = "" if master_f == "all" else f" WHERE server_name='{master_f}'"
    df = qdf(DB_UNIFIED, f"SELECT * FROM lag_history{_lag_where} ORDER BY date DESC LIMIT 500")
    if df.empty: return html.Div("No lag data.",style={"padding":"24px","color":"#E24B4A"})
    today=df["date"].max(); tod=df[df["date"]==today]
    total_lag=int(tod["total"].sum()); critical=int((tod["total"]>SLA_THRESH).sum())
    healthy=int((tod["total"]==0).sum()); near_sla=int(((tod["total"]>SLA_THRESH*0.8)&(tod["total"]<=SLA_THRESH)).sum())
    trend=df.groupby("date")["total"].sum().reset_index().sort_values("date").tail(14)
    f1=go.Figure(); f1.add_trace(go.Scatter(x=trend["date"],y=trend["total"],fill="tozeroy",line=dict(color="#378ADD",width=1.5),fillcolor="rgba(55,138,221,0.12)",mode="lines"))
    f1.add_hline(y=SLA_THRESH,line_dash="dash",line_color="#E24B4A",annotation_text=f"SLA={SLA_THRESH}",annotation_font_size=10)
    f1.update_layout(title=None,height=220,margin=dict(t=10,b=20,l=30,r=10),plot_bgcolor="#fafafa",paper_bgcolor="#fafafa",xaxis=dict(showgrid=False,tickfont=dict(size=9)),yaxis=dict(gridcolor="#f0f0f0",tickfont=dict(size=9)))
    tod_s=tod.sort_values("total",ascending=False)
    f2=go.Figure(go.Bar(x=tod_s["server_name"],y=tod_s["total"],marker_color=[_lag_color(v) for v in tod_s["total"]],text=tod_s["total"].astype(int),textposition="outside",textfont=dict(size=9)))
    f2.add_hline(y=SLA_THRESH,line_dash="dot",line_color="#E24B4A",annotation_text="SLA",annotation_font_size=9)
    f2.update_layout(title=None,height=220,margin=dict(t=10,b=40,l=10,r=10),plot_bgcolor="#fafafa",paper_bgcolor="#fafafa",xaxis=dict(tickfont=dict(size=9)),yaxis=dict(gridcolor="#f0f0f0",tickfont=dict(size=9)))
    cols=["server_name","not_started_remote","in_process_remote","not_started_backup","in_process_backup","not_started_duplicate","in_process_duplicate","total"]
    tbl_df=tod[cols].sort_values("total",ascending=False)
    def lag_rows(df):
        rows=[]
        for _,r in df.iterrows():
            t=int(r["total"]); bg="#fff0f0" if t>SLA_THRESH else "#fff8ec" if t>SLA_THRESH*0.8 else None
            rows.append(("_color",bg,[r["server_name"],int(r["not_started_remote"]),int(r["in_process_remote"]),int(r["not_started_backup"]),int(r["in_process_backup"]),int(r["not_started_duplicate"]),int(r["in_process_duplicate"]),
                html.Span(str(t),style={"fontWeight":"500","color":_lag_color(t)}),
                pill("QUEUE BREACH","danger") if t>SLA_THRESH else pill("NEAR LIMIT","warning") if t>SLA_THRESH*0.8 else pill("OK","success")]))
        return rows
    return html.Div([date_banner("Data date",today,"source: unified DB"),
        dbc.Row([dbc.Col(kpi_card("Queue depth",total_lag,"#E24B4A"),md=3),dbc.Col(kpi_card("Breaching SLA",critical,"#E24B4A"),md=3),dbc.Col(kpi_card("Near SLA",near_sla,"#EF9F27"),md=3),dbc.Col(kpi_card("Queue clear (0)",healthy,"#639922"),md=3)],className="mb-3 g-2"),
        dbc.Row([dbc.Col([html.Div("Fleet Duplication Queue — 14 days",style={"fontSize":"11px","fontWeight":"500","color":"#888","marginBottom":"6px"}),dcc.Graph(figure=f1,config={"displayModeBar":False})],md=6),
                 dbc.Col([html.Div(f"Per-server Duplication Queue — {today}",style={"fontSize":"11px","fontWeight":"500","color":"#888","marginBottom":"6px"}),dcc.Graph(figure=f2,config={"displayModeBar":False})],md=6)],className="mb-3"),
        rich_table(["Server","NS Remote","IP Remote","NS Backup","IP Backup","NS Dup","IP Dup","Total","Status"],lag_rows(tbl_df))],style={"padding":"24px"})


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2: DISKPOOL
# ══════════════════════════════════════════════════════════════════════════════
def tab_diskpool(master_f='all'):
    import json as _json
    df = qdf(DB_UNIFIED, """
        SELECT run_date,server_name,diskpool,diskpool_group,
               total_tb,used_tb,free_tb,status,pct_used,health,delta_used_tb
        FROM diskpool_daily
        ORDER BY run_date DESC,server_name,diskpool
    """)
    if df.empty:
        return html.Div("No diskpool data.", style={"padding":"24px","color":"#E24B4A"})

    today  = df["run_date"].max()
    dates  = sorted(df["run_date"].unique(), reverse=True)
    yest   = dates[1] if len(dates) > 1 else today
    tod    = df[df["run_date"] == today].copy()
    yd     = df[df["run_date"] == yest].copy()
    tod["pct_used"] = (tod["used_tb"] / tod["total_tb"].replace(0,1) * 100).round(1)

    CLOUD_SRVS = {"cazinp1cbkms","cazusp1cbkms","cgcukp1cbkms","cocinp1cbkms"}

    n_down    = int((tod["status"] == "Down").sum())
    n_up      = int((tod["status"] == "Up").sum())
    n_crit    = int((tod["pct_used"] >= 85).sum())
    n_warn    = int(((tod["pct_used"] >= 70) & (tod["pct_used"] < 85)).sum())
    total_u   = round(tod["used_tb"].sum(), 2)
    total_c   = round(tod["total_tb"].sum(), 2)
    fleet_pct = round(total_u / total_c * 100, 1) if total_c > 0 else 0
    cloud_tod = tod[tod["server_name"].isin(CLOUD_SRVS)]
    onprm_tod = tod[~tod["server_name"].isin(CLOUD_SRVS)]
    cloud_u   = round(cloud_tod["used_tb"].sum(), 2)
    cloud_c   = round(cloud_tod["total_tb"].sum(), 2)
    onprm_u   = round(onprm_tod["used_tb"].sum(), 2)
    onprm_c   = round(onprm_tod["total_tb"].sum(), 2)
    cloud_pct = round(cloud_u / cloud_c * 100, 1) if cloud_c > 0 else 0
    onprm_pct = round(onprm_u / onprm_c * 100, 1) if onprm_c > 0 else 0

    down_tod = tod[tod["status"] == "Down"].copy()
    down_tod = down_tod.merge(
        yd[["server_name","diskpool","used_tb"]].rename(columns={"used_tb":"used_yd"}),
        on=["server_name","diskpool"], how="left")
    down_tod["delta"] = (down_tod["used_tb"] - down_tod["used_yd"].fillna(down_tod["used_tb"])).round(3)

    th_s = {"padding":"6px 10px","textAlign":"left","color":"#64748b","fontWeight":"500",
             "fontSize":"10px","textTransform":"uppercase","letterSpacing":"0.4px",
             "background":"#f8fafc","borderBottom":"0.5px solid #e2e8f0"}

    def _badge(health, pct):
        if health == "CRITICAL" or pct >= 85: return pill("CRITICAL","danger")
        elif health == "WARNING" or pct >= 70: return pill("WARNING","warning")
        return pill("HEALTHY","success")

    def _delta_td(d):
        if abs(d) < 0.01:
            return html.Td("—", style={"padding":"6px 10px","fontSize":"10px",
                                        "color":"#94a3b8","textAlign":"right"})
        c = "#A32D2D" if d > 0 else "#3B6D11"
        return html.Td(f"{chr(43) if d>0 else chr(45)}{abs(d):.2f} TB",
                       style={"padding":"6px 10px","fontSize":"10px",
                              "color":c,"textAlign":"right","fontWeight":"500"})

    down_rows = []
    for _, r in down_tod.sort_values("pct_used", ascending=False).iterrows():
        bg = "#fff8ec" if r.get("health")=="WARNING" or r["pct_used"]>=70 else "#fff"
        down_rows.append(html.Tr([
            html.Td(r["server_name"], style={"padding":"6px 10px","fontSize":"10px","fontFamily":"monospace"}),
            html.Td(r["diskpool"],    style={"padding":"6px 10px","fontSize":"10px","color":"#64748b"}),
            html.Td(r["diskpool_group"], style={"padding":"6px 10px","fontSize":"10px"}),
            html.Td(f"{r['used_tb']:.2f}",  style={"padding":"6px 10px","fontSize":"10px","textAlign":"right"}),
            html.Td(f"{r['total_tb']:.2f}", style={"padding":"6px 10px","fontSize":"10px","textAlign":"right"}),
            html.Td(f"{r['pct_used']:.1f}%",
                    style={"padding":"6px 10px","fontSize":"10px","textAlign":"right","fontWeight":"500",
                           "color":"#A32D2D" if r["pct_used"]>=70 else "#3B6D11"}),
            html.Td(_badge(r.get("health",""), r["pct_used"]), style={"padding":"6px 10px","textAlign":"center"}),
            _delta_td(r.get("delta", 0)),
        ], style={"borderBottom":"0.5px solid #f1f5f9","background":bg}))

    srv_grp = tod.groupby("server_name").agg(
        used_tb=("used_tb","sum"), total_tb=("total_tb","sum"),
        pools=("diskpool","count"), down=("status", lambda x: (x=="Down").sum())
    ).reset_index()
    srv_grp["pct"] = (srv_grp["used_tb"] / srv_grp["total_tb"].replace(0,1) * 100).round(1)
    yd_grp = yd.groupby("server_name")["used_tb"].sum().reset_index()
    yd_grp.columns = ["server_name","used_yd"]
    srv_grp = srv_grp.merge(yd_grp, on="server_name", how="left")
    srv_grp["delta"] = (srv_grp["used_tb"] - srv_grp["used_yd"].fillna(srv_grp["used_tb"])).round(2)
    srv_grp["type"]  = srv_grp["server_name"].apply(lambda x: "cloud" if x in CLOUD_SRVS else "on-prem")
    srv_grp = srv_grp.sort_values("used_tb", ascending=False)

    def _bar_td(pct):
        c = "#E24B4A" if pct>=85 else "#BA7517" if pct>=70 else "#185FA5" if pct>=50 else "#639922"
        w = min(100, pct)
        return html.Td(
            html.Div(html.Div(style={"width":f"{w}%","height":"5px","background":c,"borderRadius":"3px"}),
                     style={"width":"90px","height":"5px","background":"#e2e8f0","borderRadius":"3px","overflow":"hidden"}),
            style={"padding":"6px 10px"})

    dom_rows = []
    for _, r in srv_grp.iterrows():
        pct = r["pct"]
        pc  = "#E24B4A" if pct>=85 else "#BA7517" if pct>=70 else "#185FA5" if pct>=50 else "#639922"
        d   = r["delta"]
        dc  = "#A32D2D" if d>0.05 else "#3B6D11" if d<-0.05 else "#94a3b8"
        ds  = "—" if abs(d)<0.05 else f"{chr(43) if d>0 else chr(45)}{abs(d):.2f} TB"
        tp  = pill("cloud","info") if r["type"]=="cloud" else pill("on-prem","success")
        dp  = html.Span(f" {int(r['down'])}↓",
                style={"fontSize":"9px","padding":"2px 5px","background":"#FCEBEB",
                       "color":"#A32D2D","borderRadius":"3px","marginLeft":"3px"}) if r["down"]>0 else ""
        dom_rows.append(html.Tr([
            html.Td(html.Span(r["server_name"].replace("cbkms",""),
                              style={"fontFamily":"monospace","fontSize":"10px"}),
                    style={"padding":"6px 10px"}),
            html.Td([tp, dp], style={"padding":"6px 10px"}),
            _bar_td(pct),
            html.Td(f"{r['used_tb']:,.0f} / {r['total_tb']:,.0f} TB",
                    style={"padding":"6px 10px","fontSize":"10px","textAlign":"right","color":"#64748b"}),
            html.Td(f"{pct:.1f}%",
                    style={"padding":"6px 10px","fontSize":"10px","textAlign":"right","fontWeight":"500","color":pc}),
            html.Td(ds, style={"padding":"6px 10px","fontSize":"10px","textAlign":"right","color":dc}),
            html.Td(f"{int(r['pools'])} pools",
                    style={"padding":"6px 10px","fontSize":"10px","textAlign":"right","color":"#94a3b8"}),
        ], style={"borderBottom":"0.5px solid #f1f5f9"}))

    pool_js = {}
    hist_df = df[["run_date","server_name","diskpool","diskpool_group","used_tb","total_tb","pct_used","health","status"]].copy()
    for (srv, pool), grp in hist_df.groupby(["server_name","diskpool"]):
        grp = grp.sort_values("run_date")
        pool_js[f"{srv}||{pool}"] = {
            "server": srv, "pool": pool,
            "group":  grp["diskpool_group"].iloc[-1],
            "cap":    round(float(grp["total_tb"].iloc[-1]), 2),
            "used":   round(float(grp["used_tb"].iloc[-1]), 2),
            "pct":    round(float(grp["pct_used"].iloc[-1]) if grp["pct_used"].iloc[-1] else 0, 1),
            "health": str(grp["health"].iloc[-1]),
            "status": str(grp["status"].iloc[-1]),
            "hist":   [{"d": row["run_date"], "u": round(float(row["used_tb"]),2)}
                       for _, row in grp.iterrows()],
        }

    servers_js = {}
    for srv, grp in tod.groupby("server_name"):
        used = round(float(grp["used_tb"].sum()), 2)
        cap  = round(float(grp["total_tb"].sum()), 2)
        servers_js[srv] = {
            "used": used, "cap": cap,
            "pct":  round(used/cap*100,1) if cap>0 else 0,
            "pools": grp["diskpool"].tolist(),
            "type":  "cloud" if srv in CLOUD_SRVS else "onprem",
            "group": str(grp["diskpool_group"].mode()[0]) if not grp.empty else "",
        }

    pool_js_str = _json.dumps(pool_js)
    srv_js_str  = _json.dumps(servers_js)

    fc_js = """
(function(){
var PD={},SD={},curScope='pool',fcChart=null;
function init(){
  var pd=document.getElementById('dp-pool-data');
  var sd=document.getElementById('dp-server-data');
  if(!pd||!sd){setTimeout(init,300);return;}
  try{PD=JSON.parse(pd.textContent||pd.innerText);}catch(e){}
  try{SD=JSON.parse(sd.textContent||sd.innerText);}catch(e){}
  buildUI();
}
function buildUI(){
  var cont=document.getElementById('dp-forecast-content');
  if(!cont)return;
  var srvs=Object.keys(SD).sort();
  var sOpts=srvs.map(function(s){return '<option value="'+s+'">'+s.replace('cbkms','')+' ('+SD[s].group+')</option>';}).join('');
  cont.innerHTML=
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;">'+
      '<div><label style="font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:0.4px;display:block;margin-bottom:4px;">Server</label>'+
        '<select id="fc-srv" style="width:100%;font-size:11px;padding:5px 8px;border:0.5px solid #e2e8f0;border-radius:6px;">'+sOpts+'</select></div>'+
      '<div><label style="font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:0.4px;display:block;margin-bottom:4px;">Diskpool</label>'+
        '<select id="fc-pool" style="width:100%;font-size:11px;padding:5px 8px;border:0.5px solid #e2e8f0;border-radius:6px;"></select></div>'+
    '</div>'+
    '<div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap;">'+
      '<div style="display:flex;gap:4px;" id="fc-scope-btns">'+
        '<button class="fc-sc on" data-s="pool" style="padding:5px 10px;font-size:11px;border:0.5px solid #B5D4F4;background:#E6F1FB;color:#0C447C;border-radius:6px;cursor:pointer;">Pool</button>'+
        '<button class="fc-sc" data-s="server" style="padding:5px 10px;font-size:11px;border:0.5px solid #ccc;background:transparent;color:#64748b;border-radius:6px;cursor:pointer;">Server</button>'+
        '<button class="fc-sc" data-s="domain" style="padding:5px 10px;font-size:11px;border:0.5px solid #ccc;background:transparent;color:#64748b;border-radius:6px;cursor:pointer;">Domain</button>'+
      '</div>'+
      '<select id="fc-yr" style="font-size:11px;padding:4px 7px;border:0.5px solid #e2e8f0;border-radius:6px;">'+
        '<option value="1">1 yr</option><option value="2">2 yr</option>'+
        '<option value="3" selected>3 yr</option><option value="4">4 yr</option><option value="5">5 yr</option>'+
      '</select>'+
      '<select id="fc-rt" style="font-size:11px;padding:4px 7px;border:0.5px solid #e2e8f0;border-radius:6px;">'+
        '<option value="5">5% YoY</option><option value="10" selected>10% YoY</option><option value="20">20% YoY</option>'+
      '</select>'+
    '</div>'+
    '<div id="fc-kpis" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(115px,1fr));gap:8px;margin-bottom:10px;"></div>'+
    '<div style="position:relative;width:100%;height:220px;"><canvas id="fc-canvas"></canvas></div>'+
    '<div style="display:flex;flex-wrap:wrap;gap:12px;margin-top:8px;font-size:11px;color:#64748b;">'+
      '<span><span style="display:inline-block;width:12px;height:2px;background:#185FA5;vertical-align:middle;margin-right:3px;"></span>Actual</span>'+
      '<span><span style="display:inline-block;width:12px;border-top:2px dashed #185FA5;vertical-align:middle;margin-right:3px;"></span>Forecast</span>'+
      '<span><span style="display:inline-block;width:12px;height:2px;background:#639922;vertical-align:middle;margin-right:3px;"></span>Capacity</span>'+
      '<span><span style="display:inline-block;width:12px;border-top:2px dashed #E24B4A;vertical-align:middle;margin-right:3px;"></span>85% threshold</span>'+
    '</div>'+
    '<div id="fc-note" style="margin-top:10px;padding:9px 12px;background:#f8fafc;border-radius:6px;font-size:11px;color:#64748b;"></div>';
  populatePools(srvs[0]);
  document.getElementById('fc-srv').addEventListener('change',function(){populatePools(this.value);});
  document.getElementById('fc-pool').addEventListener('change',renderFC);
  document.getElementById('fc-yr').addEventListener('change',renderFC);
  document.getElementById('fc-rt').addEventListener('change',renderFC);
  document.querySelectorAll('.fc-sc').forEach(function(b){
    b.addEventListener('click',function(){
      document.querySelectorAll('.fc-sc').forEach(function(x){
        x.style.background='transparent';x.style.color='#64748b';x.style.border='0.5px solid #ccc';
      });
      this.style.background='#E6F1FB';this.style.color='#0C447C';this.style.border='0.5px solid #B5D4F4';
      curScope=this.dataset.s;renderFC();
    });
  });
}
function populatePools(srv){
  var sel=document.getElementById('fc-pool');if(!sel)return;
  var pools=Object.keys(PD).filter(function(k){return k.indexOf(srv+'||')===0;}).sort();
  sel.innerHTML=pools.map(function(k){
    var p=k.split('||')[1];var d=PD[k];
    return '<option value="'+k+'">'+p+' ('+d.pct+'% · '+d.status+')</option>';
  }).join('');
  renderFC();
}
function getInfo(){
  var yr=parseInt(document.getElementById('fc-yr').value);
  var rt=parseInt(document.getElementById('fc-rt').value)/100;
  var pk=document.getElementById('fc-pool').value;
  var srv=document.getElementById('fc-srv').value;
  var CLOUDS=['cazinp1cbkms','cazusp1cbkms','cgcukp1cbkms','cocinp1cbkms'];
  var col=CLOUDS.indexOf(srv)>=0?'#185FA5':'#639922';
  if(curScope==='pool'){
    var pd=PD[pk];if(!pd)return null;
    return{hist:pd.hist,cap:pd.cap,used:pd.used,pct:pd.pct,label:pk.split('||')[1],color:col};
  } else if(curScope==='server'){
    var sd=SD[srv];if(!sd)return null;
    var dates={};
    Object.keys(PD).filter(function(k){return k.indexOf(srv+'||')===0;}).forEach(function(k){
      PD[k].hist.forEach(function(h){dates[h.d]=(dates[h.d]||0)+h.u;});
    });
    var hist=Object.keys(dates).sort().map(function(d){return{d:d,u:parseFloat(dates[d].toFixed(2))};});
    return{hist:hist,cap:sd.cap,used:sd.used,pct:sd.pct,label:srv.replace('cbkms','')+' (server)',color:col};
  } else {
    var sd2=SD[srv];if(!sd2)return null;
    var grpSrvs=Object.keys(SD).filter(function(s){return SD[s].group===sd2.group;});
    var totalU=grpSrvs.reduce(function(a,s){return a+SD[s].used;},0);
    var totalC=grpSrvs.reduce(function(a,s){return a+SD[s].cap;},0);
    var dates2={};
    grpSrvs.forEach(function(sn){
      Object.keys(PD).filter(function(k){return k.indexOf(sn+'||')===0;}).forEach(function(k){
        PD[k].hist.forEach(function(h){dates2[h.d]=(dates2[h.d]||0)+h.u;});
      });
    });
    var hist2=Object.keys(dates2).sort().map(function(d){return{d:d,u:parseFloat(dates2[d].toFixed(2))};});
    return{hist:hist2,cap:parseFloat(totalC.toFixed(2)),used:parseFloat(totalU.toFixed(2)),
           pct:parseFloat((totalU/totalC*100).toFixed(1)),label:sd2.group+' (domain)',color:'#185FA5'};
  }
}
function breach85(used,cap,rate){
  var u=used;for(var y=1;y<=20;y++){u*=(1+rate);if(u/cap>=0.85)return y;}return '>20';
}
function kpiCard(label,val,sub,color){
  return '<div style="background:#f8fafc;border-radius:8px;padding:10px 12px;">'+
    '<div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;font-weight:500;color:#64748b;margin-bottom:3px;">'+label+'</div>'+
    '<div style="font-size:18px;font-weight:500;line-height:1;color:'+color+';margin-bottom:2px;">'+val+'</div>'+
    '<div style="font-size:10px;color:#64748b;">'+sub+'</div></div>';
}
function renderFC(){
  var yr=parseInt(document.getElementById('fc-yr').value);
  var rt=parseInt(document.getElementById('fc-rt').value)/100;
  var info=getInfo();if(!info)return;
  var labels=info.hist.map(function(h){return h.d;});
  var act=info.hist.map(function(h){return h.u;});
  var fc=info.hist.map(function(){return null;});
  var cap=info.hist.map(function(){return info.cap;});
  var thr=info.hist.map(function(){return parseFloat((info.cap*0.85).toFixed(2));});
  var cur=info.used; var step=yr<=2?1:3;
  for(var m=step;m<=yr*12;m+=step){
    cur=cur*Math.pow(1+rt/12,step);
    var d=new Date(2026,3+m,1);
    labels.push(d.toISOString().slice(0,7));
    act.push(null);fc.push(parseFloat(cur.toFixed(2)));
    cap.push(info.cap);thr.push(parseFloat((info.cap*0.85).toFixed(2)));
  }
  var br=breach85(info.used,info.cap,rt);
  var fp=(cur/info.cap*100).toFixed(1);
  var bc=typeof br==='number'&&br<=5?'#854F0B':'#3B6D11';
  var kc=document.getElementById('fc-kpis');
  if(kc)kc.innerHTML=
    kpiCard('In '+yr+'y used',cur.toLocaleString(undefined,{maximumFractionDigits:0})+' TB',fp+'% of cap','#1e3a5f')+
    kpiCard('Free remaining',(info.cap-cur).toLocaleString(undefined,{maximumFractionDigits:0})+' TB','after '+yr+' years','#3B6D11')+
    kpiCard('85% threshold',br+(typeof br==='number'&&br>1?' yrs':' yr'),'at '+(rt*100).toFixed(0)+'% YoY',bc)+
    kpiCard('Current %',info.pct.toFixed(1)+'%',info.used.toLocaleString()+' TB',info.pct>=85?'#A32D2D':info.pct>=70?'#854F0B':'#185FA5');
  var nc=document.getElementById('fc-note');
  if(nc)nc.innerHTML='<strong>'+info.label+'</strong> &mdash; cap '+info.cap.toLocaleString()+' TB &nbsp;&middot;&nbsp; 85% in <strong>'+br+' yrs</strong> at '+(rt*100).toFixed(0)+'% YoY.';
  var canvas=document.getElementById('fc-canvas');if(!canvas)return;
  if(fcChart){fcChart.destroy();fcChart=null;}
  if(typeof Chart==='undefined'){setTimeout(renderFC,500);return;}
  fcChart=new Chart(canvas,{type:'line',data:{labels:labels,datasets:[
    {label:'Actual',data:act,borderColor:info.color,backgroundColor:info.color+'18',borderWidth:2,pointRadius:2,tension:0.3,fill:true,spanGaps:false},
    {label:'Forecast',data:fc,borderColor:info.color,borderDash:[5,4],borderWidth:2,pointRadius:2,tension:0.3,fill:false,spanGaps:false},
    {label:'Capacity',data:cap,borderColor:'#639922',borderWidth:1.5,pointRadius:0,fill:false},
    {label:'85%',data:thr,borderColor:'#E24B4A',borderDash:[4,3],borderWidth:1.5,pointRadius:0,fill:false}
  ]},options:{responsive:true,maintainAspectRatio:false,
    plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return c.parsed.y!=null?c.dataset.label+': '+c.parsed.y.toLocaleString()+' TB':null;}}}},
    scales:{
      x:{ticks:{font:{size:10},maxRotation:45,autoSkip:true,maxTicksLimit:10},grid:{color:'rgba(128,128,128,0.07)'}},
      y:{ticks:{font:{size:10},callback:function(v){return v>=1000?(v/1000).toFixed(1)+'k':v;}},grid:{color:'rgba(128,128,128,0.07)'}}
    }
  }});
}
function waitChart(){if(typeof Chart!=='undefined'){init();}else{setTimeout(waitChart,200);}}
setTimeout(waitChart,100);
})();
"""

    return html.Div([
        date_banner("Data date", today, "source: unified DB"),
        html.Div([
            html.Div([html.Div("Down pools",style={"fontSize":"10px","fontWeight":"500","textTransform":"uppercase","letterSpacing":"0.5px","color":"#A32D2D","marginBottom":"3px"}),
                      html.Div(str(n_down),style={"fontSize":"22px","fontWeight":"500","color":"#A32D2D","lineHeight":"1"}),
                      html.Div(f"{n_down} pool(s) down",style={"fontSize":"10px","color":"#A32D2D","marginTop":"3px"})],
                     style={"background":"#FCEBEB","border":"0.5px solid #F7C1C1","borderRadius":"8px","padding":"10px 12px"}),
            html.Div([html.Div("Up pools",style={"fontSize":"10px","fontWeight":"500","textTransform":"uppercase","letterSpacing":"0.5px","color":"#64748b","marginBottom":"3px"}),
                      html.Div(str(n_up),style={"fontSize":"22px","fontWeight":"500","color":"#1e3a5f","lineHeight":"1"}),
                      html.Div(f"{n_crit} critical · {n_up-n_crit} healthy",style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                     style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 12px"}),
            html.Div([html.Div("Critical ≥85%",style={"fontSize":"10px","fontWeight":"500","textTransform":"uppercase","letterSpacing":"0.5px","color":"#854F0B","marginBottom":"3px"}),
                      html.Div(str(n_crit),style={"fontSize":"22px","fontWeight":"500","color":"#854F0B","lineHeight":"1"}),
                      html.Div(f"{n_warn} warning ≥70%",style={"fontSize":"10px","color":"#854F0B","marginTop":"3px"})],
                     style={"background":"#FAEEDA","border":"0.5px solid #FAC775","borderRadius":"8px","padding":"10px 12px"}),
            html.Div([html.Div("Cloud used",style={"fontSize":"10px","fontWeight":"500","textTransform":"uppercase","letterSpacing":"0.5px","color":"#64748b","marginBottom":"3px"}),
                      html.Div(f"{cloud_u:,.0f} TB",style={"fontSize":"22px","fontWeight":"500","color":"#185FA5","lineHeight":"1"}),
                      html.Div(f"of {cloud_c:,.0f} TB · {cloud_pct}%",style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                     style={"background":"#f8fafc","borderLeft":"3px solid #185FA5","borderRadius":"0 8px 8px 0","padding":"10px 12px"}),
            html.Div([html.Div("On-prem used",style={"fontSize":"10px","fontWeight":"500","textTransform":"uppercase","letterSpacing":"0.5px","color":"#64748b","marginBottom":"3px"}),
                      html.Div(f"{onprm_u:,.0f} TB",style={"fontSize":"22px","fontWeight":"500","color":"#639922","lineHeight":"1"}),
                      html.Div(f"of {onprm_c:,.0f} TB · {onprm_pct}%",style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                     style={"background":"#f8fafc","borderLeft":"3px solid #639922","borderRadius":"0 8px 8px 0","padding":"10px 12px"}),
            html.Div([html.Div("Fleet total",style={"fontSize":"10px","fontWeight":"500","textTransform":"uppercase","letterSpacing":"0.5px","color":"#64748b","marginBottom":"3px"}),
                      html.Div(f"{total_u:,.0f} TB",style={"fontSize":"22px","fontWeight":"500","color":"#1e3a5f","lineHeight":"1"}),
                      html.Div(f"{len(tod)} pools · {fleet_pct}%",style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                     style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 12px"}),
        ], style={"display":"grid","gridTemplateColumns":"repeat(auto-fit,minmax(100px,1fr))","gap":"8px","marginBottom":"14px"}),
        html.Div([
            html.Div([html.Span(style={"width":"8px","height":"8px","borderRadius":"50%","background":"#E24B4A","display":"inline-block","marginRight":"6px"}),
                      html.Span(f"Down pools ({n_down}) — status detail",style={"fontSize":"12px","fontWeight":"500","color":"#A32D2D"})],
                     style={"display":"flex","alignItems":"center","marginBottom":"10px"}),
            html.Table([
                html.Thead(html.Tr([html.Th(h,style={**th_s,**({"textAlign":"right"} if h in ["Used TB","Total TB","% used","vs yesterday"] else {"textAlign":"center"} if h=="Health" else {})})
                                    for h in ["Server","Diskpool","Group","Used TB","Total TB","% used","Health","vs yesterday"]])),
                html.Tbody(down_rows if down_rows else [html.Tr(html.Td("All pools Up",colSpan=8,style={"padding":"12px","color":"#3B6D11","textAlign":"center","fontSize":"11px"}))])
            ], style={"width":"100%","borderCollapse":"collapse","border":"0.5px solid #e2e8f0","borderRadius":"8px","overflow":"hidden"}),
        ], style={"border":"0.5px solid #F7C1C1","borderRadius":"10px","padding":"14px","marginBottom":"14px","background":"#fff"}),
        html.Div([
            html.Div("Pool usage by server — cloud vs on-prem",style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"10px"}),
            html.Table([
                html.Thead(html.Tr([html.Th(h,style={**th_s,**({"textAlign":"right"} if h in ["Used / Total","% ","vs yesterday","Pools"] else {})})
                                    for h in ["Server","Type","Usage","Used / Total","% ","vs yesterday","Pools"]])),
                html.Tbody(dom_rows),
            ], style={"width":"100%","borderCollapse":"collapse","border":"0.5px solid #e2e8f0","borderRadius":"8px","overflow":"hidden"}),
        ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px","padding":"14px","marginBottom":"14px","background":"#fff"}),
        html.Div([
            html.Div("Capacity forecast — server & diskpool drill-down",style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"12px"}),
            html.Div(id="dp-forecast-content",children=html.Div("Loading...",style={"color":"#94a3b8","fontSize":"11px"})),
            html.Div(id="dp-pool-data",   style={"display":"none"}, children=pool_js_str),
            html.Div(id="dp-server-data", style={"display":"none"}, children=srv_js_str),
            # Inject Chart.js + forecast JS via iframe srcdoc workaround
            html.Iframe(
                id="dp-forecast-frame",
                style={"width":"100%","border":"none","minHeight":"520px"},
                srcDoc=f"""<!DOCTYPE html>
<html><head>
<script src="/assets/chart.umd.js"></script>
<style>
body{{margin:0;padding:0;font-family:system-ui,sans-serif;background:transparent;}}
select,button{{cursor:pointer;border-radius:6px;}}
.fc-sc{{padding:5px 10px;font-size:11px;border:0.5px solid #ccc;background:transparent;color:#64748b;}}
.fc-sc.on{{background:#E6F1FB;color:#0C447C;border-color:#B5D4F4;}}
.kpi{{background:#f8fafc;border-radius:8px;padding:10px 12px;}}
</style>
</head><body>
<div id="root"></div>
<script>
var PD={pool_js_str};
var SD={srv_js_str};
var curScope='pool',fcChart=null;

function buildUI(){{
  var srvs=Object.keys(SD).sort();
  var sOpts=srvs.map(function(s){{return '<option value="'+s+'">'+s.replace('cbkms','')+' ('+SD[s].group+')</option>';}}).join('');
  document.getElementById('root').innerHTML=
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;">'+
      '<div><label style="font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:0.4px;display:block;margin-bottom:4px;">Server</label>'+
        '<select id="fc-srv" style="width:100%;font-size:11px;padding:5px 8px;border:0.5px solid #e2e8f0;border-radius:6px;">'+sOpts+'</select></div>'+
      '<div><label style="font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:0.4px;display:block;margin-bottom:4px;">Diskpool</label>'+
        '<select id="fc-pool" style="width:100%;font-size:11px;padding:5px 8px;border:0.5px solid #e2e8f0;border-radius:6px;"></select></div>'+
    '</div>'+
    '<div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap;">'+
      '<div style="display:flex;gap:4px;">'+
        '<button class="fc-sc on" data-s="pool" onclick="setScope(this)">Pool</button>'+
        '<button class="fc-sc" data-s="server" onclick="setScope(this)">Server</button>'+
        '<button class="fc-sc" data-s="domain" onclick="setScope(this)">Domain</button>'+
      '</div>'+
      '<select id="fc-yr" onchange="renderFC()" style="font-size:11px;padding:4px 7px;border:0.5px solid #e2e8f0;border-radius:6px;">'+
        '<option value="1">1 yr</option><option value="2">2 yr</option>'+
        '<option value="3" selected>3 yr</option><option value="4">4 yr</option><option value="5">5 yr</option>'+
      '</select>'+
      '<select id="fc-rt" onchange="renderFC()" style="font-size:11px;padding:4px 7px;border:0.5px solid #e2e8f0;border-radius:6px;">'+
        '<option value="5">5% YoY</option><option value="10" selected>10% YoY</option><option value="20">20% YoY</option>'+
      '</select>'+
    '</div>'+
    '<div id="fc-kpis" style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px;"></div>'+
    '<div style="position:relative;width:100%;height:200px;"><canvas id="fc-canvas"></canvas></div>'+
    '<div style="display:flex;flex-wrap:wrap;gap:12px;margin-top:8px;font-size:11px;color:#64748b;">'+
      '<span><span style="display:inline-block;width:12px;height:2px;background:#185FA5;vertical-align:middle;margin-right:3px;"></span>Actual</span>'+
      '<span><span style="display:inline-block;width:12px;border-top:2px dashed #185FA5;vertical-align:middle;margin-right:3px;"></span>Forecast</span>'+
      '<span><span style="display:inline-block;width:12px;height:2px;background:#639922;vertical-align:middle;margin-right:3px;"></span>Capacity</span>'+
      '<span><span style="display:inline-block;width:12px;border-top:2px dashed #E24B4A;vertical-align:middle;margin-right:3px;"></span>85% line</span>'+
    '</div>'+
    '<div id="fc-note" style="margin-top:10px;padding:9px 12px;background:#f8fafc;border-radius:6px;font-size:11px;color:#64748b;"></div>';
  populatePools(srvs[0]);
  document.getElementById('fc-srv').addEventListener('change',function(){{populatePools(this.value);}});
  document.getElementById('fc-pool').addEventListener('change',renderFC);
}}

function setScope(btn){{
  document.querySelectorAll('.fc-sc').forEach(function(b){{b.classList.remove('on');}});
  btn.classList.add('on'); curScope=btn.dataset.s; renderFC();
}}

function populatePools(srv){{
  var sel=document.getElementById('fc-pool');if(!sel)return;
  var pools=Object.keys(PD).filter(function(k){{return k.indexOf(srv+'||')===0;}}).sort();
  sel.innerHTML=pools.map(function(k){{
    var p=k.split('||')[1];var d=PD[k];
    return '<option value="'+k+'">'+p+' ('+d.pct+'% · '+d.status+')</option>';
  }}).join('');
  renderFC();
}}

function getInfo(){{
  var srv=document.getElementById('fc-srv').value;
  var pk=document.getElementById('fc-pool').value;
  var CLOUDS=['cazinp1cbkms','cazusp1cbkms','cgcukp1cbkms','cocinp1cbkms'];
  var col=CLOUDS.indexOf(srv)>=0?'#185FA5':'#639922';
  if(curScope==='pool'){{
    var pd=PD[pk];if(!pd)return null;
    return{{hist:pd.hist,cap:pd.cap,used:pd.used,pct:pd.pct,label:pk.split('||')[1],color:col}};
  }}else if(curScope==='server'){{
    var sd=SD[srv];if(!sd)return null;
    var dates={{}};
    Object.keys(PD).filter(function(k){{return k.indexOf(srv+'||')===0;}}).forEach(function(k){{
      PD[k].hist.forEach(function(h){{dates[h.d]=(dates[h.d]||0)+h.u;}});
    }});
    var hist=Object.keys(dates).sort().map(function(d){{return{{d:d,u:parseFloat(dates[d].toFixed(2))}}}});
    return{{hist:hist,cap:sd.cap,used:sd.used,pct:sd.pct,label:srv.replace('cbkms','')+'(server)',color:col}};
  }}else{{
    var sd2=SD[srv];if(!sd2)return null;
    var grp=Object.keys(SD).filter(function(s){{return SD[s].group===sd2.group;}});
    var tU=grp.reduce(function(a,s){{return a+SD[s].used;}},0);
    var tC=grp.reduce(function(a,s){{return a+SD[s].cap;}},0);
    var dates2={{}};
    grp.forEach(function(sn){{
      Object.keys(PD).filter(function(k){{return k.indexOf(sn+'||')===0;}}).forEach(function(k){{
        PD[k].hist.forEach(function(h){{dates2[h.d]=(dates2[h.d]||0)+h.u;}});
      }});
    }});
    var hist2=Object.keys(dates2).sort().map(function(d){{return{{d:d,u:parseFloat(dates2[d].toFixed(2))}}}});
    return{{hist:hist2,cap:parseFloat(tC.toFixed(2)),used:parseFloat(tU.toFixed(2)),
            pct:parseFloat((tU/tC*100).toFixed(1)),label:sd2.group+'(domain)',color:'#185FA5'}};
  }}
}}

function breach85(used,cap,rate){{
  var u=used;for(var y=1;y<=20;y++){{u*=(1+rate);if(u/cap>=0.85)return y;}}return '>20';
}}

function kpiCard(label,val,sub,color){{
  return '<div class="kpi">'+
    '<div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;font-weight:500;color:#64748b;margin-bottom:3px;">'+label+'</div>'+
    '<div style="font-size:17px;font-weight:500;line-height:1;color:'+color+';margin-bottom:2px;">'+val+'</div>'+
    '<div style="font-size:10px;color:#64748b;">'+sub+'</div></div>';
}}

function renderFC(){{
  var yr=parseInt(document.getElementById('fc-yr').value);
  var rt=parseInt(document.getElementById('fc-rt').value)/100;
  var info=getInfo();if(!info)return;
  var labels=info.hist.map(function(h){{return h.d;}});
  var act=info.hist.map(function(h){{return h.u;}});
  var fc=info.hist.map(function(){{return null;}});
  var cap=info.hist.map(function(){{return info.cap;}});
  var thr=info.hist.map(function(){{return parseFloat((info.cap*0.85).toFixed(2));}});
  var cur=info.used;var step=yr<=2?1:3;
  for(var m=step;m<=yr*12;m+=step){{
    cur=cur*Math.pow(1+rt/12,step);
    var d=new Date(2026,3+m,1);
    labels.push(d.toISOString().slice(0,7));
    act.push(null);fc.push(parseFloat(cur.toFixed(2)));
    cap.push(info.cap);thr.push(parseFloat((info.cap*0.85).toFixed(2)));
  }}
  var br=breach85(info.used,info.cap,rt);
  var fp=(cur/info.cap*100).toFixed(1);
  var bc=typeof br==='number'&&br<=5?'#854F0B':'#3B6D11';
  var kc=document.getElementById('fc-kpis');
  if(kc)kc.innerHTML=
    kpiCard('In '+yr+'y used',cur.toLocaleString(undefined,{{maximumFractionDigits:0}})+' TB',fp+'% of cap','#1e3a5f')+
    kpiCard('Free remaining',(info.cap-cur).toLocaleString(undefined,{{maximumFractionDigits:0}})+' TB','after '+yr+' yrs','#3B6D11')+
    kpiCard('85% threshold',br+(typeof br==='number'&&br>1?' yrs':' yr'),'at '+(rt*100).toFixed(0)+'% YoY',bc)+
    kpiCard('Current %',info.pct.toFixed(1)+'%',info.used.toLocaleString()+' TB',info.pct>=85?'#A32D2D':info.pct>=70?'#854F0B':'#185FA5');
  var nc=document.getElementById('fc-note');
  if(nc)nc.innerHTML='<strong>'+info.label+'</strong> &mdash; cap '+info.cap.toLocaleString()+' TB &nbsp;&middot;&nbsp; 85% in <strong>'+br+' yrs</strong> at '+(rt*100).toFixed(0)+'% YoY.';
  var canvas=document.getElementById('fc-canvas');if(!canvas)return;
  if(fcChart){{fcChart.destroy();fcChart=null;}}
  fcChart=new Chart(canvas,{{type:'line',data:{{labels:labels,datasets:[
    {{label:'Actual',data:act,borderColor:info.color,backgroundColor:info.color+'18',borderWidth:2,pointRadius:2,tension:0.3,fill:true,spanGaps:false}},
    {{label:'Forecast',data:fc,borderColor:info.color,borderDash:[5,4],borderWidth:2,pointRadius:2,tension:0.3,fill:false,spanGaps:false}},
    {{label:'Capacity',data:cap,borderColor:'#639922',borderWidth:1.5,pointRadius:0,fill:false}},
    {{label:'85%',data:thr,borderColor:'#E24B4A',borderDash:[4,3],borderWidth:1.5,pointRadius:0,fill:false}}
  ]}},options:{{responsive:true,maintainAspectRatio:false,
    plugins:{{legend:{{display:false}},tooltip:{{callbacks:{{label:function(c){{return c.parsed.y!=null?c.dataset.label+': '+c.parsed.y.toLocaleString()+' TB':null;}}}}}}}},
    scales:{{
      x:{{ticks:{{font:{{size:10}},maxRotation:45,autoSkip:true,maxTicksLimit:10}},grid:{{color:'rgba(128,128,128,0.07)'}}}},
      y:{{ticks:{{font:{{size:10}},callback:function(v){{return v>=1000?(v/1000).toFixed(1)+'k':v;}}}},grid:{{color:'rgba(128,128,128,0.07)'}}}}
    }}
  }}}});
}}

buildUI();
</script>
</body></html>"""
            ),
        ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px","padding":"14px","background":"#fff","marginBottom":"14px"}),
        html.Div("* Recovery Vault pools (8,192 TB) are object storage — included in totals but not backup appliance capacity.",
                 style={"fontSize":"10px","color":"#94a3b8","textAlign":"right"}),
    ], style={"padding":"16px"})

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3: 3RD-SITE
# ══════════════════════════════════════════════════════════════════════════════
def _build_srv_selector_iframe(srv_wk_js, LICENSE=910):
    import json as _json
    from pathlib import Path as _P
    sd = _json.dumps(srv_wk_js)
    cjs = _P("/usr/nbu-cts-v2/assets/chart.umd.js").read_text()
    parts = [
        "<!DOCTYPE html><html><head>",
        "<style>",
        "*{box-sizing:border-box;font-family:system-ui,sans-serif;margin:0;padding:0;}",
        "body{padding:4px;background:transparent;}",
        ".btn{padding:5px 11px;font-size:11px;border:0.5px solid #ccc;",
        "background:transparent;color:#64748b;border-radius:6px;cursor:pointer;",
        "margin-right:4px;margin-bottom:4px;}",
        ".btn.on{background:#E6F1FB;color:#0C447C;border-color:#B5D4F4;}",
        "</style>",
        "<script>", cjs, "</script>",
        "</head><body>",
        "<div id='btns' style='display:flex;gap:4px;flex-wrap:wrap;margin-bottom:10px;'></div>",
        "<div style='position:relative;height:235px;'><canvas id='sc'></canvas></div>",
        "<script>",
        "var SD=", sd, ";",
        """
var chart=null;
var srvs=Object.keys(SD);
var COLORS={
  'cocinp1cbkms':'#185FA5','cazinp1cbkms':'#185FA5',
  'cpcinp1cbkms':'#639922','cpcinp2cbkms':'#639922','cgcukp1cbkms':'#854F0B'
};
function renderBtns(active){
  var d=document.getElementById('btns');
  d.innerHTML=srvs.map(function(s){
    var short=s.replace('cbkms','');
    var cls='btn'+(s===active?' on':'');
    return '<button class="'+cls+'" onclick="render(this.dataset.srv)" data-srv="'+s+'">'+short+'</button>';
  }).join('');
}
function render(srv){
  renderBtns(srv);
  var wks=SD[srv];
  if(!wks||!wks.length)return;
  var labels=wks.map(function(w){return w.lbl;});
  var peaks=wks.map(function(w){return w.rv||0;});
  var vis=wks.map(function(w){return w.vi||0;});
  var color=COLORS[srv]||'#185FA5';
  var canvas=document.getElementById('sc');
  if(chart){chart.destroy();chart=null;}
  chart=new Chart(canvas,{
    type:'bar',
    data:{labels:labels,datasets:[
      {label:'Peak pool TB',data:peaks,
       backgroundColor:color+'88',borderColor:color,borderWidth:1.5,borderRadius:4},
      {label:'Vault-in TB',data:vis,
       backgroundColor:'rgba(99,153,34,0.45)',
       borderColor:'#639922',borderWidth:1.5,borderRadius:4},
    ]},
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{
        legend:{labels:{font:{size:10},boxWidth:10}},
        title:{display:true,text:srv+' — 5 week trend',
               font:{size:11},color:'#1e3a5f'}
      },
      scales:{y:{ticks:{font:{size:10},
        callback:function(v){return v+' TB';}}}}
    }
  });
}
if(srvs.length>0)render(srvs[0]);
""",
        "</script></body></html>"
    ]
    return "".join(parts)


def _build_srv_monthly_chart(srv, srv_wk_js, LICENSE=910):
    """Build per-server monthly iframe chart for tab_3rdsite monthly tab."""
    if not srv or srv not in srv_wk_js:
        return html.Div("No data", style={"color":"#94a3b8","fontSize":"11px"})
    wks = srv_wk_js[srv]
    peaks = [w["rv"] for w in wks]
    vis   = [w["vi"] for w in wks]
    labels= [w["lbl"] for w in wks]
    COLORS = {
        "cocinp1cbkms":"#185FA5","cazinp1cbkms":"#185FA5",
        "cpcinp1cbkms":"#639922","cpcinp2cbkms":"#639922","cgcukp1cbkms":"#854F0B"
    }
    color = COLORS.get(srv, "#185FA5")
    src_doc = f"""<!DOCTYPE html><html><head>
<script src="/assets/chart.umd.js"></script>
<style>*{{box-sizing:border-box;margin:0;padding:0;}}</style></head><body>
<canvas id="sc" style="width:100%;height:155px;"></canvas>
<script>
new Chart(document.getElementById('sc'),{{type:'bar',data:{{
  labels:{labels},
  datasets:[
    {{label:'Peak pool TB',data:{peaks},backgroundColor:'{color}99',
     borderColor:'{color}',borderWidth:1.5,borderRadius:4}},
    {{label:'Vault-in TB',data:{vis},backgroundColor:'rgba(99,153,34,0.5)',
     borderColor:'#639922',borderWidth:1.5,borderRadius:4}},
  ]
}},options:{{responsive:true,maintainAspectRatio:false,
  plugins:{{legend:{{labels:{{font:{{size:10}},boxWidth:8}}}},
            title:{{display:true,text:'{srv} — 5 week trend',font:{{size:11}}}}}},
  scales:{{y:{{ticks:{{font:{{size:10}},callback:function(v){{return v+' TB';}}}}}}}}
}}}});
</script></body></html>"""
    return html.Iframe(srcDoc=src_doc,
                       style={"width":"100%","border":"none","height":"175px","marginTop":"8px"})


def tab_3rdsite(master_f='all'):
    import json as _json
    from datetime import date, timedelta

    # ── Data queries ──────────────────────────────────────────────────────
    con = __import__('sqlite3').connect(DB_UNIFIED)
    LICENSE   = 910.0
    THRESHOLD = LICENSE * 0.85

    # Latest dates
    rv_latest = con.execute(
        "SELECT MAX(run_date) FROM diskpool_daily WHERE diskpool_group='Recovery Vault'"
    ).fetchone()[0] or date.today().isoformat()
    ts_latest = con.execute(
        "SELECT MAX(report_date) FROM thirdsite_summary"
    ).fetchone()[0] or rv_latest

    # Current Sat-Sat week
    rv_dt       = date.fromisoformat(rv_latest)
    days_to_sat = (rv_dt.weekday() - 5) % 7
    curr_sat    = rv_dt - timedelta(days=days_to_sat)
    ws, we      = curr_sat.isoformat(), (curr_sat + timedelta(days=6)).isoformat()

    # Next full backup Saturday
    _days_to_next_sat = (5 - rv_dt.weekday()) % 7 or 7
    _next_sat = rv_dt + timedelta(days=_days_to_next_sat)
    _next_mon = _next_sat + timedelta(days=2)
    _next_sat_str = _next_sat.strftime("Sat %d %b")
    _next_mon_str = _next_mon.strftime("Mon %d %b")

    # Fleet recovery vault daily trend
    trend = con.execute("""
        SELECT run_date, ROUND(SUM(used_tb),3) as vault_tb
        FROM diskpool_daily WHERE diskpool_group='Recovery Vault'
        GROUP BY run_date ORDER BY run_date
    """).fetchall()
    latest_vault = trend[-1][1] if trend else 0
    peak_row     = max(trend, key=lambda x: x[1]) if trend else (rv_latest, 0)
    days_over    = sum(1 for r in trend if r[1] > LICENSE)
    days_above   = sum(1 for r in trend if r[1] > THRESHOLD)
    pct_used     = round(latest_vault / LICENSE * 100, 1)
    s_color      = "#A32D2D" if latest_vault > LICENSE else "#854F0B" if latest_vault > THRESHOLD else "#3B6D11"
    s_label      = "OVER LICENSE" if latest_vault > LICENSE else "ABOVE 85%" if latest_vault > THRESHOLD else "OK"

    # Per-server latest thirdsite
    ts_rows_db = con.execute("""
        SELECT server_name, ROUND(total_data_tb,3), ROUND(avg_dedup_percent,1),
               ROUND(avg_gbps,4), max_worm_days, report_date
        FROM thirdsite_summary
        WHERE report_date=(SELECT MAX(report_date) FROM thirdsite_summary)
        ORDER BY total_data_tb DESC
    """).fetchall()

    # Per-server this week
    srv_week = con.execute("""
        SELECT d.server_name,
               ROUND(MAX(SUM_rv),3) as rv_peak,
               t.vault_in, t.dedup, t.worm
        FROM (SELECT run_date, server_name, SUM(used_tb) as SUM_rv
              FROM diskpool_daily
              WHERE diskpool_group='Recovery Vault'
              AND run_date BETWEEN ? AND ?
              GROUP BY run_date, server_name) d
        LEFT JOIN (
            SELECT server_name,
                   ROUND(SUM(CASE WHEN delta_tb>0 THEN delta_tb ELSE 0 END),3) as vault_in,
                   ROUND(AVG(CASE WHEN avg_dedup_percent>0 THEN avg_dedup_percent END),1) as dedup,
                   MAX(max_worm_days) as worm
            FROM thirdsite_summary WHERE report_date BETWEEN ? AND ?
            GROUP BY server_name
        ) t ON t.server_name=d.server_name
        GROUP BY d.server_name ORDER BY rv_peak DESC
    """, (ws, we, ws, we)).fetchall()

    # Pool detail
    pools_db = con.execute("""
        SELECT server_name, diskpool, ROUND(used_tb,3), status
        FROM diskpool_daily
        WHERE diskpool_group='Recovery Vault' AND run_date=?
        ORDER BY used_tb DESC
    """, (rv_latest,)).fetchall()

    # 5-week history
    wk_hist = []
    for i in range(5):
        wws = (curr_sat - timedelta(weeks=i)).isoformat()
        wwe = (curr_sat - timedelta(weeks=i) + timedelta(days=6)).isoformat()
        r = con.execute("""
            SELECT ROUND(MAX(s),3), ROUND(MIN(s),3)
            FROM (SELECT run_date, SUM(used_tb) as s
                  FROM diskpool_daily WHERE diskpool_group='Recovery Vault'
                  AND run_date BETWEEN ? AND ? GROUP BY run_date)
        """, (wws, wwe)).fetchone()
        vi = con.execute("""
            SELECT ROUND(SUM(CASE WHEN delta_tb>0 THEN delta_tb ELSE 0 END),3),
                   ROUND(AVG(CASE WHEN avg_dedup_percent>0 THEN avg_dedup_percent END),1)
            FROM thirdsite_summary WHERE report_date BETWEEN ? AND ?
        """, (wws, wwe)).fetchone()
        lbl = f"{'Current' if i==0 else f'W-{i}'} (Sat {wws[5:]}–Fri {wwe[5:]})"
        wk_hist.append({
            "lbl": lbl, "ws": wws, "we": wwe,
            "rv_peak": r[0] or 0, "rv_min": r[1] or 0,
            "vault_in": vi[0] or 0, "dedup": vi[1] or 0,
            "is_current": i == 0
        })

    # Per-server 5-week history for JS
    srv_wk_js = {}
    REGIONS = {'cocinp1cbkms':'OCI India','cazinp1cbkms':'Azure India',
                'cpcinp1cbkms':'India P1','cpcinp2cbkms':'India P2','cgcukp1cbkms':'GCP UK'}
    all_srvs = list(set([r[0] for r in srv_week] + list(REGIONS.keys())))
    for srv in all_srvs:
        srv_wk_js[srv] = []
        for i in range(4, -1, -1):
            wws = (curr_sat - timedelta(weeks=i)).isoformat()
            wwe = (curr_sat - timedelta(weeks=i) + timedelta(days=6)).isoformat()
            r2 = con.execute("""
                SELECT ROUND(MAX(s),3) FROM
                (SELECT SUM(used_tb) as s FROM diskpool_daily
                 WHERE diskpool_group='Recovery Vault'
                 AND server_name=? AND run_date BETWEEN ? AND ?
                 GROUP BY run_date)
            """, (srv, wws, wwe)).fetchone()
            vi2 = con.execute("""
                SELECT ROUND(SUM(CASE WHEN delta_tb>0 THEN delta_tb ELSE 0 END),3)
                FROM thirdsite_summary WHERE server_name=? AND report_date BETWEEN ? AND ?
            """, (srv, wws, wwe)).fetchone()
            lbl2 = f"{'Current' if i==0 else f'W-{i}'}"
            srv_wk_js[srv].append({
                "lbl": lbl2, "rv": r2[0] or 0, "vi": vi2[0] or 0
            })

    # Daily server data for JS (last 14 days)
    daily_db = con.execute("""
        SELECT d.run_date, d.server_name,
               ROUND(SUM(d.used_tb),3) as rv_tb,
               t.total_data_tb, t.delta_tb,
               t.avg_dedup_percent, t.max_worm_days, t.total_dup
        FROM diskpool_daily d
        LEFT JOIN thirdsite_summary t
            ON t.server_name=d.server_name AND t.report_date=d.run_date
        WHERE d.diskpool_group='Recovery Vault'
        AND d.run_date >= date('now','-14 days')
        GROUP BY d.run_date, d.server_name
        ORDER BY d.run_date DESC, rv_tb DESC
    """).fetchall()
    con.close()

    # ── JS data ───────────────────────────────────────────────────────────
    trend_js  = _json.dumps([{"d": r[0][5:], "v": r[1]} for r in trend])
    daily_js  = _json.dumps([{
        "d": r[0], "srv": r[1].replace("cbkms",""),
        "rv": r[2], "ts": round(float(r[3] or 0),3),
        "delta": round(float(r[4] or 0),3),
        "dd": round(float(r[5] or 0),1),
        "worm": int(r[6] or 0), "q": int(r[7] or 0)
    } for r in daily_db])
    srv_wk_str = _json.dumps(srv_wk_js)

    th = {"padding":"6px 10px","textAlign":"left","color":"#64748b","fontWeight":"500",
          "fontSize":"10px","textTransform":"uppercase","letterSpacing":"0.4px",
          "background":"#f8fafc","borderBottom":"0.5px solid #e2e8f0"}
    thr = {**th, "textAlign":"right"}

    def _pc(v, cap=910):
        p = v/cap*100
        return "#A32D2D" if p>100 else "#854F0B" if p>85 else "#185FA5" if p>70 else "#3B6D11"

    def _pbar(pct, color, w=70):
        return html.Div(html.Div(style={"width":f"{min(100,max(0,pct))}%","height":"100%",
                                         "background":color,"borderRadius":"2px"}),
                        style={"width":f"{w}px","height":"4px","background":"#e2e8f0",
                               "borderRadius":"2px","overflow":"hidden",
                               "display":"inline-block","marginLeft":"4px","verticalAlign":"middle"})

    # ── Alert banner ──────────────────────────────────────────────────────
    if latest_vault > LICENSE:
        alert = html.Div([
            html.Span("🚨", style={"fontSize":"18px","marginRight":"10px"}),
            html.Div([
                html.Div(f"LICENSE BREACH — {rv_latest}",
                         style={"fontSize":"12px","fontWeight":"600","color":"#A32D2D"}),
                html.Div(f"Vault at {latest_vault} TB ({pct_used}%) — over 910 TB cap. "
                         f"Breached on {days_over} days total.",
                         style={"fontSize":"11px","color":"#A32D2D","marginTop":"2px"}),
            ], style={"flex":"1"}),
            html.Div([html.Div(f"{latest_vault} TB",style={"fontSize":"18px","fontWeight":"700"}),
                      html.Div("OVER LICENSE",style={"fontSize":"9px","opacity":"0.9"})],
                     style={"background":"#A32D2D","color":"#fff","borderRadius":"8px",
                            "padding":"6px 14px","textAlign":"center"}),
        ], style={"background":"#FCEBEB","border":"0.5px solid #F7C1C1","borderRadius":"10px",
                  "padding":"12px 16px","marginBottom":"14px","display":"flex",
                  "alignItems":"center","gap":"10px","flexWrap":"wrap"})
    elif latest_vault > THRESHOLD:
        alert = html.Div([
            html.Span("⚠️", style={"fontSize":"18px","marginRight":"10px"}),
            html.Div([
                html.Div(f"Above 85% threshold — {rv_latest}",
                         style={"fontSize":"12px","fontWeight":"600","color":"#854F0B"}),
                html.Div(f"Vault at {latest_vault} TB ({pct_used}%). "
                         f"Previously breached on {days_over} days (peak {peak_row[1]} TB on {peak_row[0]}).",
                         style={"fontSize":"11px","color":"#854F0B","marginTop":"2px"}),
            ], style={"flex":"1"}),
            html.Div([html.Div(f"{pct_used}%",style={"fontSize":"18px","fontWeight":"700"}),
                      html.Div("of license",style={"fontSize":"9px","opacity":"0.9"})],
                     style={"background":"#854F0B","color":"#fff","borderRadius":"8px",
                            "padding":"6px 14px","textAlign":"center"}),
        ], style={"background":"#FAEEDA","border":"0.5px solid #FAC775","borderRadius":"10px",
                  "padding":"12px 16px","marginBottom":"14px","display":"flex",
                  "alignItems":"center","gap":"10px","flexWrap":"wrap"})
    else:
        alert = html.Div()

    # ── Header banner ─────────────────────────────────────────────────────
    bar_pct = min(100, pct_used)
    bar_c   = "#E24B4A" if latest_vault>LICENSE else "#FFD700" if latest_vault>THRESHOLD else "#fff"
    banner  = html.Div([
        html.Div([
            html.Div([
                html.Div("External Airgap — Recovery Vault Dashboard",
                         style={"fontSize":"14px","fontWeight":"600"}),
                html.Div(f"7 pools · 5 servers · License: 910 TB · DB: {rv_latest} · Thirdsite: {ts_latest}",
                         style={"fontSize":"10px","opacity":"0.75","marginTop":"3px"}),
            ]),
            html.Div([
                html.Div([html.Div(f"{latest_vault} TB",style={"fontSize":"20px","fontWeight":"700"}),
                          html.Div(f"Vault ({rv_latest})",style={"fontSize":"9px","opacity":"0.8","marginTop":"1px"}),
                          html.Div(f"{pct_used}% of license",style={"fontSize":"9px","opacity":"0.7"})],
                         style={"background":"rgba(255,255,255,0.15)","borderRadius":"6px",
                                "padding":"6px 12px","textAlign":"center"}),
                html.Div([html.Div(f"{peak_row[1]} TB",style={"fontSize":"20px","fontWeight":"700"}),
                          html.Div("Peak ever",style={"fontSize":"9px","opacity":"0.8","marginTop":"1px"}),
                          html.Div(str(peak_row[0]),style={"fontSize":"9px","opacity":"0.7"})],
                         style={"background":"rgba(255,255,255,0.15)","borderRadius":"6px",
                                "padding":"6px 12px","textAlign":"center"}),
                html.Div([html.Div("910 TB",style={"fontSize":"20px","fontWeight":"700"}),
                          html.Div("License cap",style={"fontSize":"9px","opacity":"0.8","marginTop":"1px"}),
                          html.Div("85% = 773.5 TB",style={"fontSize":"9px","opacity":"0.7"})],
                         style={"background":"rgba(255,255,255,0.15)","borderRadius":"6px",
                                "padding":"6px 12px","textAlign":"center"}),
            ], style={"display":"flex","gap":"8px","flexWrap":"wrap"}),
        ], style={"display":"flex","alignItems":"center","justifyContent":"space-between",
                  "flexWrap":"wrap","gap":"10px","marginBottom":"12px"}),
        html.Div([
            html.Div(f"{latest_vault} / 910 TB — {pct_used}% {s_label}",
                     style={"display":"flex","justifyContent":"space-between",
                            "fontSize":"10px","opacity":"0.9","marginBottom":"4px"}),
            html.Div([
                html.Div(style={"width":f"{bar_pct}%","height":"100%","background":bar_c,"borderRadius":"4px"}),
                html.Div(style={"position":"absolute","top":"0","left":"85%","width":"2px",
                                "height":"100%","background":"rgba(255,255,255,0.5)"}),
            ], style={"height":"8px","background":"rgba(255,255,255,0.2)","borderRadius":"4px",
                      "overflow":"hidden","position":"relative"}),
            html.Div(["0 TB",html.Span("↑ 85% = 773.5 TB",style={"position":"absolute","left":"85%","transform":"translateX(-50%)"}),
                      "910 TB"],
                     style={"display":"flex","justifyContent":"space-between","fontSize":"9px",
                            "opacity":"0.55","marginTop":"2px","position":"relative"}),
        ]),
    ], style={"background":"linear-gradient(135deg,#1e3a5f,#185FA5)","borderRadius":"10px",
              "padding":"14px 18px","marginBottom":"14px","color":"#fff"})

    # ── KPI row ───────────────────────────────────────────────────────────
    kpis = html.Div([
        html.Div([html.Div("Latest",style={"fontSize":"10px","textTransform":"uppercase","letterSpacing":"0.5px","fontWeight":"500","color":"#64748b","marginBottom":"3px"}),
                  html.Div(f"{latest_vault} TB",style={"fontSize":"20px","fontWeight":"500","lineHeight":"1","color":s_color}),
                  html.Div(f"{pct_used}% of 910 TB",style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                 style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 12px",
                        "borderLeft":f"3px solid {s_color}"}),
        html.Div([html.Div("Days over license",style={"fontSize":"10px","textTransform":"uppercase","letterSpacing":"0.5px","fontWeight":"500","color":"#64748b","marginBottom":"3px"}),
                  html.Div(str(days_over),style={"fontSize":"20px","fontWeight":"500","lineHeight":"1","color":"#A32D2D" if days_over>0 else "#3B6D11"}),
                  html.Div(f"of {len(trend)} days tracked",style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                 style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 12px"}),
        html.Div([html.Div("Days above 85%",style={"fontSize":"10px","textTransform":"uppercase","letterSpacing":"0.5px","fontWeight":"500","color":"#64748b","marginBottom":"3px"}),
                  html.Div(str(days_above),style={"fontSize":"20px","fontWeight":"500","lineHeight":"1","color":"#854F0B" if days_above>5 else "#3B6D11"}),
                  html.Div("threshold breaches",style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                 style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 12px"}),
        html.Div([html.Div("Peak ever",style={"fontSize":"10px","textTransform":"uppercase","letterSpacing":"0.5px","fontWeight":"500","color":"#64748b","marginBottom":"3px"}),
                  html.Div(f"{peak_row[1]} TB",style={"fontSize":"20px","fontWeight":"500","lineHeight":"1","color":"#A32D2D"}),
                  html.Div(str(peak_row[0]),style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                 style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 12px",
                        "borderLeft":"3px solid #A32D2D"}),
        html.Div([html.Div("Headroom",style={"fontSize":"10px","textTransform":"uppercase","letterSpacing":"0.5px","fontWeight":"500","color":"#64748b","marginBottom":"3px"}),
                  html.Div(f"{round(LICENSE-latest_vault,1)} TB",style={"fontSize":"20px","fontWeight":"500","lineHeight":"1","color":_pc(latest_vault)}),
                  html.Div("to license cap",style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                 style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 12px"}),
        html.Div([html.Div("Next full backup",style={"fontSize":"10px","textTransform":"uppercase","letterSpacing":"0.5px","fontWeight":"500","color":"#64748b","marginBottom":"3px"}),
                  html.Div(_next_sat_str,style={"fontSize":"20px","fontWeight":"500","lineHeight":"1","color":"#1e3a5f"}),
                  html.Div(f"18:00 → {_next_mon_str}",style={"fontSize":"10px","color":"#64748b","marginTop":"3px"})],
                 style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 12px"}),
    ], style={"display":"grid","gridTemplateColumns":"repeat(auto-fit,minmax(100px,1fr))",
              "gap":"8px","marginBottom":"14px"})

    # ── Tab 1: Trend ──────────────────────────────────────────────────────
    trend_tab = html.Div([
        html.Div([
            html.Div("Recovery vault — all days tracked · 910 TB license · 85% = 773.5 TB",
                     style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"8px"}),
            html.Div(id="rv-trend-chart",
                     children=html.Div("Loading chart...",
                                       style={"color":"#94a3b8","fontSize":"11px","padding":"20px","maxWidth":"1400px","margin":"0 auto"})),
            html.Div([
                html.Span([html.Span(style={"display":"inline-block","width":"12px","height":"2px",
                                            "background":"#185FA5","verticalAlign":"middle","marginRight":"4px"}),
                           "Vault used"]),
                html.Span([html.Span(style={"display":"inline-block","width":"12px","height":"2px",
                                            "background":"#A32D2D","verticalAlign":"middle","marginRight":"4px"}),
                           "910 TB license"]),
                html.Span([html.Span(style={"display":"inline-block","width":"12px","height":"0",
                                            "borderTop":"2px dashed #E24B4A","verticalAlign":"middle","marginRight":"4px"}),
                           "85% threshold"]),
                html.Span(f"{days_over} days over",style={"background":"#FCEBEB","color":"#A32D2D",
                           "padding":"1px 8px","borderRadius":"4px","fontSize":"10px"}),
                html.Span(f"{days_above} days above 85%",style={"background":"#FAEEDA","color":"#854F0B",
                           "padding":"1px 8px","borderRadius":"4px","fontSize":"10px"}),
            ], style={"display":"flex","flexWrap":"wrap","gap":"12px","marginTop":"8px","fontSize":"11px","color":"#64748b"}),
            html.Div([
                "⚠ ",
                html.Strong("Compliance: "),
                f"Vault breached 910 TB license on {days_over} days (peak {peak_row[1]} TB on {peak_row[0]}). "
                f"WORM expiry on Apr 10 reduced usage by ~284 TB. "
                f"Current {latest_vault} TB ({pct_used}%) — next full backup cycle Sat 02 May will test capacity.",
            ], style={"background":"#FAEEDA","borderLeft":"3px solid #FAC775","padding":"8px 12px",
                      "borderRadius":"0 6px 6px 0","fontSize":"11px","color":"#854F0B","marginTop":"10px"}),
        ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px","padding":"14px","background":"#fff"}),
    ])

    # ── Tab 2: Daily updates ──────────────────────────────────────────────
    # Build daily table rows grouped by date
    daily_rows = []
    daily_dates = sorted(set(r[0] for r in daily_db), reverse=True)
    for dt in daily_dates:
        day_rows = [r for r in daily_db if r[0] == dt]
        fleet_rv = round(sum(r[2] or 0 for r in day_rows), 3)
        fleet_pct = round(fleet_rv / LICENSE * 100, 1)
        fc = _pc(fleet_rv)
        # Date group header row
        daily_rows.append(html.Tr([
            html.Td([
                html.Strong(dt, style={"color":"#1e3a5f"}),
                html.Span(f" · Fleet: ",style={"color":"#64748b","fontSize":"10px"}),
                html.Span(f"{fleet_rv} TB ({fleet_pct}%)",
                          style={"color":fc,"fontWeight":"600","fontSize":"10px"}),
                (html.Span(" 🚨 OVER LICENSE",
                           style={"background":"#FCEBEB","color":"#A32D2D",
                                  "fontSize":"9px","padding":"1px 6px",
                                  "borderRadius":"3px","marginLeft":"6px"})
                 if fleet_rv > LICENSE
                 else html.Span(" ⚠ ABOVE 85%",
                                style={"background":"#FAEEDA","color":"#854F0B",
                                       "fontSize":"9px","padding":"1px 6px",
                                       "borderRadius":"3px","marginLeft":"6px"})
                 if fleet_rv > THRESHOLD else ""),
            ], colSpan=8,
               style={"padding":"6px 10px","background":"#f0f4fa",
                      "fontSize":"10px","fontWeight":"500"}),
        ]))
        # Per-server rows for this date
        for r in sorted(day_rows, key=lambda x: -(x[2] or 0)):
            rv   = r[2] or 0
            ts   = round(float(r[3] or 0), 3)
            dlta = round(float(r[4] or 0), 3)
            dd   = round(float(r[5] or 0), 1)
            worm = int(r[6] or 0)
            q    = int(r[7] or 0)
            dc   = "#A32D2D" if dlta > 0.01 else "#3B6D11" if dlta < -0.01 else "#94a3b8"
            ds   = f"+{dlta:.3f} TB" if dlta > 0.01 else f"{dlta:.3f} TB" if dlta < -0.01 else "—"
            daily_rows.append(html.Tr([
                html.Td(r[1].replace("cbkms",""),
                        style={"padding":"5px 10px 5px 20px","fontFamily":"monospace",
                               "fontSize":"10px","fontWeight":"600"}),
                html.Td(REGIONS.get(r[1],""),
                        style={"padding":"5px 10px","fontSize":"10px","color":"#64748b"}),
                html.Td(f"{rv:.3f} TB",
                        style={"padding":"5px 10px","textAlign":"right",
                               "fontWeight":"600","color":"#185FA5"}),
                html.Td(ds, style={"padding":"5px 10px","textAlign":"right",
                                   "fontWeight":"500","color":dc}),
                html.Td(f"{ts:.3f} TB" if ts else "—",
                        style={"padding":"5px 10px","textAlign":"right","color":"#64748b"}),
                html.Td(f"{dd}%" if dd else "—",
                        style={"padding":"5px 10px","textAlign":"right"}),
                html.Td(f"{worm}d" if worm else "—",
                        style={"padding":"5px 10px","textAlign":"right","color":"#3B6D11"}),
                html.Td(str(q) if q else "—",
                        style={"padding":"5px 10px","textAlign":"right",
                               "color":"#A32D2D" if q>500 else "#854F0B" if q>50 else "#94a3b8"}),
            ], style={"borderBottom":"0.5px solid #f1f5f9"}))

    daily_tab = html.Div([
        html.Div("📅 Daily vault updates — server-wise · Recovery pool TB + 3rd-site · last 14 days",
                 style={"fontSize":"11px","color":"#64748b","background":"#f0f4fa",
                        "borderRadius":"6px","padding":"8px 12px","marginBottom":"10px"}),
        html.Div([
            html.Div("Daily vault — server breakdown",
                     style={"fontSize":"12px","fontWeight":"500",
                            "color":"#1e3a5f","marginBottom":"10px"}),
            html.Table([
                html.Thead(html.Tr([
                    html.Th("Server",style=th),
                    html.Th("Region",style=th),
                    html.Th("Recovery pool TB",style=thr),
                    html.Th("Day delta",style=thr),
                    html.Th("3rd-site TB",style=thr),
                    html.Th("Dedup %",style=thr),
                    html.Th("WORM",style=thr),
                    html.Th("Dup queue",style=thr),
                ])),
                html.Tbody(daily_rows if daily_rows else [
                    html.Tr(html.Td("No daily data available",
                                    colSpan=8,
                                    style={"padding":"12px","color":"#94a3b8",
                                           "textAlign":"center","fontSize":"11px"}))
                ]),
            ], style={"width":"100%","borderCollapse":"collapse",
                      "border":"0.5px solid #e2e8f0","borderRadius":"8px",
                      "overflow":"hidden"}),
            html.Div("Recovery pool TB = diskpool_daily Recovery Vault · "
                     "3rd-site TB = thirdsite_summary · "
                     "Fleet % = sum all pools / 910 TB license",
                     style={"fontSize":"10px","color":"#94a3b8","marginTop":"6px"}),
        ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px",
                  "padding":"14px","background":"#fff"}),
    ])

    # ── Tab 3: Monthly Sat-Sat ─────────────────────────────────────────────
    # Fleet monthly table
    fleet_rows = []
    for w in wk_hist:
        pp  = round(w["rv_peak"]/LICENSE*100,1) if w["rv_peak"] else 0
        cc  = _pc(w["rv_peak"])
        bg  = "#FCEBEB" if w["rv_peak"]>LICENSE else "#FAEEDA" if w["rv_peak"]>THRESHOLD else ("#f0f9ff" if w["is_current"] else "#fff")
        al  = (pill("BREACH","danger") if w["rv_peak"]>LICENSE
               else pill("ABOVE 85%","warning") if w["rv_peak"]>THRESHOLD
               else pill("OK","success"))
        fleet_rows.append(html.Tr([
            html.Td(w["lbl"].split("(")[0].strip(),
                    style={"padding":"6px 10px","fontWeight":"600","color":cc}),
            html.Td(f"Sat {w['ws']} – Fri {w['we']}",
                    style={"padding":"6px 10px","fontSize":"10px","color":"#64748b"}),
            html.Td(f"{w['rv_peak']} TB",
                    style={"padding":"6px 10px","textAlign":"right","fontWeight":"700","color":cc}),
            html.Td(f"{w['rv_min']} TB",
                    style={"padding":"6px 10px","textAlign":"right","color":"#64748b"}),
            html.Td([html.Span(f"{pp}%",style={"fontWeight":"600","color":cc}),_pbar(pp,cc)],
                    style={"padding":"6px 10px","textAlign":"right"}),
            html.Td(f"+{w['vault_in']} TB",
                    style={"padding":"6px 10px","textAlign":"right","color":"#3B6D11"}),
            html.Td(f"{w['dedup']}%" if w["dedup"] else "—",
                    style={"padding":"6px 10px","textAlign":"right"}),
            html.Td(al,style={"padding":"6px 10px"}),
        ], style={"borderBottom":"0.5px solid #f1f5f9","background":bg}))

    monthly_tab = html.Div([
        html.Div([
            html.Div("Fleet — 5 Sat-Sat weeks · Peak recovery vault vs 910 TB license",
                     style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"10px"}),
            html.Table([
                html.Thead(html.Tr([
                    html.Th("Week",style=th),html.Th("Window",style=th),
                    html.Th("Peak vault TB",style=thr),html.Th("Min vault TB",style=thr),
                    html.Th("License %",style=thr),html.Th("Vault-in TB",style=thr),
                    html.Th("Avg dedup",style=thr),html.Th("Alert",style=th),
                ])),
                html.Tbody(fleet_rows),
            ], style={"width":"100%","borderCollapse":"collapse","border":"0.5px solid #e2e8f0",
                      "borderRadius":"8px","overflow":"hidden"}),
            html.Iframe(
                id="rv-fleet-iframe",
                style={"width":"100%","border":"none","height":"200px","marginTop":"12px"},
                srcDoc=(lambda wh=wk_hist: f"""<!DOCTYPE html><html><head>
<script src="/assets/chart.umd.js"></script>
<style>*{{box-sizing:border-box;margin:0;padding:0;}}</style></head><body>
<canvas id="fc" style="width:100%;height:190px;"></canvas>
<script>
var peaks={[w['rv_peak'] for w in reversed(wh)]};
var vis={[w['vault_in'] for w in reversed(wh)]};
var labels={['"'+w['lbl'].split('(')[0].strip()+'"' for w in reversed(wh)]};
var L={LICENSE},T={THRESHOLD};
var bc=peaks.map(function(v){{return v>L?'rgba(227,75,74,0.7)':v>T?'rgba(186,116,23,0.7)':'rgba(24,95,165,0.6)';}});
new Chart(document.getElementById('fc'),{{type:'bar',data:{{labels:labels,datasets:[
  {{label:'Peak vault TB',data:peaks,backgroundColor:bc,borderRadius:4,yAxisID:'y'}},
  {{label:'Vault-in TB',data:vis,backgroundColor:'rgba(99,153,34,0.5)',borderRadius:4,yAxisID:'y'}},
  {{label:'910 TB cap',data:labels.map(function(){{return L;}}),type:'line',borderColor:'#A32D2D',borderDash:[4,3],borderWidth:2,pointRadius:0,fill:false,yAxisID:'y'}},
  {{label:'85% line',data:labels.map(function(){{return T;}}),type:'line',borderColor:'#E24B4A',borderDash:[5,4],borderWidth:1.5,pointRadius:0,fill:false,yAxisID:'y'}},
]}},options:{{responsive:true,maintainAspectRatio:false,
  plugins:{{legend:{{labels:{{font:{{size:10}},boxWidth:8}}}}}},
  scales:{{y:{{ticks:{{font:{{size:10}},callback:function(v){{return v+' TB';}}}}}}}}
}}}});
</script></body></html>""")()
            ),
        ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px","padding":"14px",
                  "background":"#fff","marginBottom":"12px"}),
        html.Div([
            html.Div("Per-server breakdown — 5 weeks",
                     style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"10px"}),
            html.Iframe(
                id="rv-srv-monthly-iframe",
                style={"width":"100%","border":"none","height":"320px"},
                srcDoc=_build_srv_selector_iframe(srv_wk_js, LICENSE),
            ),
        ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px","padding":"14px","background":"#fff"}),
    ])

    # ── Tab 4: Vault pools ────────────────────────────────────────────────
    pool_rows = []
    total_pool = sum(r[2] for r in pools_db)
    for srv, pool, used, status in pools_db:
        lp = round(used/LICENSE*100,1)
        cc = _pc(used)
        short = pool.replace("-az-cool-immu-rvlt-ltr-uk-dp","…-rvlt")
        pool_rows.append(html.Tr([
            html.Td(srv,style={"padding":"6px 10px","fontFamily":"monospace","fontSize":"10px"}),
            html.Td(short,style={"padding":"6px 10px","fontSize":"10px","color":"#64748b",
                                  "maxWidth":"180px","overflow":"hidden","textOverflow":"ellipsis",
                                  "whiteSpace":"nowrap"}),
            html.Td(f"{used} TB",style={"padding":"6px 10px","textAlign":"right","fontWeight":"600"}),
            html.Td("8,192 TB",style={"padding":"6px 10px","textAlign":"right","color":"#64748b"}),
            html.Td([html.Span(f"{lp}%",style={"fontWeight":"600","color":cc}),_pbar(lp,cc,80)],
                    style={"padding":"6px 10px","textAlign":"right"}),
            html.Td(pill(status, "success" if status=="Up" else "warning"),
                    style={"padding":"6px 10px"}),
        ], style={"borderBottom":"0.5px solid #f1f5f9",
                  "background":"#FAEEDA" if status=="Down" else "#fff"}))
    total_lp = round(total_pool/LICENSE*100,1)
    pool_rows.append(html.Tr([
        html.Td("TOTAL",colSpan=2,style={"padding":"8px 10px","fontWeight":"700","background":"#f8fafc"}),
        html.Td(f"{round(total_pool,3)} TB",style={"padding":"8px 10px","textAlign":"right","fontWeight":"700","color":"#185FA5","background":"#f8fafc"}),
        html.Td("910 TB",style={"padding":"8px 10px","textAlign":"right","color":"#64748b","background":"#f8fafc"}),
        html.Td([html.Span(f"{total_lp}%",style={"fontWeight":"700","fontSize":"14px","color":_pc(total_pool)}),
                 _pbar(total_lp,_pc(total_pool),80)],
                style={"padding":"8px 10px","textAlign":"right","background":"#f8fafc"}),
        html.Td(pill(f"{sum(1 for r in pools_db if r[3]=='Up')}/{len(pools_db)} UP","success"),
                style={"padding":"8px 10px","background":"#f8fafc"}),
    ]))
    pools_tab = html.Div([
        html.Div(f"📅 Physical recovery vault pools — {rv_latest} snapshot · 910 TB combined license",
                 style={"fontSize":"11px","color":"#64748b","background":"#f0f4fa",
                        "borderRadius":"6px","padding":"8px 12px","marginBottom":"10px"}),
        html.Div([
            html.Div(f"Physical recovery vault pools — {rv_latest}",
                     style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"10px"}),
            html.Table([
                html.Thead(html.Tr([
                    html.Th("Server",style=th),html.Th("Pool",style=th),
                    html.Th("Used TB",style=thr),html.Th("Pool cap",style=thr),
                    html.Th("% of license",style=thr),html.Th("Status",style=th),
                ])),
                html.Tbody(pool_rows),
            ], style={"width":"100%","borderCollapse":"collapse","border":"0.5px solid #e2e8f0",
                      "borderRadius":"8px","overflow":"hidden"}),
        ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px","padding":"14px","background":"#fff"}),
    ])

    # ── Tab 5: This week ──────────────────────────────────────────────────
    week_srv_rows = []
    fleet_rv_wk = sum(r[1] or 0 for r in srv_week)
    fleet_vi_wk = sum((r[2] or 0) for r in srv_week)
    for srv, rv_peak, vi, dd, worm in srv_week:
        ts_r = next((r for r in ts_rows_db if r[0]==srv), None)
        vt   = ts_r[1] if ts_r else 0
        lp   = round(rv_peak/LICENSE*100,1)
        cc   = _pc(rv_peak)
        week_srv_rows.append(html.Tr([
            html.Td(srv,style={"padding":"6px 10px","fontFamily":"monospace","fontSize":"10px","fontWeight":"600"}),
            html.Td(REGIONS.get(srv,""),style={"padding":"6px 10px","fontSize":"10px","color":"#64748b"}),
            html.Td(f"{vt} TB" if vt else "—",
                    style={"padding":"6px 10px","textAlign":"right","fontWeight":"600","color":"#185FA5"}),
            html.Td(f"+{vi:.3f} TB" if vi else "—",
                    style={"padding":"6px 10px","textAlign":"right","color":"#3B6D11","fontWeight":"500"}),
            html.Td(f"{rv_peak} TB",style={"padding":"6px 10px","textAlign":"right","fontWeight":"600"}),
            html.Td([html.Span(f"{lp}%",style={"fontWeight":"600","color":cc}),_pbar(lp,cc,60)],
                    style={"padding":"6px 10px","textAlign":"right"}),
            html.Td(f"{dd}%" if dd else "—",style={"padding":"6px 10px","textAlign":"right"}),
            html.Td(f"{int(worm)}d" if worm else "—",
                    style={"padding":"6px 10px","textAlign":"right","color":"#3B6D11","fontWeight":"500"}),
        ], style={"borderBottom":"0.5px solid #f1f5f9"}))
    fleet_lp_wk = round(fleet_rv_wk/LICENSE*100,1)
    week_srv_rows.append(html.Tr([
        html.Td("FLEET TOTAL",colSpan=2,
                style={"padding":"7px 10px","fontWeight":"700","background":"#f8fafc"}),
        html.Td(f"{round(sum(r[1] for r in ts_rows_db),3)} TB",
                style={"padding":"7px 10px","textAlign":"right","fontWeight":"700","color":"#185FA5","background":"#f8fafc"}),
        html.Td(f"+{round(fleet_vi_wk,3)} TB",
                style={"padding":"7px 10px","textAlign":"right","fontWeight":"700","color":"#3B6D11","background":"#f8fafc"}),
        html.Td(f"{round(fleet_rv_wk,3)} TB",
                style={"padding":"7px 10px","textAlign":"right","fontWeight":"700","background":"#f8fafc"}),
        html.Td([html.Span(f"{fleet_lp_wk}%",style={"fontWeight":"700","color":_pc(fleet_rv_wk)}),
                 _pbar(fleet_lp_wk,_pc(fleet_rv_wk),60)],
                style={"padding":"7px 10px","textAlign":"right","background":"#f8fafc"}),
        html.Td(colSpan=2,style={"background":"#f8fafc"}),
    ]))

    week_tab = html.Div([
        html.Div(f"📅 Current week: Sat {ws} → Fri {we} · {(rv_dt-curr_sat).days+1} days data · DB: {rv_latest}",
                 style={"fontSize":"11px","color":"#64748b","background":"#f0f4fa",
                        "borderRadius":"6px","padding":"8px 12px","marginBottom":"10px"}),
        html.Div([
            html.Div(f"Week {ws} – {we} · 3rd-site duplication + recovery pool correlation",
                     style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f","marginBottom":"10px"}),
            html.Table([
                html.Thead(html.Tr([
                    html.Th("Server",style=th),html.Th("Region",style=th),
                    html.Th("3rd-site TB",style=thr),html.Th("Week vault-in",style=thr),
                    html.Th("Recovery pool",style=thr),html.Th("License %",style=thr),
                    html.Th("Avg dedup",style=thr),html.Th("WORM",style=thr),
                ])),
                html.Tbody(week_srv_rows),
            ], style={"width":"100%","borderCollapse":"collapse","border":"0.5px solid #e2e8f0",
                      "borderRadius":"8px","overflow":"hidden"}),
            html.Div("* 3rd-site TB = thirdsite_summary latest · Vault-in = sum positive delta_tb · Recovery pool = diskpool_daily Recovery Vault max",
                     style={"fontSize":"10px","color":"#94a3b8","marginTop":"6px"}),
        ], style={"border":"0.5px solid #e2e8f0","borderRadius":"10px","padding":"14px","background":"#fff"}),
    ])

    # ── Tabs container ────────────────────────────────────────────────────
    tab_contents = dcc.Tabs([
        dcc.Tab(label="📈 Trend",       children=[html.Div(trend_tab,   style={"paddingTop":"12px"})],
                style={"fontSize":"11px"}, selected_style={"fontSize":"11px"}),
        dcc.Tab(label="📅 Daily",       children=[html.Div(daily_tab,   style={"paddingTop":"12px"})],
                style={"fontSize":"11px"}, selected_style={"fontSize":"11px"}),
        dcc.Tab(label="📆 Monthly",     children=[html.Div(monthly_tab, style={"paddingTop":"12px"})],
                style={"fontSize":"11px"}, selected_style={"fontSize":"11px"}),
        dcc.Tab(label="🗄️ Vault Pools", children=[html.Div(pools_tab,   style={"paddingTop":"12px"})],
                style={"fontSize":"11px"}, selected_style={"fontSize":"11px"}),
        dcc.Tab(label="📊 This Week",   children=[html.Div(week_tab,    style={"paddingTop":"12px"})],
                style={"fontSize":"11px","fontWeight":"600"}, selected_style={"fontSize":"11px","fontWeight":"600"}),
    ], style={"fontSize":"11px"})

    # ── Iframe for JS charts ──────────────────────────────────────────────
    iframe_src = f"""<!DOCTYPE html><html><head>
<script src="/assets/chart.umd.js"></script>
<style>*{{box-sizing:border-box;font-family:system-ui,sans-serif;margin:0;padding:0;}}
canvas{{width:100%!important;}}</style></head><body>
<canvas id="tc" style="width:100%;height:240px;"></canvas>
<script>
const TR={trend_js};
const L={LICENSE},T={THRESHOLD};
const labels=TR.map(function(r){{return r.d;}});
const vals=TR.map(function(r){{return r.v;}});
new Chart(document.getElementById("tc"),{{type:"line",data:{{labels:labels,datasets:[
  {{label:"Vault TB",data:vals,borderWidth:2.5,pointRadius:2,tension:0.3,fill:true,
   backgroundColor:vals.map(function(v){{return v>L?"rgba(227,75,74,0.2)":v>T?"rgba(186,116,23,0.1)":"rgba(24,95,165,0.1)"}}),
   segment:{{borderColor:function(c){{var v=vals[c.p1DataIndex];return v>L?"#E24B4A":v>T?"#BA7517":"#185FA5";}}}}}},
  {{label:"910TB cap",data:labels.map(function(){{return L;}}),borderColor:"#A32D2D",borderWidth:1.5,pointRadius:0,fill:false,borderDash:[4,3]}},
  {{label:"85% line",data:labels.map(function(){{return T;}}),borderColor:"#E24B4A",borderWidth:1,pointRadius:0,fill:false,borderDash:[6,4]}},
]}},options:{{responsive:true,maintainAspectRatio:false,
  plugins:{{legend:{{labels:{{font:{{size:10}},boxWidth:10}}}}}},
  scales:{{x:{{ticks:{{font:{{size:9}},maxRotation:45,autoSkip:true,maxTicksLimit:15}}}},
           y:{{min:400,ticks:{{font:{{size:10}},callback:function(v){{return v+" TB";}}}}}}}}}}}});
</script></body></html>"""

    return html.Div([
        date_banner("DB last update", rv_latest, f"thirdsite: {ts_latest} · License: 910 TB"),
        alert,
        banner,
        kpis,
        tab_contents,
        html.Iframe(srcDoc=iframe_src,
                    style={"width":"100%","border":"none","height":"280px",
                           "marginTop":"12px"}),
        html.Div(id="rv-trend-data",   style={"display":"none"}, children=trend_js),
        html.Div(id="rv-daily-data",   style={"display":"none"}, children=daily_js),
        html.Div(id="rv-srv-wk-data",  style={"display":"none"}, children=srv_wk_str),
        html.Div(
            f"DB: {rv_latest} · Thirdsite: {ts_latest} · diskpool sync: 17:00 · License: 910 TB combined",
            style={"fontSize":"10px","color":"#94a3b8","textAlign":"right","marginTop":"6px"}),
    ], style={"padding":"16px"})



# ══════════════════════════════════════════════════════════════════════════════
# TAB 5: CATALOG
# ══════════════════════════════════════════════════════════════════════════════
def tab_catalog(master_f='all'):
    df=qdf(DB_CATALOG,"SELECT server,timestamp AS checked_at,catalog_date,catalog_size_gb,catalog_status,vvr_status,health_score,anomaly_detected,anomaly_reason FROM health_records ORDER BY timestamp DESC")
    if df.empty: return html.Div("No catalog data.",style={"padding":"24px","color":"#E24B4A"})
    tod=df.drop_duplicates("server",keep="first"); total=len(tod)
    success=int((tod["catalog_status"]=="SUCCESS").sum()); delayed=int((tod["catalog_status"]=="DELAYED").sum())
    errors=int((tod["catalog_status"]=="ERROR").sum()); avg_s=round(tod["health_score"].mean(),1); latest=df["checked_at"].max()
    tod_s=tod.sort_values("health_score")
    fig=go.Figure(); fig.add_trace(go.Bar(x=tod_s["server"],y=tod_s["health_score"],marker_color=[_pct_color(s) for s in tod_s["health_score"]],text=tod_s["health_score"].round(0).astype(int),textposition="outside",textfont=dict(size=9)))
    fig.add_hline(y=80,line_dash="dash",line_color="#639922",annotation_text="80",annotation_font_size=9)
    fig.add_hline(y=60,line_dash="dash",line_color="#EF9F27",annotation_text="60",annotation_font_size=9)
    fig.update_layout(title=None,height=260,margin=dict(t=10,b=40,l=10,r=10),plot_bgcolor="#fafafa",paper_bgcolor="#fafafa",xaxis=dict(tickfont=dict(size=9)),yaxis=dict(gridcolor="#f0f0f0",tickfont=dict(size=9)))
    def cat_rows(df):
        rows=[]
        for _,r in df.sort_values("health_score").iterrows():
            s=r["health_score"]; bg="#fff0f0" if s<60 else "#fff8ec" if s<80 else None
            rows.append(("_color",bg,[r["server"],pill(r["catalog_status"],_status_color(r["catalog_status"])),mini_bar(s),str(r["catalog_date"])[:10] if r["catalog_date"] else "—",f"{r.get('catalog_size_gb',0):.1f} GB",r.get("vvr_status","—"),pill("Yes","danger") if r.get("anomaly_detected") else pill("No","secondary"),html.Span(str(r.get("anomaly_reason",""))[:60],style={"fontSize":"9px","color":"#888"})]))
        return rows
    return html.Div([date_banner("Latest check",str(latest)[:19],f"{total} servers"),
        dbc.Row([dbc.Col(kpi_card("✅ Success",f"{success}/{total}","#639922"),md=3),dbc.Col(kpi_card("🟡 Delayed",delayed,"#EF9F27"),md=3),dbc.Col(kpi_card("🔴 Errors",errors,"#E24B4A"),md=3),dbc.Col(kpi_card("📊 Avg score",avg_s,BRAND),md=3)],className="mb-3 g-2"),
        html.Div("Backup Health Index per server",style={"fontSize":"11px","fontWeight":"500","color":"#888","marginBottom":"6px"}),
        dcc.Graph(figure=fig,config={"displayModeBar":False}),html.Div(style={"height":"16px"}),
        rich_table(["Server","Status","Health score","Catalog date","Size GB","VVR","Anomaly","Reason"],cat_rows(tod))],style={"padding":"24px"})


# ══════════════════════════════════════════════════════════════════════════════
# TAB 6: AIRGAP
# ══════════════════════════════════════════════════════════════════════════════
def tab_airgap(master_f='all'):
    df=qdf(DB_AIRGAP,"SELECT server,timestamp AS checked_at,air_master,image_count,backup_date,status,replication_active FROM replication_status ORDER BY timestamp DESC")
    if df.empty: return html.Div("No airgap data.",style={"padding":"24px","color":"#E24B4A"})
    tod=df.drop_duplicates("server",keep="first"); backlog=int(tod["image_count"].sum())
    completed=int((tod["status"]=="Completed").sum()); working=int((tod["status"]=="Working").sum()); failed=len(tod)-completed-working; latest=df["checked_at"].max()
    ret_df=qdf(DB_AIRGAP,"SELECT server,weekly_compliant,monthly_compliant,yearly_compliant,weekly_backups,monthly_backups,yearly_backups FROM retention_compliance rc1 WHERE timestamp=(SELECT MAX(timestamp) FROM retention_compliance WHERE server=rc1.server)")
    ret_ok=0; ret_warn=0
    if not ret_df.empty:
        ret_ok=int(((ret_df["weekly_compliant"]==1)&(ret_df["monthly_compliant"]==1)&(ret_df["yearly_compliant"]==1)).sum()); ret_warn=len(ret_df)-ret_ok
    fb=go.Figure(go.Bar(x=tod["server"],y=tod["image_count"],marker_color=[_lag_color(v) for v in tod["image_count"]],text=tod["image_count"].astype(int),textposition="outside",textfont=dict(size=9)))
    fb.update_layout(title=None,height=240,margin=dict(t=10,b=40,l=10,r=10),plot_bgcolor="#fafafa",paper_bgcolor="#fafafa",xaxis=dict(tickfont=dict(size=9)),yaxis=dict(gridcolor="#f0f0f0",tickfont=dict(size=9)))
    fd=go.Figure(go.Pie(labels=["Completed","Working","Failed"],values=[max(completed,0),max(working,0),max(failed,0)],hole=0.58,marker_colors=["#639922","#EF9F27","#E24B4A"],textinfo="percent+label",textfont=dict(size=9)))
    fd.update_layout(title=None,height=240,margin=dict(t=10,b=10,l=10,r=10),paper_bgcolor="#fafafa")
    if not ret_df.empty:
        fr=go.Figure()
        fr.add_trace(go.Bar(name="Weekly",x=ret_df["server"],y=ret_df["weekly_backups"],marker_color="#378ADD"))
        fr.add_trace(go.Bar(name="Monthly",x=ret_df["server"],y=ret_df["monthly_backups"],marker_color="#639922"))
        fr.add_trace(go.Bar(name="Yearly",x=ret_df["server"],y=ret_df["yearly_backups"],marker_color="#EF9F27"))
        fr.update_layout(title=None,barmode="group",height=240,margin=dict(t=10,b=40,l=10,r=10),plot_bgcolor="#fafafa",paper_bgcolor="#fafafa",legend=dict(font=dict(size=9),bgcolor="rgba(0,0,0,0)"),xaxis=dict(tickfont=dict(size=9)),yaxis=dict(gridcolor="#f0f0f0",tickfont=dict(size=9)))
    else:
        fr=go.Figure(); fr.update_layout(title="No retention data",height=240)
    merged=pd.merge(tod,ret_df,on="server",how="left") if not ret_df.empty else tod
    def ag_rows(df):
        rows=[]
        for _,r in df.sort_values("image_count",ascending=False).iterrows():
            wc=r.get("weekly_compliant"); mc=r.get("monthly_compliant"); yc=r.get("yearly_compliant")
            all_ok=bool(wc) and bool(mc) and bool(yc); bg=None if all_ok else "#fff0f0"; st=r.get("status","—")
            rows.append(("_color",bg,[r["server"],pill(st,"success" if st=="Completed" else "warning" if st=="Working" else "danger"),
                html.Span(str(int(r["image_count"])),style={"fontWeight":"500","color":_lag_color(r["image_count"])}),r.get("air_master","—"),
                html.Span(f"{'✓' if wc else '✗'} {int(r['weekly_backups']) if not pd.isna(r.get('weekly_backups',float('nan'))) else 0}",style={"color":"#639922" if wc else "#E24B4A","fontWeight":"500"}),
                html.Span(f"{'✓' if mc else '✗'} {int(r['monthly_backups']) if not pd.isna(r.get('monthly_backups',float('nan'))) else 0}",style={"color":"#639922" if mc else "#E24B4A","fontWeight":"500"}),
                html.Span(f"{'✓' if yc else '✗'} {int(r['yearly_backups']) if not pd.isna(r.get('yearly_backups',float('nan'))) else 0}",style={"color":"#639922" if yc else "#E24B4A","fontWeight":"500"}),
                pill("OK","success") if all_ok else pill("VAULT BREACH","danger")]))
        return rows
    return html.Div([date_banner("Latest check",str(latest)[:19],f"{len(tod)} servers"),
        dbc.Row([dbc.Col(kpi_card("📦 Vault backlog",backlog,"#E24B4A"),md=2),dbc.Col(kpi_card("✅ Vault sync done",completed,"#639922"),md=2),dbc.Col(kpi_card("⟳ Vault syncing",working,"#EF9F27"),md=2),dbc.Col(kpi_card("❌ Failed",failed,"#E24B4A"),md=2),dbc.Col(kpi_card("✓ Vault retention ok",ret_ok,"#639922"),md=2),dbc.Col(kpi_card("⚠️ Vault breaches",ret_warn,"#EF9F27"),md=2)],className="mb-3 g-2"),
        dbc.Row([dbc.Col([html.Div("Backlog per server",style={"fontSize":"11px","fontWeight":"500","color":"#888","marginBottom":"6px"}),dcc.Graph(figure=fb,config={"displayModeBar":False})],md=5),
                 dbc.Col([html.Div("Replication status",style={"fontSize":"11px","fontWeight":"500","color":"#888","marginBottom":"6px"}),dcc.Graph(figure=fd,config={"displayModeBar":False})],md=3),
                 dbc.Col([html.Div("Retention counts",style={"fontSize":"11px","fontWeight":"500","color":"#888","marginBottom":"6px"}),dcc.Graph(figure=fr,config={"displayModeBar":False})],md=4)],className="mb-3"),
        rich_table(["Server","Status","Backlog","Air master","Weekly","Monthly","Yearly","Vault retention"],ag_rows(merged))],style={"padding":"24px"})


# ══════════════════════════════════════════════════════════════════════════════
# AI INSIGHTS HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _insight_severity_bar(sev):
    color={"critical":"#E24B4A","warning":"#EF9F27","healthy":"#639922","info":"#378ADD"}.get(sev,"#ccc")
    return html.Div(style={"width":"3px","borderRadius":"2px","flexShrink":"0","alignSelf":"stretch","minHeight":"40px","background":color})

def _exec_card_head(sev, icon, title, sub, pill_text):
    bg_map={"critical":("#fff0f0","#ffd0d0"),"warning":("#fff8ec","#ffe0b0"),"healthy":("#f0faf0","#c0e0c0"),"info":("#e8f0fe","#c0d4f8")}
    bg,border=bg_map.get(sev,("#f4f4f4","#ddd"))
    return html.Div([html.Span(icon,style={"fontSize":"16px"}),
        html.Div([html.Div(title,style={"fontSize":"12px","fontWeight":"500","color":"#222"}),html.Div(sub,style={"fontSize":"10px","color":"#888","marginTop":"1px"})],style={"flex":"1"}),
        pill(pill_text,{"critical":"danger","warning":"warning","healthy":"success","info":"info"}.get(sev,"secondary"))
    ],style={"padding":"10px 14px","display":"flex","alignItems":"center","gap":"8px","background":bg,"borderBottom":f"0.5px solid {border}"})

def _impact_grid(items):
    cells=[]
    for label,value,color,sub in items:
        cells.append(html.Div([html.Div(label,style={"fontSize":"9px","color":"#888","marginBottom":"3px"}),html.Div(str(value),style={"fontSize":"14px","fontWeight":"500","color":color,"lineHeight":"1"}),html.Div(sub,style={"fontSize":"9px","color":"#aaa","marginTop":"2px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}))
    return html.Div(cells,style={"display":"flex","gap":"8px","marginBottom":"12px"})

def _narrative(text):
    return html.Div(dcc.Markdown(text,dangerously_allow_html=False),
        style={"fontSize":"11px","color":"#444","lineHeight":"1.7","marginBottom":"12px","padding":"10px 12px","background":"#f9f9f9","borderRadius":"6px","borderLeft":f"3px solid {BRAND}"})

def _sec_label(text):
    return html.Div(text,style={"fontSize":"9px","fontWeight":"500","color":"#aaa","textTransform":"uppercase","letterSpacing":"0.8px","marginBottom":"8px","marginTop":"4px"})

def _spark_bar(label,value,max_val,color):
    pct=min((value/max_val*100) if max_val>0 else 0,100)
    return html.Div([html.Span(label,style={"width":"110px","color":"#888","fontSize":"10px","textAlign":"right","flexShrink":"0"}),
        html.Div(html.Div(style={"width":f"{pct}%","height":"100%","borderRadius":"3px","background":color}),style={"flex":"1","height":"6px","background":"#e8e8e8","borderRadius":"3px","overflow":"hidden"}),
        html.Span(str(value),style={"width":"40px","textAlign":"right","fontSize":"10px","fontWeight":"500","color":color})],
        style={"display":"flex","alignItems":"center","gap":"8px","marginBottom":"6px"})

def _rec_card(num, title, detail, action_label, vaultix_query):
    return html.Div([
        html.Div(str(num),style={"width":"20px","height":"20px","borderRadius":"50%","background":BRAND,"color":"#fff","fontSize":"9px","fontWeight":"500","display":"flex","alignItems":"center","justifyContent":"center","flexShrink":"0","marginTop":"1px"}),
        html.Div([html.Div(title,style={"fontSize":"11px","fontWeight":"500","color":"#222","marginBottom":"2px"}),html.Div(detail,style={"fontSize":"10px","color":"#888","lineHeight":"1.4"}),
            html.Div([html.Span("↗ ",style={"color":BRAND}),html.Span(action_label,style={"color":BRAND,"fontSize":"10px"})],
                     style={"marginTop":"4px","cursor":"pointer"},id={"type":"insight_rec_btn","index":vaultix_query[:60]},n_clicks=0)],style={"flex":"1"})
    ],style={"border":"0.5px solid #e0e0e0","borderRadius":"8px","padding":"10px 13px","marginBottom":"8px","display":"flex","gap":"10px","alignItems":"flex-start"})

def _srv_chip(server, query):
    return html.Div([html.Div(style={"width":"6px","height":"6px","borderRadius":"50%","background":"#639922"}),html.Span(server,style={"fontSize":"10px"})],
        id={"type":"insight_srv_chip","index":query[:60]},n_clicks=0,
        style={"padding":"4px 10px","borderRadius":"6px","fontSize":"10px","cursor":"pointer","border":"0.5px solid #d0d0d0","background":"#fff","display":"flex","alignItems":"center","gap":"5px"})


# =============================================================================
# REPORT TAB DRILL-DOWN HELPERS
# =============================================================================

def _rpt_drill_lag():
    df = qdf(DB_UNIFIED,
        "SELECT server_name, date, total, above_sla, "
        "not_started_remote, in_process_remote, "
        "not_started_duplicate, in_process_duplicate "
        "FROM lag_history lh1 "
        "WHERE date=(SELECT MAX(date) FROM lag_history WHERE server_name=lh1.server_name) "
        "ORDER BY total DESC")
    if df.empty:
        return html.Div("No lag data.", style={"padding":"20px","color":"#888"})
    total_lag = int(df["total"].sum())
    breaching = int((df["total"] > SLA_THRESH).sum())
    healthy   = int((df["total"] == 0).sum())
    trend = qdf(DB_UNIFIED,
        "SELECT date, SUM(total) AS fleet_total FROM lag_history "
        "GROUP BY date ORDER BY date DESC LIMIT 30")
    trend = trend.iloc[::-1].reset_index(drop=True)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=trend["date"], y=trend["fleet_total"],
        fill="tozeroy", line=dict(color="#E24B4A", width=1.5),
        fillcolor="rgba(226,75,74,0.12)", mode="lines"))
    fig.add_hline(y=SLA_THRESH, line_dash="dash", line_color="#E24B4A",
                  annotation_text="SLA", annotation_font_size=10)
    fig.update_layout(height=180, margin=dict(t=10,b=20,l=30,r=10),
        plot_bgcolor="#fafafa", paper_bgcolor="#fafafa",
        xaxis=dict(showgrid=False, tickfont=dict(size=9)),
        yaxis=dict(gridcolor="#f0f0f0", tickfont=dict(size=9)))
    rows = []
    for _, r in df.iterrows():
        t = int(r["total"])
        bg = "#fff0f0" if t > SLA_THRESH else "#fff8ec" if t > SLA_THRESH*0.8 else None
        rows.append(("_color", bg, [
            r["server_name"], str(r["date"])[:10],
            int(r.get("not_started_remote",0)), int(r.get("in_process_remote",0)),
            int(r.get("not_started_duplicate",0)), int(r.get("in_process_duplicate",0)),
            html.Span(str(t), style={"fontWeight":"600","color":_lag_color(t)}),
            pill("BREACH","danger") if t>SLA_THRESH
            else pill("NEAR","warning") if t>SLA_THRESH*0.8
            else pill("OK","success"),
        ]))
    return html.Div([
        dbc.Row([
            dbc.Col(kpi_card("Queue Depth", f"{total_lag:,}", "#E24B4A"), md=3),
            dbc.Col(kpi_card("Breaching SLA", breaching, "#E24B4A"), md=3),
            dbc.Col(kpi_card("Healthy", healthy, "#639922"), md=3),
            dbc.Col(kpi_card("SLA Limit", SLA_THRESH, BRAND), md=3),
        ], className="mb-3 g-2"),
        html.Div("30-day fleet queue trend",
                 style={"fontSize":"11px","color":"#888","marginBottom":"6px"}),
        dcc.Graph(figure=fig, config={"displayModeBar":False}),
        html.Div(style={"height":"12px"}),
        rich_table(["Server","Date","NS Remote","IP Remote",
                    "NS Dup","IP Dup","Total","Status"], rows),
    ], style={"padding":"8px"})


def _rpt_drill_dp():
    df = qdf(DB_UNIFIED,
        "SELECT server_name, diskpool, diskpool_group, "
        "ROUND(used_tb,2) AS used_tb, ROUND(total_tb,2) AS total_tb, "
        "ROUND(used_tb*100.0/NULLIF(total_tb,0),1) AS pct_used, health "
        "FROM diskpool_daily dd1 "
        "WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily "
        "WHERE server_name=dd1.server_name) ORDER BY pct_used DESC")
    if df.empty:
        return html.Div("No storage pool data.", style={"padding":"20px","color":"#888"})
    critical = int((df["pct_used"] >= 85).sum())
    warning  = int(((df["pct_used"] >= 70) & (df["pct_used"] < 85)).sum())
    total_u  = round(df["used_tb"].sum(), 2)
    top10 = df.nlargest(10, "pct_used")
    fig = go.Figure(go.Bar(
        x=top10["pct_used"], y=top10["diskpool"], orientation="h",
        marker_color=[_pct_color(p) for p in top10["pct_used"]],
        text=[f"{p}%" for p in top10["pct_used"]],
        textposition="outside", textfont=dict(size=9)))
    fig.update_layout(height=260, margin=dict(t=10,b=10,l=10,r=60),
        plot_bgcolor="#fafafa", paper_bgcolor="#fafafa",
        xaxis=dict(gridcolor="#f0f0f0", tickfont=dict(size=9), range=[0,115]),
        yaxis=dict(tickfont=dict(size=9)))
    rows = []
    for _, r in df.iterrows():
        p = float(r["pct_used"] or 0)
        rows.append(("_color",
            "#fff0f0" if p>=85 else "#fff8ec" if p>=70 else None, [
            r["server_name"], r["diskpool"], r.get("diskpool_group","--"),
            f"{r['used_tb']:.2f}", f"{r['total_tb']:.2f}", mini_bar(p),
            pill("CRITICAL","danger") if p>=85
            else pill("WARNING","warning") if p>=70
            else pill("HEALTHY","success"),
        ]))
    return html.Div([
        dbc.Row([
            dbc.Col(kpi_card("Total Used", f"{total_u} TB", BRAND), md=3),
            dbc.Col(kpi_card("Critical >=85%", critical, "#E24B4A"), md=3),
            dbc.Col(kpi_card("Warning >=70%", warning, "#EF9F27"), md=3),
            dbc.Col(kpi_card("Total Pools", len(df), "#639922"), md=3),
        ], className="mb-3 g-2"),
        html.Div("Top 10 pools by utilisation",
                 style={"fontSize":"11px","color":"#888","marginBottom":"6px"}),
        dcc.Graph(figure=fig, config={"displayModeBar":False}),
        html.Div(style={"height":"12px"}),
        rich_table(["Server","Pool","Group","Used TB","Total TB","% Used","Status"], rows),
    ], style={"padding":"8px"})


def _rpt_drill_3rd():
    df = qdf(DB_UNIFIED,
        "SELECT server_name, report_date, ROUND(total_data_tb,3) AS total_data_tb, "
        "ROUND(avg_dedup_percent,1) AS avg_dedup_percent, "
        "ROUND(avg_gbps,4) AS avg_gbps, ROUND(max_worm_days,0) AS max_worm_days "
        "FROM thirdsite_summary ts1 "
        "WHERE report_date=(SELECT MAX(report_date) FROM thirdsite_summary "
        "WHERE server_name=ts1.server_name) ORDER BY avg_dedup_percent DESC")
    if df.empty:
        return html.Div("No 3rd-site data.", style={"padding":"20px","color":"#888"})
    avg_dd   = round(df["avg_dedup_percent"].mean(), 1)
    total_tb = round(df["total_data_tb"].sum(), 3)
    low_worm = int((df["max_worm_days"] < 30).sum())
    fig = go.Figure(go.Bar(
        x=df["server_name"], y=df["avg_dedup_percent"],
        marker_color=[_pct_color(min(d,100)) for d in df["avg_dedup_percent"]],
        text=[f"{d:.1f}%" for d in df["avg_dedup_percent"]],
        textposition="outside", textfont=dict(size=9)))
    fig.update_layout(height=220, margin=dict(t=10,b=40,l=10,r=10),
        plot_bgcolor="#fafafa", paper_bgcolor="#fafafa",
        xaxis=dict(tickfont=dict(size=9)),
        yaxis=dict(gridcolor="#f0f0f0", tickfont=dict(size=9)))
    rows = []
    for _, r in df.iterrows():
        d = float(r["avg_dedup_percent"]); w = float(r["max_worm_days"])
        rows.append(("_color", "#fff0f0" if d<30 else None, [
            r["server_name"], str(r["report_date"])[:10],
            f"{r['total_data_tb']:.3f}", f"{r['avg_gbps']:.4f}",
            mini_bar(min(d,100)), f"{int(w)}d",
            pill("LOW","danger") if w<30 else pill("OK","success"),
            pill("GOOD","success") if d>=50
            else pill("MODERATE","warning") if d>=30
            else pill("LOW","danger"),
        ]))
    return html.Div([
        dbc.Row([
            dbc.Col(kpi_card("Vaulted", f"{total_tb} TB", BRAND), md=3),
            dbc.Col(kpi_card("Avg Dedup", f"{avg_dd}%", "#639922"), md=3),
            dbc.Col(kpi_card("Servers", len(df), "#378ADD"), md=3),
            dbc.Col(kpi_card("WORM <30d", low_worm, "#E24B4A"), md=3),
        ], className="mb-3 g-2"),
        html.Div("Dedup efficiency per server",
                 style={"fontSize":"11px","color":"#888","marginBottom":"6px"}),
        dcc.Graph(figure=fig, config={"displayModeBar":False}),
        html.Div(style={"height":"12px"}),
        rich_table(["Server","Date","Vaulted TB","GB/s","Dedup %",
                    "WORM","WORM Status","Dedup Status"], rows),
    ], style={"padding":"8px"})


def _rpt_drill_ag():
    rep = qdf(DB_UNIFIED,
        "SELECT server_name, ag_status AS status, "
        "ag_image_count AS image_count, ag_air_master AS air_master, "
        "ag_weekly_ok, ag_monthly_ok, ag_yearly_ok, "
        "ag_weekly_count, ag_monthly_count, ag_yearly_count "
        "FROM v_server_latest ORDER BY server_name")
    if rep.empty:
        return html.Div("No airgap data.", style={"padding":"20px","color":"#888"})
    total_bl   = int(rep["image_count"].fillna(0).sum())
    completed  = int((rep["status"] == "Completed").sum())
    violations = int((~(rep["ag_weekly_ok"].astype(bool) &
                        rep["ag_monthly_ok"].astype(bool) &
                        rep["ag_yearly_ok"].astype(bool))).sum())
    rows = []
    for _, r in rep.iterrows():
        wc = bool(r.get("ag_weekly_ok"))
        mc = bool(r.get("ag_monthly_ok"))
        yc = bool(r.get("ag_yearly_ok"))
        all_ok = wc and mc and yc
        st = str(r.get("status","--"))
        bl = int(r.get("image_count") or 0)
        wct = int(r.get("ag_weekly_count") or 0)
        mct = int(r.get("ag_monthly_count") or 0)
        yct = int(r.get("ag_yearly_count") or 0)
        rows.append(("_color", None if all_ok else "#fff0f0", [
            r["server_name"],
            pill(st, "success" if st=="Completed"
                 else "warning" if st=="Working" else "danger"),
            html.Span(str(bl), style={"fontWeight":"600","color":_lag_color(bl)}),
            r.get("air_master","--"),
            html.Span(("V " if wc else "X ") + str(wct),
                style={"color":"#639922" if wc else "#E24B4A","fontWeight":"500"}),
            html.Span(("V " if mc else "X ") + str(mct),
                style={"color":"#639922" if mc else "#E24B4A","fontWeight":"500"}),
            html.Span(("V " if yc else "X ") + str(yct),
                style={"color":"#639922" if yc else "#E24B4A","fontWeight":"500"}),
            pill("OK","success") if all_ok else pill("BREACH","danger"),
        ]))
    return html.Div([
        dbc.Row([
            dbc.Col(kpi_card("Total Backlog", total_bl, "#E24B4A"), md=3),
            dbc.Col(kpi_card("Completed", completed, "#639922"), md=3),
            dbc.Col(kpi_card("Violations", violations,
                             "#E24B4A" if violations else "#639922"), md=3),
            dbc.Col(kpi_card("Servers", len(rep), BRAND), md=3),
        ], className="mb-3 g-2"),
        rich_table(["Server","Status","Backlog","Air Master",
                    "Weekly","Monthly","Yearly","Retention"], rows),
    ], style={"padding":"8px"})


def _rpt_drill_cat():
    df = qdf(DB_UNIFIED,
        "SELECT server_name, catalog_status, health_score, checked_at, "
        "catalog_date, catalog_size_gb, vvr_status, "
        "anomaly_detected, anomaly_reason "
        "FROM catalog_health ch1 "
        "WHERE checked_at=(SELECT MAX(checked_at) FROM catalog_health "
        "WHERE server_name=ch1.server_name) ORDER BY health_score ASC")
    if df.empty:
        return html.Div("No catalog data.", style={"padding":"20px","color":"#888"})
    success = int((df["catalog_status"]=="SUCCESS").sum())
    errors  = int((df["catalog_status"]=="ERROR").sum())
    delayed = int((df["catalog_status"]=="DELAYED").sum())
    avg_bhi = round(df["health_score"].mean(), 1)
    fig = go.Figure()
    fig.add_trace(go.Bar(x=df["server_name"], y=df["health_score"],
        marker_color=[_pct_color(s) for s in df["health_score"]],
        text=df["health_score"].round(0).astype(int),
        textposition="outside", textfont=dict(size=9)))
    fig.add_hline(y=80, line_dash="dash", line_color="#639922",
                  annotation_text="80", annotation_font_size=9)
    fig.add_hline(y=60, line_dash="dash", line_color="#EF9F27",
                  annotation_text="60", annotation_font_size=9)
    fig.update_layout(height=220, margin=dict(t=10,b=40,l=10,r=10),
        plot_bgcolor="#fafafa", paper_bgcolor="#fafafa",
        xaxis=dict(tickfont=dict(size=9)),
        yaxis=dict(gridcolor="#f0f0f0", tickfont=dict(size=9), range=[0,115]))
    rows = []
    for _, r in df.iterrows():
        s = float(r["health_score"])
        sz = float(r.get("catalog_size_gb") or 0)
        rows.append(("_color",
            "#fff0f0" if s<60 else "#fff8ec" if s<80 else None, [
            r["server_name"],
            pill(r["catalog_status"], _status_color(r["catalog_status"])),
            mini_bar(s), str(r.get("catalog_date","--"))[:10],
            f"{sz:.1f} GB",
            r.get("vvr_status","--"),
            pill("Yes","danger") if r.get("anomaly_detected")
            else pill("No","secondary"),
            html.Span(str(r.get("anomaly_reason",""))[:50],
                      style={"fontSize":"9px","color":"#888"}),
        ]))
    return html.Div([
        dbc.Row([
            dbc.Col(kpi_card("Success", f"{success}/{len(df)}", "#639922"), md=3),
            dbc.Col(kpi_card("Delayed", delayed, "#EF9F27"), md=3),
            dbc.Col(kpi_card("Errors", errors, "#E24B4A"), md=3),
            dbc.Col(kpi_card("Avg BHI", avg_bhi, BRAND), md=3),
        ], className="mb-3 g-2"),
        html.Div("Backup Health Index per server",
                 style={"fontSize":"11px","color":"#888","marginBottom":"6px"}),
        dcc.Graph(figure=fig, config={"displayModeBar":False}),
        html.Div(style={"height":"12px"}),
        rich_table(["Server","Status","BHI","Catalog Date",
                    "Size","VVR","Anomaly","Reason"], rows),
    ], style={"padding":"8px"})


def _rpt_drill_media():
    import sqlite3 as _sq2, pandas as _pd2
    try:
        con = _sq2.connect(DB_UNIFIED)
        df = _pd2.read_sql_query("""
            SELECT master_name, media_server, ai_status,
                   active_jobs, total_jobs,
                   ROUND(data_tb,2) AS data_tb,
                   ROUND(efficiency,4) AS efficiency
            FROM media_metrics_unified m1
            WHERE timestamp=(
                SELECT MAX(timestamp) FROM media_metrics_unified m2
                WHERE m2.media_server=m1.media_server)
            ORDER BY ai_status DESC, total_jobs DESC
        """, con)
        con.close()
    except Exception as e:
        return html.Div(f"Media data error: {e}",
                        style={"padding":"20px","color":"#E24B4A"})
    if df.empty:
        return html.Div("No media server data.",
                        style={"padding":"20px","color":"#888"})
    SC  = {"HIGH_LOAD":"#E24B4A","ANOMALY":"#EF9F27",
           "BALANCED":"#378ADD","UNDERUTILIZED":"#639922"}
    hl  = int((df["ai_status"]=="HIGH_LOAD").sum())
    an  = int((df["ai_status"]=="ANOMALY").sum())
    bal = int((df["ai_status"]=="BALANCED").sum())
    rows = []
    for _, r in df.iterrows():
        st = str(r.get("ai_status","")); sc = SC.get(st,"#888")
        tj = int(r.get("total_jobs") or 0)
        dt = float(r.get("data_tb") or 0)
        ef = float(r.get("efficiency") or 0)
        aj = int(r.get("active_jobs") or 0)
        rows.append(("_color",
            "#fff0f0" if st=="HIGH_LOAD"
            else "#fff8ec" if st=="ANOMALY" else None, [
            r["media_server"].split(".")[0], r["master_name"],
            html.Span(st, style={"background":sc,"color":"#fff",
                "borderRadius":"6px","padding":"1px 8px",
                "fontSize":"9px","fontWeight":"600"}),
            str(aj), f"{tj:,}", f"{dt:.2f} TB", f"{ef:.4f}",
        ]))
    return html.Div([
        dbc.Row([
            dbc.Col(kpi_card("Total Servers", len(df), BRAND), md=3),
            dbc.Col(kpi_card("High Load", hl,
                             "#E24B4A" if hl else "#639922"), md=3),
            dbc.Col(kpi_card("Anomaly", an,
                             "#EF9F27" if an else "#639922"), md=3),
            dbc.Col(kpi_card("Balanced", bal, "#378ADD"), md=3),
        ], className="mb-3 g-2"),
        rich_table(["Server","Master","Status",
                    "Active","Jobs","Data","Efficiency"], rows),
    ], style={"padding":"8px"})


def _rpt_drill_bj():
    import sqlite3 as _sq3, pandas as _pd3
    try:
        con = _sq3.connect(DB_UNIFIED)
        df = _pd3.read_sql_query("""
            SELECT server_name, schedule, backup_type,
                   total_jobs, success_jobs, failed_jobs,
                   ROUND(success_rate,1) AS success_rate,
                   unique_clients,
                   ROUND(total_volume_tb,3) AS total_volume_tb,
                   ROUND(avg_throughput_mbps,1) AS avg_throughput_mbps,
                   ROUND(backup_window_hours,1) AS backup_window_hours,
                   report_date
            FROM backup_jobs_summary
            WHERE report_date=(
                SELECT MAX(report_date) FROM backup_jobs_summary)
            ORDER BY success_rate ASC
        """, con)
        errs = _pd3.read_sql_query("""
            SELECT error_code, SUM(count) AS total
            FROM backup_error_codes
            WHERE report_date=(
                SELECT MAX(report_date) FROM backup_error_codes)
            GROUP BY error_code ORDER BY total DESC LIMIT 6
        """, con)
        con.close()
    except Exception as e:
        return html.Div(f"Backup jobs error: {e}",
                        style={"padding":"20px","color":"#E24B4A"})
    if df.empty:
        return html.Div("No backup job data.",
                        style={"padding":"20px","color":"#888"})
    fleet_rate = round(
        df["success_jobs"].sum() / df["total_jobs"].sum() * 100, 1
    ) if df["total_jobs"].sum() > 0 else 0
    fleet_fail = int(df["failed_jobs"].sum())
    fleet_tb   = round(df["total_volume_tb"].sum(), 2)
    ERR_NAMES  = {96:"Client backup failed",24:"Socket read failed",
                  41:"Network error",6:"Backup aborted",
                  71:"None required",58:"Cannot connect"}
    err_section = html.Span()
    if not errs.empty:
        max_cnt  = int(errs.iloc[0]["total"])
        err_bars = []
        for _, er in errs.iterrows():
            code = int(er["error_code"]); cnt = int(er["total"])
            pct  = int(cnt/max_cnt*100) if max_cnt > 0 else 0
            err_bars.append(html.Div([
                html.Span(str(code), style={"fontFamily":"monospace",
                    "fontSize":"10px","fontWeight":"700","color":"#E24B4A",
                    "width":"28px","display":"inline-block"}),
                html.Div([html.Div(style={"position":"absolute","top":"0",
                    "left":"0","width":f"{pct}%","height":"100%",
                    "background":"#ef4444","borderRadius":"2px"})],
                    style={"flex":"1","height":"5px","background":"#f1f5f9",
                           "borderRadius":"2px","position":"relative",
                           "display":"inline-block","verticalAlign":"middle",
                           "margin":"0 8px","width":"120px"}),
                html.Span(f"{cnt:,}", style={"fontSize":"10px",
                    "color":"#555","marginRight":"6px"}),
                html.Span(ERR_NAMES.get(code, f"Error {code}"),
                    style={"fontSize":"9px","color":"#888"}),
            ], style={"display":"flex","alignItems":"center",
                      "padding":"3px 0","borderBottom":"1px solid #f8fafc"}))
        err_section = html.Div([
            html.Div("Top Error Codes",
                style={"fontSize":"10px","fontWeight":"600",
                       "color":"#334155","marginBottom":"8px"}),
            html.Div(err_bars),
        ], style={"background":"#fff","border":"1px solid #e2e8f0",
                  "borderRadius":"6px","padding":"10px","marginBottom":"12px"})
    rows = []
    for _, r in df.iterrows():
        rate = float(r["success_rate"])
        rc = "#dc2626" if rate<85 else "#d97706" if rate<95 else "#16a34a"
        tj = int(r["total_jobs"]); fj = int(r["failed_jobs"])
        uc = int(r["unique_clients"])
        tv = float(r["total_volume_tb"]); bw = float(r["backup_window_hours"])
        rows.append(("_color",
            "#fef2f2" if rate<85 else "#fffbeb" if rate<95 else None, [
            r["server_name"], r["schedule"], r["backup_type"],
            f"{tj:,}",
            html.Span(f"{rate:.1f}%", style={"fontWeight":"700","color":rc}),
            f"{fj:,}", f"{uc:,}",
            f"{tv:.3f} TB", f"{bw:.1f}h",
            str(r["report_date"])[:10],
        ]))
    return html.Div([
        dbc.Row([
            dbc.Col(kpi_card("Fleet Success", f"{fleet_rate}%",
                "#639922" if fleet_rate>=95
                else "#EF9F27" if fleet_rate>=85 else "#E24B4A"), md=3),
            dbc.Col(kpi_card("Failed Jobs", f"{fleet_fail:,}",
                "#E24B4A" if fleet_fail else "#639922"), md=3),
            dbc.Col(kpi_card("Volume", f"{fleet_tb} TB", BRAND), md=3),
            dbc.Col(kpi_card("Servers", len(df), "#378ADD"), md=3),
        ], className="mb-3 g-2"),
        err_section,
        rich_table(["Server","Schedule","Type","Jobs","Success",
                    "Failed","Clients","Volume","Window","Date"], rows),
    ], style={"padding":"8px"})


def _rpt_drill_vaultix():
    try:
        con = sqlite3.connect(DB_UNIFIED)
        total   = con.execute(
            "SELECT COUNT(*) FROM vaultix_messages").fetchone()[0]
        unans   = con.execute(
            "SELECT COUNT(*) FROM vaultix_messages "
            "WHERE was_answered=0").fetchone()[0]
        helpful = con.execute(
            "SELECT COUNT(*) FROM vaultix_messages "
            "WHERE was_helpful=0").fetchone()[0]
        top_i   = con.execute(
            "SELECT intent, COUNT(*) AS n FROM vaultix_messages "
            "WHERE intent!='' GROUP BY intent "
            "ORDER BY n DESC LIMIT 8").fetchall()
        recent_gaps = con.execute(
            "SELECT asked_at, question, intent, was_answered "
            "FROM vaultix_messages "
            "WHERE was_answered=0 OR was_helpful=0 "
            "ORDER BY asked_at DESC LIMIT 15").fetchall()
        con.close()
    except Exception as e:
        return html.Div(f"Vaultix data error: {e}",
                        style={"padding":"20px","color":"#E24B4A"})
    rate = round((total - unans) / max(total, 1) * 100, 1)
    chart = html.Span()
    if top_i:
        fig = go.Figure(go.Bar(
            x=[r[1] for r in top_i], y=[r[0] for r in top_i],
            orientation="h", marker_color=BRAND,
            textposition="outside", textfont=dict(size=9)))
        fig.update_layout(height=200,
            margin=dict(t=10,b=10,l=80,r=40),
            plot_bgcolor="#fafafa", paper_bgcolor="#fafafa",
            xaxis=dict(gridcolor="#f0f0f0", tickfont=dict(size=9)),
            yaxis=dict(tickfont=dict(size=9)))
        chart = dcc.Graph(figure=fig, config={"displayModeBar":False})
    gap_rows = []
    for row in recent_gaps:
        asked, q, intent, ans = row
        gap_rows.append(html.Tr([
            html.Td(str(asked)[:10],
                style={"padding":"4px 8px","fontSize":"9px","color":"#888"}),
            html.Td(str(q)[:60],
                style={"padding":"4px 8px","fontSize":"10px","color":"#333"}),
            html.Td(str(intent or "--"),
                style={"padding":"4px 8px","fontSize":"9px","color":"#555"}),
            html.Td(pill("No","danger") if not ans
                    else pill("Unhelpful","warning"),
                style={"padding":"4px 8px"}),
        ]))
    gaps_tbl = html.Div([
        html.Div("Recent Gaps",
            style={"fontSize":"10px","fontWeight":"600",
                   "color":"#334155","marginBottom":"6px"}),
        html.Table([
            html.Thead(html.Tr([
                html.Th(h, style={"padding":"5px 8px","background":"#f0f4fa",
                    "fontSize":"9px","color":BRAND,"fontWeight":"600"})
                for h in ["Date","Question","Intent","Status"]
            ])),
            html.Tbody(gap_rows),
        ], style={"width":"100%","borderCollapse":"collapse","background":"#fff"}),
    ], style={"border":"1px solid #e2e8f0","borderRadius":"6px",
              "overflow":"hidden"}) if gap_rows else html.Div(
        "No gaps -- Vaultix answered everything!",
        style={"color":"#639922","fontSize":"11px","padding":"10px"})
    return html.Div([
        dbc.Row([
            dbc.Col(kpi_card("Total Questions", total, BRAND), md=3),
            dbc.Col(kpi_card("Unanswered", unans,
                "#E24B4A" if unans else "#639922"), md=3),
            dbc.Col(kpi_card("Thumbs Down", helpful,
                "#EF9F27" if helpful else "#639922"), md=3),
            dbc.Col(kpi_card("Answer Rate", f"{rate}%",
                "#639922" if rate >= 95 else "#EF9F27"), md=3),
        ], className="mb-3 g-2"),
        html.Div("Top intents",
                 style={"fontSize":"11px","color":"#888","marginBottom":"6px"}),
        chart,
        html.Div(style={"height":"12px"}),
        gaps_tbl,
    ], style={"padding":"8px"})


def _build_drilldown_content(tab_id):
    builders = {
        "tab_lag":      _rpt_drill_lag,
        "tab_dp":       _rpt_drill_dp,
        "tab_3rd":      _rpt_drill_3rd,
        "tab_ag":       _rpt_drill_ag,
        "tab_cat":      _rpt_drill_cat,
        "tab_media":    _rpt_drill_media,
        "tab_bj":       _rpt_drill_bj,
        "tab_ai_train": _rpt_drill_vaultix,
    }
    fn = builders.get(tab_id)
    if fn:
        try:
            return fn()
        except Exception as e:
            logger.error("Drilldown error [%s]: %s", tab_id, e)
            return html.Div(f"Error loading drill-down: {e}",
                            style={"padding":"20px","color":"#E24B4A"})
    return html.Div("Unknown module.",
                    style={"padding":"20px","color":"#888"})

def _build_lag_insight(server, total, above_sla, trend_rows):
    pct_of_sla=round(total/SLA_THRESH*100)
    max_val=max([r["total"] for r in trend_rows],default=1)
    spark=html.Div([_spark_bar(r["date"][:10],int(r["total"]),max_val,_lag_color(r["total"])) for r in trend_rows],style={"marginBottom":"12px"})
    ns_remote=above_sla.get("not_started_remote",0) if above_sla else 0
    ip_remote=above_sla.get("in_process_remote",0)  if above_sla else 0
    ns_dup   =above_sla.get("not_started_duplicate",0) if above_sla else 0
    return html.Div([html.Div([_exec_card_head("critical","📉",f"Duplication queue {pct_of_sla}% of SLA — immediate action required",f"{server.upper()} · detected {datetime.now().strftime('%Y-%m-%d %H:%M')}","CRITICAL"),
        html.Div([_impact_grid([("Current lag",total,"#E24B4A",f"SLA limit: {SLA_THRESH}"),("% of SLA",f"{pct_of_sla}%","#E24B4A","breach threshold"),("NS Remote jobs",int(ns_remote),"#555",f"IP: {int(ip_remote)}")]),
            _narrative(f"Duplication lag on **{server.upper()}** has reached **{total} images** ({pct_of_sla}% of SLA {SLA_THRESH}). Primary driver: **{int(ns_remote)} not-started remote replication jobs**, plus {int(ns_dup)} not-started duplicate jobs."),
            _sec_label("14-day lag trend"),spark,_sec_label("Recommended actions"),
            _rec_card(1,f"Investigate not-started remote jobs ({int(ns_remote)})","Check NBU job monitor for stalled duplication jobs.","Ask Vaultix for lag breakdown",f"Show lag breakdown for {server}"),
            _rec_card(2,"Check disk pool capacity","Near-full pools may block duplication writes.","View disk pool detail",f"Show diskpool status for {server}"),
            _rec_card(3,"Run full server diagnostics","Correlate lag with catalog health and airgap retention.","Full server report",f"Show full report for {server}"),
        ],style={"padding":"12px 14px","background":"#fff"})
    ],style={"border":"0.5px solid #e0e0e0","borderRadius":"8px","overflow":"hidden","marginBottom":"14px"})])

def _build_disk_insight(server, pools_df):
    crit_pools=pools_df[pools_df["pct_used"]>=85] if not pools_df.empty else pd.DataFrame()
    top3=pools_df.nlargest(3,"pct_used") if not pools_df.empty else pd.DataFrame()
    spark=html.Div([_spark_bar(r["diskpool"][:28],round(r["pct_used"],1),100,_pct_color(r["pct_used"])) for _,r in top3.iterrows()],style={"marginBottom":"12px"})
    return html.Div([html.Div([_exec_card_head("critical","💽","Critical disk capacity — backup jobs at risk",f"{server.upper()} · {len(crit_pools)} pools ≥85% · {len(pools_df)} total","CRITICAL"),
        html.Div([_impact_grid([("Critical pools",len(crit_pools),"#E24B4A","≥ 85% used"),("Highest usage",f"{pools_df['pct_used'].max():.0f}%" if not pools_df.empty else "—","#E24B4A","worst pool"),("Est. days to full","~3d","#E24B4A","at current rate")]),
            _narrative(f"**{len(crit_pools)} disk pool(s)** on **{server.upper()}** are at critical capacity (≥85%). NetBackup may begin failing new backup jobs. This likely contributes to any duplication lag."),
            _sec_label("Pool utilization"),spark,_sec_label("Recommended actions"),
            _rec_card(1,"Expire old images to free capacity","Run bpexpdate on aged images. Target <70% to restore headroom.","View full diskpool report",f"Show diskpool status for {server}"),
            _rec_card(2,"Check fleet-wide capacity","Multiple servers may be at warning levels.","Fleet diskpool view","Show top 10 diskpools by capacity usage"),
        ],style={"padding":"12px 14px","background":"#fff"})
    ],style={"border":"0.5px solid #e0e0e0","borderRadius":"8px","overflow":"hidden","marginBottom":"14px"})])

def _build_retention_insight(server, ag_ret):
    wc=ag_ret.get("weekly_compliant",0) if ag_ret else 0; mc=ag_ret.get("monthly_compliant",0) if ag_ret else 0; yc=ag_ret.get("yearly_compliant",0) if ag_ret else 0
    wb=int(ag_ret.get("weekly_backups",0)) if ag_ret else 0; mb=int(ag_ret.get("monthly_backups",0)) if ag_ret else 0; yb=int(ag_ret.get("yearly_backups",0)) if ag_ret else 0
    return html.Div([html.Div([_exec_card_head("critical","🔄","Internal Airgap Vault — retention breach",f"{server.upper()} · W{'✓' if wc else '✗'} · M{'✓' if mc else '✗'} · Y{'✓' if yc else '✗'}","VAULT BREACH"),
        html.Div([_impact_grid([("Weekly backups",f"{'✓' if wc else '✗'} {wb}","#639922" if wc else "#E24B4A","Required: 4"),("Monthly backups",f"{'✓' if mc else '✗'} {mb}","#639922" if mc else "#E24B4A","Required: 2"),("Yearly backups",f"{'✓' if yc else '✗'} {yb}","#639922" if yc else "#E24B4A","Required: 1")]),
            _narrative(f"**{server.upper()}** airgap vault has failed {'all three' if not wc and not mc and not yc else 'one or more'} retention tiers. This is a **compliance and DR risk**."),
            _sec_label("Recommended actions"),
            _rec_card(1,"Investigate airgap SLP replication","Check nbstlutil and SLP status for the airgap vault.","Airgap detail",f"Show airgap replication status for {server}"),
            _rec_card(2,"Escalate to compliance team","Monthly and yearly violations may breach regulatory requirements.","View airgap tab","Show airgap replication status for all servers"),
        ],style={"padding":"12px 14px","background":"#fff"})
    ],style={"border":"0.5px solid #e0e0e0","borderRadius":"8px","overflow":"hidden","marginBottom":"14px"})])

def _build_dedup_insight(server, dedup_pct, fleet_avg, worm_days):
    sev="critical" if dedup_pct<30 else "warning"
    return html.Div([html.Div([_exec_card_head(sev,"🌐","External Airgap Vault dedup below threshold",f"{server.upper()} · {dedup_pct:.1f}% vs fleet avg {fleet_avg:.1f}%","LOW" if dedup_pct<30 else "MODERATE"),
        html.Div([_impact_grid([("Dedup %",f"{dedup_pct:.1f}%",_pct_color(dedup_pct),f"Fleet avg: {fleet_avg:.1f}%"),("Immutable retention (d)",f"{worm_days:.0f}d","#E24B4A" if worm_days<30 else "#639922","Threshold: 30d"),("Gap vs fleet",f"-{fleet_avg-dedup_pct:.1f}%","#E24B4A","efficiency loss")]),
            _narrative(f"**{server.upper()}** dedup is **{dedup_pct:.1f}%**, below fleet avg {fleet_avg:.1f}%.{'WORM retention at '+str(int(worm_days))+'d is below 30d threshold.' if worm_days<30 else ''}"),
            _sec_label("Recommended actions"),
            _rec_card(1,f"Review dedup config for {server.upper()}","Check MSDP settings, policy fingerprinting, client-side dedup.","Fleet 3rd-site comparison","Summarize 3rd-site dedup efficiency per server"),
            _rec_card(2,"Review WORM retention policy",f"Current WORM {worm_days:.0f}d is below 30d minimum.","3rd-site tab",f"Show 3rd-site for {server}"),
        ],style={"padding":"12px 14px","background":"#fff"})
    ],style={"border":"0.5px solid #e0e0e0","borderRadius":"8px","overflow":"hidden","marginBottom":"14px"})])

def _build_catalog_insight(server, cat_status, health_score, anomaly_reason=""):
    sev="critical" if cat_status=="ERROR" or health_score<60 else "warning"
    return html.Div([html.Div([_exec_card_head(sev,"📋",f"Catalog health {cat_status} — score {health_score:.0f}/100",f"{server.upper()} · {'anomaly detected' if anomaly_reason else 'no anomaly'}",cat_status),
        html.Div([html.Div([
                html.Div([html.Div("Status",style={"fontSize":"9px","color":"#888"}),html.Div(pill(cat_status,_status_color(cat_status)),style={"marginTop":"4px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
                html.Div([html.Div("Health score",style={"fontSize":"9px","color":"#888"}),html.Div(mini_bar(health_score),style={"marginTop":"6px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"2"}),
                html.Div([html.Div("Catalog date",style={"fontSize":"9px","color":"#888"}),html.Div("—",style={"fontSize":"12px","fontWeight":"500","marginTop":"4px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
                html.Div([html.Div("Anomaly",style={"fontSize":"9px","color":"#888"}),html.Div(pill("Yes","danger") if anomaly_reason else pill("No","secondary"),style={"marginTop":"4px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
            ],style={"display":"flex","gap":"8px","marginBottom":"10px"}),
            html.Div(anomaly_reason[:120] if anomaly_reason else "",style={"fontSize":"10px","color":"#888","marginBottom":"8px"}) if anomaly_reason else html.Span(),
            _sec_label("Recommended actions"),
            _rec_card(1,"Review catalog backup job activity","Check bpbackupdb logs and catalog backup policy schedule.","Catalog detail",f"Show catalog health for {server}"),
            _rec_card(2,"Verify VVR replication status","Confirm catalog replication to DR site is current.","Catalog tab","Show catalog backup health for all servers"),
        ],style={"padding":"12px 14px","background":"#fff"})
    ],style={"border":"0.5px solid #e0e0e0","borderRadius":"8px","overflow":"hidden","marginBottom":"14px"})])

def _build_healthy_insight(compliant_servers, working_servers):
    chips=[_srv_chip(s,f"Show airgap status for {s.lower()}") for s in compliant_servers]
    return html.Div([html.Div([_exec_card_head("healthy","🔄",f"Airgap fleet — {len(compliant_servers)} of {len(compliant_servers)+len(working_servers)} servers fully compliant","Completed replication · all retention tiers met","HEALTHY"),
        html.Div([_impact_grid([("Compliant",f"{len(compliant_servers)}","#639922","servers"),("Working",f"{len(working_servers)}","#EF9F27","servers"),("Violations","0","#639922","for these servers")]),
            _narrative(f"**{len(compliant_servers)} servers** are fully compliant with all airgap retention tiers and have zero replication backlog."),
            _sec_label("Compliant servers — click to inspect"),
            html.Div(chips,style={"display":"flex","flexWrap":"wrap","gap":"6px","marginBottom":"12px"}),
        ],style={"padding":"12px 14px","background":"#fff"})
    ],style={"border":"0.5px solid #e0e0e0","borderRadius":"8px","overflow":"hidden","marginBottom":"14px"})])


def _rebuild_insight_detail(iid):
    try:
        parts=iid.split("_",2); kind="_".join(parts[:2]) if len(parts)>=2 else iid; srv=parts[2] if len(parts)>2 else ""
        if kind in ("lag_breach","lag_warn"):
            r=qrow(DB_UNIFIED,f"SELECT total,above_sla,not_started_remote,in_process_remote,not_started_duplicate,in_process_duplicate,date FROM lag_history WHERE server_name='{srv}' ORDER BY date DESC LIMIT 1")
            trend=qdf(DB_LAG,f"SELECT date,total FROM lag_history WHERE server='{srv}' ORDER BY date DESC LIMIT 14").sort_values("date").to_dict("records")
            return _build_lag_insight(srv,int(r["total"]) if r else 0,r or {},trend)
        if kind in ("disk_crit","disk_warn"):
            grp=qdf(DB_UNIFIED,f"SELECT diskpool,ROUND(used_tb*100.0/total_tb,1) AS pct_used FROM diskpool_daily WHERE server_name='{srv}' AND run_date=(SELECT MAX(run_date) FROM diskpool_daily WHERE server_name='{srv}')")
            return _build_disk_insight(srv,grp)
        if kind=="ret_viol":
            r=qrow(DB_AIRGAP,f"SELECT weekly_compliant,monthly_compliant,yearly_compliant,weekly_backups,monthly_backups,yearly_backups FROM retention_compliance WHERE server='{srv}' ORDER BY timestamp DESC LIMIT 1")
            return _build_retention_insight(srv,r)
        if kind.startswith("dedup"):
            r=qrow(DB_UNIFIED,f"SELECT avg_dedup_percent,max_worm_days FROM thirdsite_summary WHERE server_name='{srv}' ORDER BY report_date DESC LIMIT 1")
            avg=scalar(DB_UNIFIED,"SELECT AVG(avg_dedup_percent) FROM thirdsite_summary WHERE report_date=(SELECT MAX(report_date) FROM thirdsite_summary)") or 0
            return _build_dedup_insight(srv,r["avg_dedup_percent"] if r else 0,avg,r["max_worm_days"] if r else 0)
        if kind.startswith("cat"):
            r=qrow(DB_CATALOG,f"SELECT catalog_status,health_score,anomaly_detected,anomaly_reason FROM health_records WHERE server='{srv}' ORDER BY timestamp DESC LIMIT 1")
            return _build_catalog_insight(srv,r["catalog_status"] if r else "ERROR",r["health_score"] if r else 0,str(r.get("anomaly_reason","")) if r and r.get("anomaly_detected") else "")
        if iid=="airgap_healthy":
            ag=qdf(DB_AIRGAP,"SELECT server,status FROM replication_status rs1 WHERE timestamp=(SELECT MAX(timestamp) FROM replication_status WHERE server=rs1.server)")
            ret=qdf(DB_AIRGAP,"SELECT server,weekly_compliant,monthly_compliant,yearly_compliant FROM retention_compliance rc1 WHERE timestamp=(SELECT MAX(timestamp) FROM retention_compliance WHERE server=rc1.server)")
            merged=pd.merge(ag,ret,on="server",how="left") if not ret.empty else ag
            compliant,working=[],[]
            for _,row in merged.iterrows():
                ok=bool(row.get("weekly_compliant")) and bool(row.get("monthly_compliant")) and bool(row.get("yearly_compliant"))
                if ok and row.get("status")=="Completed": compliant.append(row["server"])
                elif row.get("status")=="Working": working.append(row["server"])
            return _build_healthy_insight(compliant,working)
    except Exception as e:
        logger.error(f"_rebuild_insight_detail({iid}): {e}")
    return html.Div("Unable to load detail.",style={"padding":"20px","color":"#E24B4A","fontSize":"11px"})


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4: AI INSIGHTS
# ══════════════════════════════════════════════════════════════════════════════
def tab_ai():
    """AI Fleet Intelligence — CEO-level visibility, operations-actionable."""
    import sqlite3 as _sq
    from datetime import datetime as _dt

    try:
        con = _sq.connect(DB_UNIFIED)
        today = con.execute("SELECT MAX(date) FROM lag_history").fetchone()[0]

        lag = con.execute("""
            SELECT server_name, total, not_started_duplicate,
                   in_process_duplicate, above_sla, delta_1d
            FROM lag_history WHERE date=?
            ORDER BY total DESC
        """, (today,)).fetchall()

        pools_down = con.execute("""
            SELECT server_name, diskpool, health, pct_used, status
            FROM diskpool_daily
            WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily)
            AND status='Down'
            ORDER BY pct_used DESC
        """).fetchall()

        rv = con.execute("""
            SELECT ROUND(SUM(used_tb),1)
            FROM diskpool_daily
            WHERE diskpool_group='Recovery Vault'
            AND run_date=(SELECT MAX(run_date) FROM diskpool_daily
                         WHERE diskpool_group='Recovery Vault')
        """).fetchone()[0] or 0

        rv_breach = con.execute("""
            SELECT COUNT(*) FROM (
                SELECT SUM(used_tb) as v FROM diskpool_daily
                WHERE diskpool_group='Recovery Vault' GROUP BY run_date
            ) WHERE v>910
        """).fetchone()[0]

        ag_down = con.execute("""
            SELECT server_name, ag_status FROM v_server_latest
            WHERE ag_status='Not Working'
        """).fetchall()

        cat_err = con.execute("""
            SELECT server_name, cat_status, cat_health_score
            FROM v_server_latest WHERE cat_status='ERROR'
        """).fetchall()

        media_sum = con.execute("""
            SELECT SUM(CASE WHEN ai_status='ANOMALY'   THEN 1 ELSE 0 END),
                   SUM(CASE WHEN ai_status='HIGH_LOAD' THEN 1 ELSE 0 END)
            FROM media_metrics_unified m1
            WHERE timestamp=(SELECT MAX(m2.timestamp)
                             FROM media_metrics_unified m2
                             WHERE m2.media_server=m1.media_server)
        """).fetchone()

        media_by_master = con.execute("""
            SELECT master_name,
                   SUM(CASE WHEN ai_status='ANOMALY'   THEN 1 ELSE 0 END) as an,
                   SUM(CASE WHEN ai_status='HIGH_LOAD' THEN 1 ELSE 0 END) as hl
            FROM media_metrics_unified m1
            WHERE timestamp=(SELECT MAX(m2.timestamp)
                             FROM media_metrics_unified m2
                             WHERE m2.media_server=m1.media_server)
            GROUP BY master_name HAVING an>0 OR hl>0
            ORDER BY an DESC
        """).fetchall()

        dedup_low = con.execute("""
            SELECT server_name, ROUND(avg_dedup_percent,1), max_worm_days,
                   ROUND(total_data_tb,1)
            FROM thirdsite_summary
            WHERE report_date=(SELECT MAX(report_date) FROM thirdsite_summary)
            AND avg_dedup_percent < 80
            ORDER BY avg_dedup_percent
        """).fetchall()

        trend = con.execute("""
            SELECT date, SUM(total) as fleet_total
            FROM lag_history
            WHERE date >= date('now','-15 days')
            GROUP BY date ORDER BY date
        """).fetchall()

        con.close()
    except Exception as e:
        return html.Div(f"AI Insights unavailable: {e}",
                        style={"padding":"24px","color":"#E24B4A"})

    # ── Computed values ────────────────────────────────────────────────────
    total_lag   = sum(int(r[1] or 0) for r in lag)
    ms_an       = int(media_sum[0] or 0) if media_sum else 0
    ms_hl       = int(media_sum[1] or 0) if media_sum else 0
    rv_pct      = round(rv/910*100, 1)
    n_pools_down= len(pools_down)
    n_ag_down   = len(ag_down)
    n_cat_err   = len(cat_err)
    act_now     = sum([1 if n_ag_down>0 else 0,
                       1 if n_pools_down>0 else 0,
                       1 if total_lag>10000 else 0])
    this_week   = sum([1 if n_cat_err>0 else 0,
                       1 if rv_pct>50 else 0,
                       1 if ms_an>5 else 0,
                       1 if dedup_low else 0])
    next_sat = "Sat 31 May"

    # ── Helpers ────────────────────────────────────────────────────────────
    def _pill(txt, cls):
        styles = {
            "r":  ("background:#FCEBEB;color:#791F1F;",),
            "a":  ("background:#FAEEDA;color:#633806;",),
            "g":  ("background:#EAF3DE;color:#27500A;",),
            "b":  ("background:#E6F1FB;color:#0C447C;",),
            "nt": ("background:#f1f5f9;color:#475569;",),
        }
        s = styles.get(cls, styles["nt"])[0]
        return html.Span(txt, style={
            "display":"inline-flex","alignItems":"center","gap":"4px",
            "fontSize":"10px","fontWeight":"500","padding":"3px 9px",
            "borderRadius":"20px","whiteSpace":"nowrap",
            **dict(item.split(":") for item in s.rstrip(";").split(";") if ":" in item)
        })

    def _dot(color):
        return html.Span(style={"width":"7px","height":"7px","borderRadius":"50%",
                                 "background":color,"display":"inline-block",
                                 "flexShrink":"0"})

    def _step_tag(txt):
        return html.Span(txt, style={
            "fontSize":"10px","color":"#475569","background":"#f1f5f9",
            "borderRadius":"4px","padding":"2px 7px","marginRight":"4px",
            "display":"inline-block","marginBottom":"3px"
        })

    def _srv_tag(txt):
        return html.Span(txt.replace("cbkms",""), style={
            "fontFamily":"monospace","fontSize":"10px",
            "background":"#f1f5f9","color":"#475569",
            "padding":"1px 6px","borderRadius":"4px",
            "display":"inline-block"
        })

    def _action_row(num, color, title, body, steps, tags=None):
        num_bg = "#FCEBEB" if color=="r" else "#FAEEDA"
        num_c  = "#A32D2D" if color=="r" else "#854F0B"
        pill_c = "r" if color=="r" else "a"
        pill_t = "Act now" if color=="r" else "This week"
        return html.Div([
            html.Div([
                html.Div(str(num), style={
                    "width":"28px","height":"28px","borderRadius":"50%",
                    "background":num_bg,"color":num_c,"fontWeight":"500",
                    "fontSize":"12px","display":"flex","alignItems":"center",
                    "justifyContent":"center","flexShrink":"0"
                }),
            ], style={"paddingTop":"2px"}),
            html.Div([
                html.Div([
                    html.Span(title, style={"fontSize":"12px","fontWeight":"500",
                                            "color":"#1e293b","marginRight":"6px"}),
                    _pill(pill_t, pill_c),
                    *([_srv_tag(t) for t in (tags or [])]),
                ], style={"display":"flex","alignItems":"center","flexWrap":"wrap",
                          "gap":"4px","marginBottom":"5px"}),
                html.Div(body, style={"fontSize":"11px","color":"#64748b",
                                       "lineHeight":"1.6","marginBottom":"8px"}),
                html.Div([_step_tag(s) for s in steps],
                         style={"display":"flex","flexWrap":"wrap","gap":"2px"}),
            ], style={"flex":"1","paddingLeft":"12px"}),
        ], style={"display":"flex","alignItems":"flex-start","gap":"0",
                  "padding":"12px 0",
                  "borderBottom":"0.5px solid var(--color-border-tertiary)"})

    # ── KPI strip ──────────────────────────────────────────────────────────
    def _kpi_bar(val, label, color, pct):
        return html.Div([
            html.Div(str(val),
                     style={"fontSize":"24px","fontWeight":"500",
                            "color":color,"lineHeight":"1"}),
            html.Div(label,
                     style={"fontSize":"10px","color":"#94a3b8",
                            "textTransform":"uppercase","letterSpacing":"0.4px",
                            "marginTop":"3px"}),
            html.Div(html.Div(style={"width":f"{min(100,pct)}%","height":"100%",
                                      "background":color,"borderRadius":"2px"}),
                     style={"height":"3px","background":"#e2e8f0",
                            "borderRadius":"2px","marginTop":"6px","overflow":"hidden"}),
        ], style={"background":"var(--color-background-secondary)",
                  "borderRadius":"var(--border-radius-md)","padding":"12px 10px",
                  "textAlign":"center"})

    kpi_strip = html.Div([
        _kpi_bar(f"{total_lag:,}","Dup queue","#E24B4A", min(100,total_lag/1000)),
        _kpi_bar(n_pools_down,"Pools down",
                 "#E24B4A" if n_pools_down>5 else "#EF9F27",
                 min(100,n_pools_down*12)),
        _kpi_bar(f"{rv} TB","Vault used",
                 "#E24B4A" if rv>773 else "#185FA5", rv_pct),
        _kpi_bar(n_ag_down,"Airgap down","#E24B4A" if n_ag_down>0 else "#639922",
                 min(100,n_ag_down*33)),
        _kpi_bar(ms_an+ms_hl,"Media anomalies",
                 "#EF9F27" if ms_an+ms_hl>10 else "#639922",
                 min(100,(ms_an+ms_hl)*2)),
        _kpi_bar(n_cat_err,"Catalog errors",
                 "#E24B4A" if n_cat_err>0 else "#639922",
                 min(100,n_cat_err*50)),
    ], style={"display":"grid",
              "gridTemplateColumns":"repeat(auto-fit,minmax(100px,1fr))",
              "gap":"8px","marginBottom":"16px"})

    # ── Spotlight cards ────────────────────────────────────────────────────
    india_lag   = sum(int(r[1] or 0) for r in lag
                      if r[0] in ("cpcinp1cbkms","cazinp1cbkms"))
    india_tags  = [r[0] for r in lag
                   if r[0] in ("cpcinp1cbkms","cazinp1cbkms") and int(r[1] or 0)>1000]
    ag_tags     = [r[0] for r in ag_down]

    spotlight = html.Div([
        # India cluster card
        html.Div([
            html.Div([
                html.Span(style={"width":"8px","height":"8px","borderRadius":"50%",
                                  "background":"#E24B4A","flexShrink":"0"}),
                html.Span("India cluster — highest risk",
                          style={"fontSize":"12px","fontWeight":"500",
                                 "color":"var(--color-text-primary)"}),
                _pill("Act now","r"),
            ], style={"display":"flex","alignItems":"center","gap":"8px",
                      "marginBottom":"10px","flexWrap":"wrap"}),
            html.Div(
                f"{india_lag:,} images stalled across cpcinp1 + cazinp1. "
                f"Both airgap connections failed. {n_pools_down} pools Down on "
                f"cpcind2 blocking new writes.",
                style={"fontSize":"11px","color":"var(--color-text-secondary)",
                       "lineHeight":"1.6","marginBottom":"10px"}),
            html.Div([
                _pill(f"29,780 cpcinp1","r"),
                _pill(f"29,089 cazinp1","r"),
                _pill("Airgap: not working","r"),
                _pill(f"{n_pools_down} pools Down cpcind2","a"),
            ], style={"display":"flex","gap":"5px","flexWrap":"wrap"}),
        ], style={"background":"var(--color-background-primary)",
                  "border":"2px solid #E24B4A",
                  "borderRadius":"var(--border-radius-lg)","padding":"14px 16px"}),

        # Vault card
        html.Div([
            html.Div([
                html.Span(style={"width":"8px","height":"8px","borderRadius":"50%",
                                  "background":"#EF9F27","flexShrink":"0"}),
                html.Span("Vault compliance — watch",
                          style={"fontSize":"12px","fontWeight":"500",
                                 "color":"var(--color-text-primary)"}),
                _pill("This week","a"),
            ], style={"display":"flex","alignItems":"center","gap":"8px",
                      "marginBottom":"10px","flexWrap":"wrap"}),
            html.Div(
                f"{rv} TB used ({rv_pct}%) — currently safe. "
                f"But {rv_breach} past breach days, peak 968 TB. "
                f"Next full backup {next_sat} will push higher.",
                style={"fontSize":"11px","color":"var(--color-text-secondary)",
                       "lineHeight":"1.6","marginBottom":"10px"}),
            html.Div([
                _pill(f"{rv} / 910 TB","b"),
                _pill(f"{rv_breach} breach days historically","a"),
                _pill("cocinp1 dedup only 70%","a"),
            ], style={"display":"flex","gap":"5px","flexWrap":"wrap"}),
        ], style={"background":"var(--color-background-primary)",
                  "border":"0.5px solid var(--color-border-tertiary)",
                  "borderRadius":"var(--border-radius-lg)","padding":"14px 16px"}),
    ], style={"display":"grid","gridTemplateColumns":"1fr 1fr",
              "gap":"10px","marginBottom":"16px"})

    # ── Actions panel ──────────────────────────────────────────────────────
    actions_list = [
        _action_row(1,"r",
            "Fix airgap on India servers",
            f"{n_ag_down} servers showing 'Not Working' — airgap replication completely stalled. "
            "No 3-site protection until fixed. These hold the largest backup volumes in the fleet.",
            ["Run nbstlutil on each affected server",
             "Check SLP configuration",
             "Verify air-gap master connectivity",
             "Restart SLP jobs if needed"],
            tags=[r[0] for r in ag_down]),

        _action_row(2,"r",
            f"Recover Down pools — {n_pools_down} pools",
            "Backup jobs targeting Down pools will fail silently. "
            f"{'cpcingups116852 at 77.8% is approaching critical.' if n_pools_down>0 else ''} "
            "Redirect policies immediately.",
            ["Run nbdevquery -listdp",
             "Check media server connectivity",
             "Redirect policies from Down pools",
             "Run bpexpdate on near-critical pools"],
            tags=list({r[0] for r in pools_down})[:3]),

        _action_row(3,"r",
            f"Clear duplication backlog — {total_lag:,} images fleet total",
            "Queue stable at 60K–72K for 15 days — structural backlog, not a spike. "
            "Fixing pools and airgap (steps 1–2) will unblock most automatically.",
            ["After steps 1+2, monitor queue drop",
             "Check STU throughput on cpcinp1 and cazinp1",
             "Review media server load balancing"],
            tags=["cpcinp1cbkms","cazinp1cbkms"]),

        _action_row(4,"a",
            "Restore catalog backup — APAC region",
            "China and Philippines servers showing ERROR with health 0/100. "
            "No catalog DR available for APAC until resolved.",
            ["Test network to cpcchp1 and cpcphp1",
             "Verify catalog backup policy is active",
             "Check STU accessibility from APAC"],
            tags=[r[0] for r in cat_err]),

        _action_row(5,"a",
            f"Vault compliance — prepare before {next_sat} full backup",
            f"Current: {rv} TB (53% of 910 TB). "
            f"{rv_breach} historical breach days, peak 968 TB. "
            "cocinp1 dedup at 70% is primary driver of over-consumption.",
            ["Improve cocinp1 dedup (70% vs fleet avg 87%)",
             "Run nbdedup -report on cocinp1",
             "Consider reducing WORM from 186d to 90d",
             "Monitor vault during Sat backup window"],
            tags=["cocinp1cbkms"]),

        _action_row(6,"a",
            f"Investigate media server anomalies — {ms_an+ms_hl} flagged",
            f"{ms_an} ANOMALY + {ms_hl} HIGH_LOAD across "
            f"{len(media_by_master)} masters. Most correlate with Down pools. "
            "Resolving pools (step 2) should clear majority automatically.",
            ["Cross-check anomalous servers vs Down pools",
             "Run bpmedialist on affected masters",
             "Rebalance load to BALANCED servers"],
            tags=[m[0] for m in media_by_master[:3]]),
    ]

    # Remove last border
    actions_panel = html.Div([
        html.Div("What to do — in order",
                 style={"fontSize":"12px","fontWeight":"500",
                        "color":"var(--color-text-primary)","marginBottom":"4px"}),
        html.Div(actions_list),
    ], style={"background":"var(--color-background-primary)",
              "border":"0.5px solid var(--color-border-tertiary)",
              "borderRadius":"var(--border-radius-lg)",
              "padding":"16px","marginBottom":"16px"})

    # ── Trend chart + server risk grid ────────────────────────────────────
    import json as _json
    trend_labels = [r[0][5:] for r in trend]
    trend_data   = [int(r[1]) for r in trend]
    trend_js     = _json.dumps({"labels":trend_labels,"data":trend_data})

    from pathlib import Path as _P
    cjs = _P("/usr/nbu-cts-v2/assets/chart.umd.js").read_text()           if _P("/usr/nbu-cts-v2/assets/chart.umd.js").exists() else ""

    trend_iframe_src = """<!DOCTYPE html><html><head>
<style>*{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,sans-serif;}
body{background:transparent;padding:4px;}
</style>
<script>""" + cjs + """</script></head><body>
<div style="position:relative;height:130px;">
<canvas id="tc" role="img" aria-label="14-day duplication queue trend">14-day trend data</canvas>
</div>
<div style="font-size:10px;color:#94a3b8;margin-top:6px;">
  Persistent 60K–72K range · structural backlog since May 13
</div>
<script>
var D=""" + trend_js + """;
new Chart(document.getElementById('tc'),{
  type:'line',
  data:{labels:D.labels,datasets:[{
    label:'Fleet queue',data:D.data,
    borderColor:'#E24B4A',backgroundColor:'#FCEBEB',
    borderWidth:2,pointRadius:2,fill:true,tension:0.3
  }]},
  options:{responsive:true,maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{
      x:{ticks:{font:{size:9},color:'#888780'},grid:{display:false}},
      y:{ticks:{font:{size:9},color:'#888780',
           callback:function(v){return Math.round(v/1000)+'K';}},
         grid:{color:'#f8f8f8'}}
    }
  }
});
</script></body></html>"""

    # Server risk snapshot
    all_srv_risk = []
    for r in lag:
        srv = r[0]
        pills = []
        if int(r[1] or 0) > 1000:
            pills.append(_pill("Queue","r"))
        ag_match = [a for a in ag_down if a[0]==srv]
        if ag_match: pills.append(_pill("Airgap","r"))
        cat_match = [c for c in cat_err if c[0]==srv]
        if cat_match: pills.append(_pill("Catalog","r"))
        pool_match = list({p[0] for p in pools_down if p[0]==srv})
        if pool_match: pills.append(_pill(f"{len([p for p in pools_down if p[0]==srv])} pools","r"))
        media_match = [m for m in media_by_master if m[0]==srv]
        if media_match and (media_match[0][1]>0 or media_match[0][2]>0):
            pills.append(_pill("Media","a"))
        dedup_match = [d for d in dedup_low if d[0]==srv]
        if dedup_match: pills.append(_pill(f"Dedup {dedup_match[0][1]}%","a"))
        if not pills: continue
        all_srv_risk.append(html.Div([
            html.Span(srv.replace("cbkms",""),
                      style={"fontFamily":"monospace","fontSize":"10px",
                             "fontWeight":"500","minWidth":"80px"}),
            html.Div(pills,
                     style={"display":"flex","gap":"4px","flexWrap":"wrap"}),
        ], style={"display":"flex","alignItems":"center","justifyContent":"space-between",
                  "padding":"6px 0","borderBottom":"0.5px solid var(--color-border-tertiary)",
                  "gap":"8px"}))

    # Healthy servers
    risk_srvs = {r[0] for r in lag
                 if int(r[1] or 0)>1000
                 or r[0] in {a[0] for a in ag_down}
                 or r[0] in {c[0] for c in cat_err}
                 or r[0] in {p[0] for p in pools_down}}
    healthy_srvs = [r[0] for r in lag if r[0] not in risk_srvs]
    if healthy_srvs:
        all_srv_risk.append(html.Div([
            html.Span(f"+ {len(healthy_srvs)} servers",
                      style={"fontSize":"10px","color":"var(--color-text-secondary)",
                             "fontFamily":"monospace","minWidth":"80px"}),
            _pill("All healthy","g"),
        ], style={"display":"flex","alignItems":"center","justifyContent":"space-between",
                  "padding":"6px 0","gap":"8px"}))

    bottom_row = html.Div([
        html.Div([
            html.Div("14-day dup queue trend",
                     style={"fontSize":"12px","fontWeight":"500",
                            "color":"var(--color-text-primary)","marginBottom":"10px"}),
            html.Iframe(srcDoc=trend_iframe_src,
                        style={"width":"100%","border":"none","height":"170px"}),
        ], style={"background":"var(--color-background-primary)",
                  "border":"0.5px solid var(--color-border-tertiary)",
                  "borderRadius":"var(--border-radius-lg)","padding":"14px 16px"}),

        html.Div([
            html.Div("Server risk snapshot",
                     style={"fontSize":"12px","fontWeight":"500",
                            "color":"var(--color-text-primary)","marginBottom":"10px"}),
            html.Div(all_srv_risk),
        ], style={"background":"var(--color-background-primary)",
                  "border":"0.5px solid var(--color-border-tertiary)",
                  "borderRadius":"var(--border-radius-lg)","padding":"14px 16px"}),
    ], style={"display":"grid","gridTemplateColumns":"1fr 1fr",
              "gap":"10px","marginBottom":"16px"})

    # ── Saturday warning banner ────────────────────────────────────────────
    sat_banner = html.Div([
        html.Span(f"Next full backup {next_sat} 18:00",
                  style={"fontWeight":"500","color":"var(--color-text-primary)",
                         "marginRight":"8px"}),
        html.Span(f"Vault at {rv_pct}% now — steps 1–3 must complete before "
                  f"Saturday to avoid breach risk.",
                  style={"fontSize":"11px","color":"var(--color-text-secondary)"}),
        _pill(f"7 servers healthy","g"),
    ], style={"background":"var(--color-background-secondary)",
              "borderRadius":"var(--border-radius-md)",
              "padding":"12px 16px","display":"flex","alignItems":"center",
              "justifyContent":"space-between","flexWrap":"wrap","gap":"8px",
              "fontSize":"11px"})

    # ── Email button + header ──────────────────────────────────────────────
    header = html.Div([
        html.Div([
            html.Div("Fleet intelligence",
                     style={"fontSize":"16px","fontWeight":"500",
                            "color":"var(--color-text-primary)"}),
            html.Div(f"{today} · 14 servers · 6 regions · AI-analysed",
                     style={"fontSize":"11px","color":"var(--color-text-secondary)",
                            "marginTop":"2px"}),
        ]),
        html.Div([
            html.Div([
                html.Span(style={"width":"7px","height":"7px","borderRadius":"50%",
                                  "background":"#E24B4A","display":"inline-block",
                                  "marginRight":"4px"}),
                html.Span(f"{act_now} act now",
                          style={"fontSize":"10px","fontWeight":"500",
                                 "padding":"3px 9px","borderRadius":"20px",
                                 "background":"#FCEBEB","color":"#791F1F"}),
            ]),
            html.Div([
                html.Span(style={"width":"7px","height":"7px","borderRadius":"50%",
                                  "background":"#EF9F27","display":"inline-block",
                                  "marginRight":"4px"}),
                html.Span(f"{this_week} this week",
                          style={"fontSize":"10px","fontWeight":"500",
                                 "padding":"3px 9px","borderRadius":"20px",
                                 "background":"#FAEEDA","color":"#633806"}),
            ]),
            html.Div([
                html.Span(style={"width":"7px","height":"7px","borderRadius":"50%",
                                  "background":"#639922","display":"inline-block",
                                  "marginRight":"4px"}),
                html.Span("7 healthy",
                          style={"fontSize":"10px","fontWeight":"500",
                                 "padding":"3px 9px","borderRadius":"20px",
                                 "background":"#EAF3DE","color":"#27500A"}),
            ]),
            html.Button([
                html.Span("📧 ", style={"marginRight":"3px"}),
                "Email insights to team",
            ], id="ai-insights-email-btn", n_clicks=0,
            style={"padding":"7px 14px","fontSize":"11px","fontWeight":"500",
                   "background":"#185FA5","color":"#fff","border":"none",
                   "borderRadius":"8px","cursor":"pointer","whiteSpace":"nowrap"}),
            html.Div(id="ai-insights-email-result",
                     style={"fontSize":"11px","color":"#3B6D11"}),
        ], style={"display":"flex","alignItems":"center","gap":"6px","flexWrap":"wrap"}),
    ], style={"display":"flex","justifyContent":"space-between","alignItems":"center",
              "marginBottom":"16px","flexWrap":"wrap","gap":"10px"})

    return html.Div([
        header,
        kpi_strip,
        spotlight,
        actions_panel,
        bottom_row,
        sat_banner,
        html.Div(f"NBU-CTS Fleet Intelligence · {today} · auto-refreshes on tab load",
                 style={"fontSize":"10px","color":"#94a3b8","textAlign":"right",
                        "marginTop":"8px"}),
    ], style={"padding":"16px"})



def _session_pill(sid,label,active):
    return html.Div([html.Span("💬 "),label],id={"type":"vaultix_session_btn","index":sid},n_clicks=0,
        style={"padding":"6px 14px","fontSize":"10px","cursor":"pointer","color":"#333" if active else "#888",
               "background":"#fff" if active else "transparent","borderLeft":f"2px solid {BRAND}" if active else "2px solid transparent",
               "fontWeight":"500" if active else "400","whiteSpace":"nowrap","overflow":"hidden","textOverflow":"ellipsis"})


def _welcome_bubble():
    return html.Div([
        html.Div("V",style={"width":"24px","height":"24px","background":BRAND,"borderRadius":"50%","display":"flex","alignItems":"center","justifyContent":"center","fontSize":"10px","color":"#fff","flexShrink":"0","marginTop":"2px"}),
        html.Div([html.Strong("Vaultix",style={"color":BRAND}),html.Br(),html.Span("Hello! I am Vaultix AI, your NBU Backup Intelligence assistant. Ask me anything about the Duplication Queue, Storage Pools, External Airgap Vault, Internal Airgap Vault, or Catalog Health.",style={"fontSize":"11px"})],
                 style={"background":"#fff","border":"0.5px solid #e0e0e0","borderRadius":"4px 10px 10px 10px","padding":"10px 13px","flex":"1","fontSize":"11px","lineHeight":"1.6"})
    ],style={"display":"flex","gap":"8px","alignItems":"flex-start"})


def _user_bubble(text):
    return html.Div(html.Div(text,style={"background":BRAND,"color":"#fff","borderRadius":"10px 4px 10px 10px","padding":"9px 13px","fontSize":"11px","lineHeight":"1.5","maxWidth":"80%"}),style={"display":"flex","justifyContent":"flex-end"})


def _bot_bubble(content, idx=None):
    body = (html.Span(content, style={"whiteSpace":"pre-wrap","lineHeight":"1.6"})
            if isinstance(content, str) else content)

    if idx is not None:
        feedback = html.Div([
            html.Button("👍",
                id={"type":"vaultix_feedback","index":f"helpful:{idx}"},
                n_clicks=0, title="Good answer",
                style={"background":"none","border":"none","cursor":"pointer",
                       "fontSize":"13px","padding":"2px 4px","opacity":"0.6",
                       "transition":"opacity 0.2s"}),
            html.Button("👎",
                id={"type":"vaultix_feedback","index":f"unhelpful:{idx}"},
                n_clicks=0, title="Flag for correction",
                style={"background":"none","border":"none","cursor":"pointer",
                       "fontSize":"13px","padding":"2px 4px","opacity":"0.6",
                       "transition":"opacity 0.2s"}),
            html.Button("📧 Email to Team",
                id={"type":"vaultix_email_btn","index":idx},
                n_clicks=0, title="Email this report to team",
                style={"background":"#0f766e","color":"#fff","border":"none",
                       "borderRadius":"6px","padding":"3px 10px",
                       "fontSize":"9px","cursor":"pointer","fontWeight":"600",
                       "marginLeft":"6px","letterSpacing":"0.2px"}),
        ], style={"display":"flex","alignItems":"center","gap":"2px",
                  "marginTop":"6px","justifyContent":"flex-end"})
    else:
        feedback = None

    children = [
        html.Div("V", style={"width":"24px","height":"24px","background":BRAND,
                              "borderRadius":"50%","display":"flex",
                              "alignItems":"center","justifyContent":"center",
                              "fontSize":"10px","color":"#fff",
                              "flexShrink":"0","marginTop":"2px"}),
        html.Div([body, feedback] if feedback else [body],
                 style={"background":"#fff","border":"0.5px solid #e0e0e0",
                        "borderRadius":"4px 10px 10px 10px","padding":"8px 12px",
                        "fontSize":"11px","color":"#333","maxWidth":"85%",
                        "wordBreak":"break-word"}),
    ]
    return html.Div(children,
                    style={"display":"flex","gap":"8px","marginBottom":"8px",
                           "alignItems":"flex-start"})

def _build_session_list(sessions,active_id):
    if not sessions: return [html.Div("No sessions yet.",style={"padding":"6px 14px","fontSize":"10px","color":"#aaa"})]
    return [_session_pill(s["id"],s["label"],s["id"]==active_id) for s in reversed(sessions)]


def _upsert_session(sessions,sid,history):
    for s in sessions:
        if s["id"]==sid:
            s["history"]=history
            if history: q=history[-1]["q"]; s["label"]=(q[:26]+"…") if len(q)>26 else q
            return
    label=(history[-1]["q"][:26]+"…") if history else f"Chat {sid}"
    sessions.append({"id":sid,"label":label,"history":history})


def _vaultix_topbar_title(history):
    if not history: return "Vaultix — ready"
    return history[-1]["q"][:55]+("…" if len(history[-1]["q"])>55 else "")



def tab_slm():
    sidebar=html.Div([
        html.Div([html.Div("Vaultix",style={"fontSize":"14px","fontWeight":"500","color":BRAND,"letterSpacing":"1px"}),html.Div("nbu-backup-cts-mini-0.1",style={"fontSize":"9px","color":"#aaa","marginTop":"2px"})],
                 style={"padding":"13px 14px 10px","borderBottom":"0.5px solid #e8e8e8"}),
        html.Div(dbc.Button("+ New chat",id="vaultix_new_chat",size="sm",style={"background":BRAND,"border":"none","borderRadius":"6px","fontSize":"11px","width":"calc(100% - 20px)","margin":"10px"})),
        html.Div("Sessions",style={"fontSize":"9px","color":"#aaa","padding":"6px 14px 3px","textTransform":"uppercase","letterSpacing":"0.8px"}),
        html.Div(id="vaultix_session_list",style={"maxHeight":"140px","overflowY":"auto"}),
        html.Div("Quick queries",style={"fontSize":"9px","color":"#aaa","padding":"10px 14px 3px","textTransform":"uppercase","letterSpacing":"0.8px"}),
        html.Div([html.Div([html.Span(icon,style={"marginRight":"5px","flexShrink":"0"}),html.Span(text,style={"lineHeight":"1.3"})],
            id={"type":"vaultix_quick","index":i},n_clicks=0,
            style={"padding":"6px 14px","fontSize":"10px","cursor":"pointer","color":"#555","display":"flex","alignItems":"flex-start","borderLeft":"2px solid transparent"})
            for i,(icon,text) in enumerate(QUICK_QUERIES)],style={"overflowY":"auto","flex":"1"}),
        html.Div([html.Div("Format key",style={"fontSize":"9px","color":"#aaa","marginBottom":"5px","textTransform":"uppercase","letterSpacing":"0.8px"}),
            html.Div([pill("CRITICAL","danger"),html.Span(" ≥ threshold",style={"fontSize":"9px","color":"#888","marginLeft":"4px"})],style={"marginBottom":"3px"}),
            html.Div([pill("WARNING","warning"),html.Span(" near limit",style={"fontSize":"9px","color":"#888","marginLeft":"4px"})],style={"marginBottom":"3px"}),
            html.Div([pill("OK","success"),html.Span(" within SLA",style={"fontSize":"9px","color":"#888","marginLeft":"4px"})]),
        ],style={"padding":"10px 14px","borderTop":"0.5px solid #e8e8e8"})
    ],style={"width":"200px","flexShrink":"0","background":"#f7f8fa","borderRight":"0.5px solid #e8e8e8","display":"flex","flexDirection":"column","height":"100%","overflowY":"hidden"})

    chat_panel=html.Div([
        html.Div([html.Div(id="vaultix_topbar_title",style={"fontSize":"12px","fontWeight":"500","color":"#333"}),html.Span("All 5 reports",style={"fontSize":"9px","background":"#e8f0fe","color":BRAND,"padding":"2px 8px","borderRadius":"10px"})],
                 style={"display":"flex","alignItems":"center","justifyContent":"space-between","padding":"9px 16px","borderBottom":"0.5px solid #e8e8e8"}),
        html.Div(id="vaultix_chat_window",children=[_welcome_bubble()],style={"flex":"1","overflowY":"auto","padding":"14px 16px","background":"#f7f8fa","display":"flex","flexDirection":"column","gap":"10px"}),
        html.Div(id="vaultix_status",style={"fontSize":"10px","color":"#aaa","padding":"3px 16px 4px","textAlign":"right","borderTop":"0.5px solid #f0f0f0","background":"#fff"}),
        html.Div([dcc.Input(id="slm_input",type="text",placeholder="Ask Vaultix anything…",n_submit=0,debounce=False,style={"flex":"1","border":"0.5px solid #d0d0d0","borderRadius":"8px","padding":"8px 12px","fontSize":"11px","height":"40px","fontFamily":"inherit","background":"#f7f8fa","color":"#333","outline":"none"}),
            html.Div([dbc.Button("Send ➤",id="slm_submit",style={"background":BRAND,"border":"none","borderRadius":"8px","fontSize":"11px","padding":"9px 14px"}),
                      dbc.Button("Clear",id="slm_clear",color="light",size="sm",style={"fontSize":"10px","borderRadius":"8px","padding":"9px 10px"})],style={"display":"flex","gap":"6px"})],
                style={"display":"flex","gap":"8px","padding":"10px 14px","borderTop":"0.5px solid #e8e8e8","background":"#fff","alignItems":"flex-end"}),
        html.Div(id="vaultix_quick_dynamic",
            style={"display":"flex","flexWrap":"wrap","gap":"4px",
                   "padding":"6px 10px","background":"#f0f4ff",
                   "borderTop":"0.5px solid #dde8ff",
                   "minHeight":"38px","alignItems":"center"}),
    ],style={"flex":"1","display":"flex","flexDirection":"column","minHeight":"0"})

    return html.Div([
        html.Div([sidebar,chat_panel],style={"display":"flex","border":"0.5px solid #e0e0e0","borderRadius":"10px","overflow":"hidden","height":"580px","background":"#fff"}),
    dcc.Store(id="slm_history",data=[]),dcc.Store(id="vaultix_sessions",data=[]),dcc.Store(id="vaultix_active_id",data=1),
        # fleet_group_mode store moved to top-level
        # download components moved to top-level layout
        # email_modal moved to top-level layout
    ],style={"padding":"24px"})


# ══════════════════════════════════════════════════════════════════════════════
# VAULTIX ENGINE
# ══════════════════════════════════════════════════════════════════════════════
def known_servers():
    df=qdf(DB_UNIFIED,"SELECT name FROM servers WHERE active=1 ORDER BY name")
    if not df.empty: return list(df["name"].str.lower())
    srvs=set()
    for db,sql in [(DB_LAG,"SELECT DISTINCT server FROM lag_history"),(DB_DISKPOOL,"SELECT DISTINCT server FROM diskpool_daily"),(DB_3RDSITE,"SELECT DISTINCT master_server FROM duplication_summary"),(DB_AIRGAP,"SELECT DISTINCT server FROM replication_status")]:
        d=qdf(db,sql)
        if not d.empty: srvs.update(d.iloc[:,0].str.lower().tolist())
    return sorted(srvs)


# ══════════════════════════════════════════════════════════════════════════
# Filtered answer functions — used when resolver returns multiple servers
# ══════════════════════════════════════════════════════════════════════════

def ans_lag_filtered(server_list, label):
    """Show lag table filtered to specific servers."""
    rows = []
    for srv in server_list:
        r = scalar_row(DB_UNIFIED,
            "SELECT * FROM lag_history WHERE server_name=? ORDER BY date DESC LIMIT 1",
            (srv,))
        if r:
            total    = int(r.get("total", 0))
            sla      = int(r.get("sla_threshold", SLA_THRESH))
            above    = bool(r.get("above_sla", False))
            pct      = round(total / sla * 100) if sla > 0 else 0
            pill_col = "#E24B4A" if above else ("#EF9F27" if pct > 80 else "#639922")
            pill_txt = "BREACH" if above else ("NEAR" if pct > 80 else "OK")
            rows.append(html.Div([
                html.Div([
                    html.Span(srv.upper(),
                        style={"fontSize":"10px","fontWeight":"600",
                               "color":BRAND,"minWidth":"160px"}),
                    html.Span(f"{total} imgs",
                        style={"fontSize":"10px","color":"#555",
                               "minWidth":"80px","textAlign":"right"}),
                    html.Span(f"{pct}% of SLA",
                        style={"fontSize":"9px","color":"#888",
                               "minWidth":"90px","textAlign":"right"}),
                    html.Span(pill_txt,
                        style={"background":pill_col,"color":"#fff",
                               "borderRadius":"8px","padding":"1px 8px",
                               "fontSize":"9px","fontWeight":"600",
                               "marginLeft":"auto"}),
                ], style={"display":"flex","alignItems":"center",
                          "gap":"10px","padding":"7px 12px",
                          "borderBottom":"0.5px solid #f0f0f0"}),
            ]))
        else:
            rows.append(html.Div(
                f"{srv.upper()} — no data",
                style={"padding":"6px 12px","fontSize":"10px","color":"#aaa"}))

    return html.Div([
        html.Div([
            html.Span(f"📉 Duplication Queue — {label}",
                style={"fontSize":"11px","fontWeight":"600","color":"#fff"}),
            html.Span(f"{len(server_list)} servers",
                style={"fontSize":"9px","color":"rgba(255,255,255,0.6)",
                       "marginLeft":"auto"}),
        ], style={"background":BRAND,"padding":"8px 12px",
                  "borderRadius":"6px 6px 0 0","display":"flex",
                  "alignItems":"center"}),
        html.Div(rows or [html.Div("No data",
            style={"padding":"10px","fontSize":"11px","color":"#aaa"})],
            style={"background":"#fff","border":"0.5px solid #e0e0e0",
                   "borderTop":"none","borderRadius":"0 0 6px 6px"}),
    ], style={"borderRadius":"6px","overflow":"hidden"})


def ans_3rd_filtered(server_list, label):
    """Show External Airgap Vault table filtered to specific servers."""
    rows = []
    for srv in server_list:
        r = scalar_row(DB_UNIFIED,
            "SELECT * FROM thirdsite_summary WHERE server_name=? "
            "ORDER BY report_date DESC LIMIT 1", (srv,))
        if r:
            tb       = float(r.get("total_data_tb") or 0)
            dedup    = float(r.get("avg_dedup_percent") or 0)
            worm     = float(r.get("max_worm_days") or 0)
            col      = "#E24B4A" if dedup < 30 else ("#EF9F27" if dedup < 50 else "#639922")
            rows.append(html.Div([
                html.Div([
                    html.Span(srv.upper(),
                        style={"fontSize":"10px","fontWeight":"600",
                               "color":BRAND,"minWidth":"160px"}),
                    html.Span(f"{tb:.2f} TB",
                        style={"fontSize":"10px","color":"#555",
                               "minWidth":"80px","textAlign":"right"}),
                    html.Span(f"Dedup {dedup:.1f}%",
                        style={"fontSize":"9px","color":col,
                               "minWidth":"90px","textAlign":"right"}),
                    html.Span(f"WORM {worm:.0f}d",
                        style={"fontSize":"9px",
                               "color":"#E24B4A" if worm < 30 else "#639922",
                               "marginLeft":"auto"}),
                ], style={"display":"flex","alignItems":"center",
                          "gap":"10px","padding":"7px 12px",
                          "borderBottom":"0.5px solid #f0f0f0"}),
            ]))
        else:
            rows.append(html.Div(f"{srv.upper()} — no data",
                style={"padding":"6px 12px","fontSize":"10px","color":"#aaa"}))

    return html.Div([
        html.Div([
            html.Span(f"🌐 External Airgap Vault — {label}",
                style={"fontSize":"11px","fontWeight":"600","color":"#fff"}),
        ], style={"background":BRAND,"padding":"8px 12px",
                  "borderRadius":"6px 6px 0 0","display":"flex",
                  "alignItems":"center"}),
        html.Div(rows or [html.Div("No data",
            style={"padding":"10px","fontSize":"11px","color":"#aaa"})],
            style={"background":"#fff","border":"0.5px solid #e0e0e0",
                   "borderTop":"none","borderRadius":"0 0 6px 6px"}),
    ], style={"borderRadius":"6px","overflow":"hidden"})


def ans_dp_filtered(server_list, label):
    """Show Storage Pool table filtered to specific servers — clean table format."""
    import sqlite3 as _sq
    con = _sq.connect(DB_UNIFIED)
    th = {"padding":"6px 10px","fontSize":"10px","textTransform":"uppercase",
          "letterSpacing":"0.4px","fontWeight":"500","color":"#64748b",
          "background":"#f8fafc","borderBottom":"0.5px solid #e2e8f0"}
    thr = {**th,"textAlign":"right"}
    thc = {**th,"textAlign":"center"}
    tbl_rows = []
    summary_lines = []
    for srv in server_list:
        rows_db = con.execute("""
            SELECT server_name, diskpool,
                   ROUND(used_tb,2), ROUND(total_tb,2),
                   ROUND(pct_used,1), health, status
            FROM diskpool_daily
            WHERE server_name=?
            AND run_date=(SELECT MAX(run_date) FROM diskpool_daily WHERE server_name=?)
            AND diskpool_group != 'Recovery Vault'
            ORDER BY pct_used DESC
        """, (srv, srv)).fetchall()
        if not rows_db:
            continue
        crit = sum(1 for r in rows_db if r[5]=='CRITICAL')
        warn = sum(1 for r in rows_db if r[5]=='WARNING')
        if crit:
            summary_lines.append(f"{srv.upper()}: {len(rows_db)} pools — {crit} CRITICAL")
        elif warn:
            summary_lines.append(f"{srv.upper()}: {len(rows_db)} pools — {warn} WARNING")
        for srv_n, pool, used, total, pct, health, status in rows_db:
            hc = "#A32D2D" if health=='CRITICAL' else "#854F0B" if health=='WARNING' else "#3B6D11"
            sc = "#3B6D11" if status=="Up" else "#A32D2D"
            tbl_rows.append(html.Tr([
                html.Td(srv_n.replace("cbkms",""),
                        style={"padding":"6px 10px","fontFamily":"monospace",
                               "fontSize":"10px","fontWeight":"500"}),
                html.Td(pool[:32]+"…" if len(pool)>32 else pool,
                        style={"padding":"6px 10px","fontSize":"10px","color":"#64748b"}),
                html.Td(f"{used} TB",
                        style={"padding":"6px 10px","textAlign":"right","fontWeight":"500"}),
                html.Td(f"{total} TB",
                        style={"padding":"6px 10px","textAlign":"right","color":"#64748b"}),
                html.Td(f"{pct}%",
                        style={"padding":"6px 10px","textAlign":"right",
                               "fontWeight":"500","color":hc}),
                html.Td(health,
                        style={"padding":"6px 10px","textAlign":"center",
                               "color":hc,"fontWeight":"500"}),
                html.Td(status,
                        style={"padding":"6px 10px","textAlign":"center",
                               "color":sc,"fontWeight":"500"}),
            ], style={"borderBottom":"0.5px solid #f1f5f9",
                      "background":"#FCEBEB" if health=='CRITICAL' else
                                   "#FAEEDA" if health=='WARNING' else "#fff"}))
    con.close()
    if not tbl_rows:
        return html.Div("💽 No storage pool data found.",
                        style={"padding":"12px","color":"#94a3b8"})
    summary = " · ".join(summary_lines) if summary_lines else               f"All pools healthy across {len(server_list)} server(s)"
    return html.Div([
        html.Div([
            html.Span("💽 ", style={"fontSize":"13px","marginRight":"7px"}),
            html.Span(f"Storage Pools — {label}",
                      style={"fontSize":"12px","fontWeight":"500"}),
        ], style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
        html.Div(summary,
                 style={"fontSize":"11px","color":"#64748b",
                        "marginBottom":"10px","lineHeight":"1.5"}),
        html.Table([
            html.Thead(html.Tr([
                html.Th("Server",style=th),
                html.Th("Pool",style=th),
                html.Th("Used TB",style=thr),
                html.Th("Total TB",style=thr),
                html.Th("% Used",style=thr),
                html.Th("Health",style=thc),
                html.Th("Status",style=thc),
            ])),
            html.Tbody(tbl_rows),
        ], style={"width":"100%","borderCollapse":"collapse",
                  "border":"0.5px solid #e2e8f0","borderRadius":"8px",
                  "overflow":"hidden"}),
    ])


def ans_catalog_filtered(server_list, label):
    """Show Catalog Health filtered to specific servers."""
    rows = []
    for srv in server_list:
        r = scalar_row(DB_UNIFIED,
            "SELECT * FROM catalog_health WHERE server_name=? "
            "ORDER BY checked_at DESC LIMIT 1", (srv,))
        if r:
            status = str(r.get("catalog_status",""))
            score  = float(r.get("health_score") or 0)
            col    = "#E24B4A" if status == "ERROR" else                      ("#EF9F27" if status == "DELAYED" else "#639922")
            rows.append(html.Div([
                html.Div([
                    html.Span(srv.upper(),
                        style={"fontSize":"10px","fontWeight":"600",
                               "color":BRAND,"minWidth":"160px"}),
                    html.Span(status or "OK",
                        style={"fontSize":"10px","color":col,
                               "fontWeight":"600","minWidth":"80px"}),
                    html.Span(f"BHI {score:.0f}/100",
                        style={"fontSize":"9px","color":"#888",
                               "marginLeft":"auto"}),
                ], style={"display":"flex","alignItems":"center",
                          "gap":"10px","padding":"7px 12px",
                          "borderBottom":"0.5px solid #f0f0f0"}),
            ]))
        else:
            rows.append(html.Div(f"{srv.upper()} — no data",
                style={"padding":"6px 12px","fontSize":"10px","color":"#aaa"}))

    return html.Div([
        html.Div([
            html.Span(f"📋 Catalog Health — {label}",
                style={"fontSize":"11px","fontWeight":"600","color":"#fff"}),
        ], style={"background":BRAND,"padding":"8px 12px",
                  "borderRadius":"6px 6px 0 0","display":"flex",
                  "alignItems":"center"}),
        html.Div(rows or [html.Div("No data",
            style={"padding":"10px","fontSize":"11px","color":"#aaa"})],
            style={"background":"#fff","border":"0.5px solid #e0e0e0",
                   "borderTop":"none","borderRadius":"0 0 6px 6px"}),
    ], style={"borderRadius":"6px","overflow":"hidden"})


def ans_airgap_filtered(server_list, label):
    """Show Internal Airgap Vault filtered to specific servers."""
    rows = []
    for srv in server_list:
        r = scalar_row(DB_UNIFIED,
            "SELECT * FROM airgap_replication WHERE server_name=? "
            "ORDER BY checked_at DESC LIMIT 1", (srv,))
        if r:
            status  = str(r.get("replication_status",""))
            backlog = int(r.get("image_count") or 0)
            col     = "#E24B4A" if backlog > 50 else                       ("#EF9F27" if backlog > 0 else "#639922")
            rows.append(html.Div([
                html.Div([
                    html.Span(srv.upper(),
                        style={"fontSize":"10px","fontWeight":"600",
                               "color":BRAND,"minWidth":"160px"}),
                    html.Span(status or "—",
                        style={"fontSize":"10px","color":"#555",
                               "minWidth":"100px"}),
                    html.Span(f"Backlog: {backlog}",
                        style={"fontSize":"9px","color":col,
                               "fontWeight":"600","marginLeft":"auto"}),
                ], style={"display":"flex","alignItems":"center",
                          "gap":"10px","padding":"7px 12px",
                          "borderBottom":"0.5px solid #f0f0f0"}),
            ]))
        else:
            rows.append(html.Div(f"{srv.upper()} — no data",
                style={"padding":"6px 12px","fontSize":"10px","color":"#aaa"}))

    return html.Div([
        html.Div([
            html.Span(f"🔒 Internal Airgap Vault — {label}",
                style={"fontSize":"11px","fontWeight":"600","color":"#fff"}),
        ], style={"background":BRAND,"padding":"8px 12px",
                  "borderRadius":"6px 6px 0 0","display":"flex",
                  "alignItems":"center"}),
        html.Div(rows or [html.Div("No data",
            style={"padding":"10px","fontSize":"11px","color":"#aaa"})],
            style={"background":"#fff","border":"0.5px solid #e0e0e0",
                   "borderTop":"none","borderRadius":"0 0 6px 6px"}),
    ], style={"borderRadius":"6px","overflow":"hidden"})


def ans_group_full(server_list, label):
    """Full report for a group of servers — stacked cards."""
    cards = []
    for srv in server_list:
        try:
            card = ans_srv_full(srv)
            cards.append(html.Div(card,
                style={"marginBottom":"10px"}))
        except Exception as e:
            cards.append(html.Div(
                f"{srv.upper()}: {e}",
                style={"padding":"8px","color":"#E24B4A",
                       "fontSize":"10px"}))
    header = html.Div([
        html.Span(f"📊 Group Report — {label}",
            style={"fontSize":"11px","fontWeight":"600","color":"#fff"}),
        html.Span(f"{len(server_list)} servers",
            style={"fontSize":"9px","color":"rgba(255,255,255,0.6)",
                   "marginLeft":"auto"}),
    ], style={"background":BRAND,"padding":"8px 12px",
              "borderRadius":"6px","display":"flex",
              "alignItems":"center","marginBottom":"8px"})
    return html.Div([header] + cards)


def safe_qdf(db, sql, params=()):
    """Safe DataFrame query — returns empty DataFrame on error."""
    try:
        import sqlite3
        import pandas as pd
        con = sqlite3.connect(db)
        df  = pd.read_sql_query(sql, con, params=params)
        con.close()
        return df
    except Exception:
        import pandas as pd
        return pd.DataFrame()


def scalar_row(db, sql, params=()):
    """Return single row as dict — helper for filtered functions."""
    try:
        import sqlite3
        con = sqlite3.connect(db)
        con.row_factory = sqlite3.Row
        row = con.execute(sql, params).fetchone()
        con.close()
        return dict(row) if row else None
    except Exception:
        return None




def tab_training():
    """Training Centre — operator corrections, gap analysis, retraining."""
    import sqlite3
    db = "/usr/nbu-cts-v2/db/nbu_unified.db"

    # ── Load unanswered queries ───────────────────────────────────────────
    try:
        con = sqlite3.connect(db)
        unanswered = con.execute(
            "SELECT question, COUNT(*) AS freq, MAX(asked_at) AS last_seen "
            "FROM vaultix_messages WHERE was_answered=0 "
            "GROUP BY question ORDER BY freq DESC LIMIT 20"
        ).fetchall()
        wrong = con.execute(
            "SELECT question, answer, intent, submitted_at AS asked_at "
            "FROM corrections_corpus WHERE submitted_by='thumbs_down' "
            "UNION ALL "
            "SELECT question, answer, intent, asked_at "
            "FROM vaultix_messages WHERE was_helpful=0 "
            "ORDER BY asked_at DESC LIMIT 20"
        ).fetchall()
        corpus_size = con.execute(
            "SELECT COUNT(*) FROM vaultix_messages"
        ).fetchone()[0]
        corrections = con.execute(
            "SELECT COUNT(*) FROM corrections_corpus WHERE trained=0"
        ).fetchone()[0]
        synonyms = con.execute(
            "SELECT COUNT(*) FROM synonym_map"
        ).fetchone()[0]
        last_train = con.execute(
            "SELECT MAX(trained_at) FROM training_log"
        ).fetchone()[0] if con.execute(
            "SELECT name FROM sqlite_master WHERE type=\'table\' "
            "AND name=\'training_log\'"
        ).fetchone() else "Never"
        con.close()
    except Exception as e:
        unanswered, wrong = [], []
        corpus_size, corrections, synonyms = 0, 0, 0
        last_train = f"Error: {e}"

    # ── Panel 1: Unanswered Queries ───────────────────────────────────────
    unans_rows = []
    for q, freq, last in unanswered:
        unans_rows.append(html.Div([
            html.Div([
                html.Span(q[:80], style={"fontSize":"11px","color":"#333",
                    "flex":"1"}),
                html.Span(f"×{freq}",
                    style={"fontSize":"10px","color":"#E24B4A",
                           "fontWeight":"600","marginLeft":"8px"}),
                html.Span(str(last)[:10] if last else "",
                    style={"fontSize":"9px","color":"#aaa","marginLeft":"8px"}),
                html.Button("✏️ Correct",
                    id={"type":"train_correct_btn","index":q[:100]},
                    n_clicks=0,
                    style={"fontSize":"9px","padding":"2px 8px",
                           "borderRadius":"4px","border":"0.5px solid #1A3C5E",
                           "background":"#fff","color":"#1A3C5E",
                           "cursor":"pointer","marginLeft":"8px"}),
            ], style={"display":"flex","alignItems":"center",
                      "padding":"7px 12px",
                      "borderBottom":"0.5px solid #f0f0f0"}),
        ]))

    panel_unans = html.Div([
        html.Div("❓ Unanswered Queries",
            style={"background":"#1A3C5E","color":"#fff","padding":"8px 12px",
                   "fontSize":"11px","fontWeight":"600",
                   "borderRadius":"6px 6px 0 0"}),
        html.Div(unans_rows or [html.Div(
            "No unanswered queries yet — Vaultix is handling everything! 🎉",
            style={"padding":"16px","fontSize":"11px","color":"#888"})],
            style={"background":"#fff","border":"0.5px solid #e0e0e0",
                   "borderTop":"none","borderRadius":"0 0 6px 6px",
                   "maxHeight":"250px","overflowY":"auto"}),
    ], style={"marginBottom":"12px"})

    # ── Panel 2: Wrong Answer Queue ───────────────────────────────────────
    wrong_rows = []
    for q, a, intent, ts in wrong:
        wrong_rows.append(html.Div([
            html.Div([
                html.Span(f"[{intent}]",
                    style={"fontSize":"9px","color":"#fff",
                           "background":"#E24B4A","borderRadius":"4px",
                           "padding":"1px 6px","marginRight":"8px"}),
                html.Span(q[:70],
                    style={"fontSize":"11px","color":"#333","flex":"1"}),
                html.Span(str(ts)[:10] if ts else "",
                    style={"fontSize":"9px","color":"#aaa"}),
            ], style={"display":"flex","alignItems":"center",
                      "padding":"7px 12px",
                      "borderBottom":"0.5px solid #f0f0f0"}),
        ]))

    panel_wrong = html.Div([
        html.Div("👎 Wrong Answer Queue",
            style={"background":"#1A3C5E","color":"#fff","padding":"8px 12px",
                   "fontSize":"11px","fontWeight":"600",
                   "borderRadius":"6px 6px 0 0"}),
        html.Div(wrong_rows or [html.Div(
            "No wrong answers flagged yet.",
            style={"padding":"16px","fontSize":"11px","color":"#888"})],
            style={"background":"#fff","border":"0.5px solid #e0e0e0",
                   "borderTop":"none","borderRadius":"0 0 6px 6px",
                   "maxHeight":"200px","overflowY":"auto"}),
    ], style={"marginBottom":"12px"})

    # ── Panel 3: Add Correction ───────────────────────────────────────────
    panel_correct = html.Div([
        html.Div("✏️ Add / Correct Answer",
            style={"background":"#1A3C5E","color":"#fff","padding":"8px 12px",
                   "fontSize":"11px","fontWeight":"600",
                   "borderRadius":"6px 6px 0 0"}),
        html.Div([
            html.Div([
                html.Label("Question",
                    style={"fontSize":"10px","color":"#666",
                           "marginBottom":"4px","display":"block"}),
                dcc.Input(id="tc_question", type="text",
                    placeholder="What query should Vaultix understand?",
                    style={"width":"100%","padding":"6px","fontSize":"11px",
                           "border":"0.5px solid #ccc","borderRadius":"4px",
                           "marginBottom":"8px"}),
                html.Label("Correct Answer",
                    style={"fontSize":"10px","color":"#666",
                           "marginBottom":"4px","display":"block"}),
                dcc.Textarea(id="tc_answer",
                    placeholder="What should Vaultix reply?",
                    style={"width":"100%","padding":"6px","fontSize":"11px",
                           "border":"0.5px solid #ccc","borderRadius":"4px",
                           "height":"80px","resize":"vertical",
                           "marginBottom":"8px"}),
                html.Div([
                    dcc.Dropdown(id="tc_report_type",
                        options=[
                            {"label":"Duplication Queue","value":"lag"},
                            {"label":"Storage Pools",    "value":"diskpool"},
                            {"label":"External Airgap",  "value":"3rdsite"},
                            {"label":"Internal Airgap",  "value":"airgap"},
                            {"label":"Catalog Health",   "value":"catalog"},
                            {"label":"General",          "value":"general"},
                        ],
                        placeholder="Report type",
                        style={"fontSize":"11px","flex":"1",
                               "marginRight":"8px"}),
                    dcc.Input(id="tc_server", type="text",
                        placeholder="Server (optional)",
                        style={"padding":"6px","fontSize":"11px",
                               "border":"0.5px solid #ccc",
                               "borderRadius":"4px","flex":"1"}),
                ], style={"display":"flex","marginBottom":"8px"}),
                html.Button("💾 Save Correction",
                    id="tc_save_btn", n_clicks=0,
                    style={"background":"#1A3C5E","color":"#fff",
                           "border":"none","borderRadius":"6px",
                           "padding":"6px 16px","fontSize":"11px",
                           "cursor":"pointer","fontWeight":"500",
                           "marginRight":"8px"}),
                html.Span(id="tc_save_status",
                    style={"fontSize":"11px","color":"#639922"}),
            ], style={"padding":"12px"}),
        ], style={"background":"#fff","border":"0.5px solid #e0e0e0",
                  "borderTop":"none","borderRadius":"0 0 6px 6px"}),
    ], style={"marginBottom":"12px"})

    # ── Panel 4: Synonym Manager ──────────────────────────────────────────
    panel_synonym = html.Div([
        html.Div("🔤 Synonym Manager",
            style={"background":"#1A3C5E","color":"#fff","padding":"8px 12px",
                   "fontSize":"11px","fontWeight":"600",
                   "borderRadius":"6px 6px 0 0"}),
        html.Div([
            html.Div([
                html.Div([
                    dcc.Input(id="tc_variant", type="text",
                        placeholder="User term (e.g. lag, 3rd site, airgap)",
                        style={"flex":"1","padding":"6px","fontSize":"11px",
                               "border":"0.5px solid #ccc","borderRadius":"4px",
                               "marginRight":"8px"}),
                    dcc.Input(id="tc_canonical", type="text",
                        placeholder="Canonical term (e.g. Duplication Queue)",
                        style={"flex":"1","padding":"6px","fontSize":"11px",
                               "border":"0.5px solid #ccc","borderRadius":"4px",
                               "marginRight":"8px"}),
                    html.Button("➕ Add",
                        id="tc_synonym_btn", n_clicks=0,
                        style={"background":"#639922","color":"#fff",
                               "border":"none","borderRadius":"6px",
                               "padding":"6px 12px","fontSize":"11px",
                               "cursor":"pointer"}),
                ], style={"display":"flex","marginBottom":"8px"}),
                html.Span(id="tc_synonym_status",
                    style={"fontSize":"11px","color":"#639922"}),
                html.Div(id="tc_synonym_list",
                    style={"marginTop":"8px","fontSize":"10px","color":"#666"}),
            ], style={"padding":"12px"}),
        ], style={"background":"#fff","border":"0.5px solid #e0e0e0",
                  "borderTop":"none","borderRadius":"0 0 6px 6px"}),
    ], style={"marginBottom":"12px"})

    # ── Panel 5: Training Status + Retrain ───────────────────────────────
    panel_status = html.Div([
        html.Div("🧠 Training Status",
            style={"background":"#1A3C5E","color":"#fff","padding":"8px 12px",
                   "fontSize":"11px","fontWeight":"600",
                   "borderRadius":"6px 6px 0 0"}),
        html.Div([
            html.Div([
                html.Div([
                    html.Div([
                        html.Div(str(corpus_size),
                            style={"fontSize":"22px","fontWeight":"700",
                                   "color":"#1A3C5E"}),
                        html.Div("Chat messages",
                            style={"fontSize":"9px","color":"#888"}),
                    ], style={"flex":"1","textAlign":"center","padding":"10px",
                              "background":"#f8f9fb","borderRadius":"6px",
                              "marginRight":"8px"}),
                    html.Div([
                        html.Div(str(corrections),
                            style={"fontSize":"22px","fontWeight":"700",
                                   "color":"#EF9F27"}),
                        html.Div("Pending corrections",
                            style={"fontSize":"9px","color":"#888"}),
                    ], style={"flex":"1","textAlign":"center","padding":"10px",
                              "background":"#f8f9fb","borderRadius":"6px",
                              "marginRight":"8px"}),
                    html.Div([
                        html.Div(str(synonyms),
                            style={"fontSize":"22px","fontWeight":"700",
                                   "color":"#639922"}),
                        html.Div("Synonyms defined",
                            style={"fontSize":"9px","color":"#888"}),
                    ], style={"flex":"1","textAlign":"center","padding":"10px",
                              "background":"#f8f9fb","borderRadius":"6px"}),
                ], style={"display":"flex","marginBottom":"12px"}),
                html.Div([
                    html.Span("Last retrain: ",
                        style={"fontSize":"10px","color":"#888"}),
                    html.Span(str(last_train)[:19] if last_train else "Never",
                        style={"fontSize":"10px","color":"#333",
                               "fontWeight":"500"}),
                ], style={"marginBottom":"12px"}),
                html.Button("🔄 Retrain Now",
                    id="tc_retrain_btn", n_clicks=0,
                    style={"background":"#1A3C5E","color":"#fff",
                           "border":"none","borderRadius":"6px",
                           "padding":"8px 20px","fontSize":"11px",
                           "cursor":"pointer","fontWeight":"500",
                           "marginRight":"12px"}),
                html.Span(id="tc_retrain_status",
                    style={"fontSize":"11px","color":"#639922"}),
            ], style={"padding":"12px"}),
        ], style={"background":"#fff","border":"0.5px solid #e0e0e0",
                  "borderTop":"none","borderRadius":"0 0 6px 6px"}),
    ])

    return html.Div([
        html.Div("🎓 Vaultix Training Centre",
            style={"fontSize":"14px","fontWeight":"700","color":"#1A3C5E",
                   "marginBottom":"4px"}),
        html.Div("Review unanswered queries, correct wrong answers, "
                 "manage synonyms and retrain the model.",
            style={"fontSize":"11px","color":"#888","marginBottom":"16px"}),
        dbc.Row([
            dbc.Col([panel_unans, panel_wrong], md=6),
            dbc.Col([panel_correct, panel_synonym, panel_status], md=6),
        ]),
    ], style={"padding":"24px"})



def _wrap_with_narrative(component, srv, report_type):
    """Wrap a structured answer with a narrative paragraph above it."""
    if not _INTELLIGENCE_LOADED:
        return component
    try:
        from narrative_engine import (lag_narrative, diskpool_narrative,
            ext_vault_narrative, int_vault_narrative, catalog_narrative)
        import pandas as pd, sqlite3 as _sq

        txt = None

        if report_type == "lag":
            r = _qrow_local(DB_UNIFIED,
                "SELECT total, above_sla, not_started_remote, "
                "in_process_remote, not_started_duplicate, in_process_duplicate "
                "FROM lag_history WHERE server_name=? ORDER BY date DESC LIMIT 1",
                (srv,))
            if r:
                txt = lag_narrative(srv,
                    int(r.get("total") or 0), SLA_THRESH,
                    int(r.get("not_started_remote") or 0),
                    int(r.get("in_process_remote") or 0),
                    int(r.get("not_started_duplicate") or 0),
                    int(r.get("in_process_duplicate") or 0),
                    above_sla=bool(r.get("above_sla", 0)))

        elif report_type == "diskpool":
            con = _sq.connect(DB_UNIFIED)
            df = pd.read_sql_query(
                "SELECT diskpool, used_tb, total_tb, "
                "ROUND(used_tb*100.0/NULLIF(total_tb,0),1) AS pct_used "
                "FROM diskpool_daily WHERE server_name=? "
                "AND run_date=(SELECT MAX(run_date) FROM diskpool_daily "
                "WHERE server_name=?) ORDER BY pct_used DESC",
                con, params=(srv, srv))
            con.close()
            if not df.empty:
                txt = diskpool_narrative(srv, df)

        elif report_type == "3rdsite":
            r = _qrow_local(DB_UNIFIED,
                "SELECT total_data_tb, avg_gbps, avg_dedup_percent, max_worm_days "
                "FROM thirdsite_summary WHERE server_name=? "
                "ORDER BY report_date DESC LIMIT 1", (srv,))
            if r:
                txt = ext_vault_narrative(srv,
                    float(r.get("total_data_tb") or 0),
                    float(r.get("avg_gbps") or 0),
                    float(r.get("avg_dedup_percent") or 0),
                    float(r.get("max_worm_days") or 0))

        elif report_type == "catalog":
            r = _qrow_local(DB_UNIFIED,
                "SELECT catalog_status, health_score, catalog_date, "
                "catalog_size_gb, vvr_status, anomaly_detected, anomaly_reason "
                "FROM catalog_health WHERE server_name=? "
                "ORDER BY checked_at DESC LIMIT 1", (srv,))
            if r:
                txt = catalog_narrative(srv,
                    str(r.get("catalog_status") or ""),
                    float(r.get("health_score") or 0),
                    r.get("catalog_date",""),
                    float(r.get("catalog_size_gb") or 0),
                    str(r.get("vvr_status") or ""),
                    bool(r.get("anomaly_detected")),
                    str(r.get("anomaly_reason") or ""))

        elif report_type == "airgap":
            r   = _qrow_local(DB_UNIFIED,
                "SELECT status, image_count, air_master "
                "FROM airgap_replication WHERE server_name=? "
                "ORDER BY checked_at DESC LIMIT 1", (srv,))
            ret = _qrow_local(DB_UNIFIED,
                "SELECT weekly_compliant, monthly_compliant, yearly_compliant, "
                "weekly_backups, monthly_backups, yearly_backups "
                "FROM airgap_retention WHERE server_name=? "
                "ORDER BY checked_at DESC LIMIT 1", (srv,))
            if r:
                txt = int_vault_narrative(srv,
                    int(r.get("image_count") or 0),
                    str(r.get("status") or ""),
                    str(r.get("air_master") or ""),
                    bool(ret.get("weekly_compliant")) if ret else False,
                    bool(ret.get("monthly_compliant")) if ret else False,
                    bool(ret.get("yearly_compliant")) if ret else False,
                    int(ret.get("weekly_backups") or 0) if ret else 0,
                    int(ret.get("monthly_backups") or 0) if ret else 0,
                    int(ret.get("yearly_backups") or 0) if ret else 0)

        if not txt:
            return component

        return html.Div([
            html.Div(txt, style={
                "fontSize":"11px","color":"#2c3e50","lineHeight":"1.8",
                "marginBottom":"12px","padding":"12px 15px",
                "background":"#eef4ff","borderRadius":"8px",
                "borderLeft":f"4px solid {BRAND}",
                "boxShadow":"0 1px 3px rgba(0,0,0,0.05)"}),
            component
        ])

    except Exception:
        return component




def tab_media_servers(master_f='all', status_f='all'):
    """Media Servers — executive overview with client-side filtering."""
    import sqlite3 as _sq, json as _js

    try:
        con = _sq.connect(DB_UNIFIED)
        fleet = con.execute("""
            SELECT COUNT(DISTINCT media_server),COUNT(DISTINCT master_name),
                   SUM(total_jobs),ROUND(SUM(data_tb),1),SUM(active_jobs),
                   SUM(CASE WHEN ai_status='HIGH_LOAD'    THEN 1 ELSE 0 END),
                   SUM(CASE WHEN ai_status='UNDERUTILIZED'THEN 1 ELSE 0 END),
                   SUM(CASE WHEN ai_status='ANOMALY'      THEN 1 ELSE 0 END),
                   SUM(CASE WHEN ai_status='BALANCED'     THEN 1 ELSE 0 END),
                   MAX(timestamp)
            FROM media_metrics_unified m1
            WHERE timestamp=(SELECT MAX(m2.timestamp)
                             FROM media_metrics_unified m2
                             WHERE m2.media_server=m1.media_server)
        """).fetchone()

        masters = con.execute("""
            SELECT master_name,
                   COUNT(DISTINCT media_server) AS servers,
                   SUM(total_jobs) AS jobs, ROUND(SUM(data_tb),1) AS data_tb,
                   SUM(active_jobs) AS active,
                   SUM(CASE WHEN ai_status='HIGH_LOAD'     THEN 1 ELSE 0 END) AS hl,
                   SUM(CASE WHEN ai_status='UNDERUTILIZED' THEN 1 ELSE 0 END) AS ul,
                   SUM(CASE WHEN ai_status='ANOMALY'       THEN 1 ELSE 0 END) AS an,
                   SUM(CASE WHEN ai_status='BALANCED'      THEN 1 ELSE 0 END) AS bal,
                   ROUND(AVG(CASE WHEN efficiency>0 THEN efficiency END),4) AS avg_eff
            FROM media_metrics_unified m1
            WHERE timestamp=(SELECT MAX(m2.timestamp)
                             FROM media_metrics_unified m2
                             WHERE m2.media_server=m1.media_server)
            GROUP BY master_name ORDER BY hl DESC, jobs DESC
        """).fetchall()

        top_servers = con.execute("""
            SELECT master_name, media_server, total_jobs,
                   ROUND(data_tb,2), active_jobs,
                   ROUND(efficiency,4), ROUND(dup_ratio,3), ai_status
            FROM media_metrics_unified m1
            WHERE timestamp=(SELECT MAX(t2.timestamp)
                             FROM media_metrics_unified t2
                             WHERE t2.media_server=m1.media_server)
            ORDER BY active_jobs DESC, total_jobs DESC LIMIT 30
        """).fetchall()

        heat_data = {}
        for row in masters:
            mn = row[0]
            svrs = con.execute("""
                SELECT media_server, ai_status FROM media_metrics_unified
                WHERE master_name=?
                AND timestamp=(SELECT MAX(t2.timestamp)
                               FROM media_metrics_unified t2
                               WHERE t2.media_server=media_metrics_unified.media_server)
                ORDER BY ai_status, media_server LIMIT 24
            """, (mn,)).fetchall()
            heat_data[mn] = [{"ms": r[0].split(".")[0][-10:], "st": r[1]} for r in svrs]
        con.close()

    except Exception as e:
        return html.Div(f"Media server data unavailable: {e}",
                        style={"padding":"24px","color":"#E24B4A"})

    if not fleet or (fleet[0] or 0) == 0:
        return html.Div("No media server data. Run sync_media_servers.py",
                        style={"padding":"24px","color":"#94a3b8"})

    total_s,total_m,total_j,total_tb,active,hl,ul,an,bal,latest = fleet
    total_s=int(total_s or 0); total_m=int(total_m or 0)
    total_j=int(total_j or 0); total_tb=float(total_tb or 0)
    active=int(active or 0); hl=int(hl or 0); ul=int(ul or 0)
    an=int(an or 0); bal=int(bal or 0); latest=str(latest or "")[:16]
    health_pct=round(bal/max(total_s,1)*100)

    # Build master cards data for JS
    cards_data = []
    for row in masters:
        mn,svrs,jobs,tb,act,m_hl,m_ul,m_an,m_bal,m_eff = row
        state = "hl" if int(m_hl or 0)>0 else "an" if int(m_an or 0)>0 else "ok"
        cards_data.append({
            "name": mn, "short": mn.replace("cbkms","").upper(),
            "servers": int(svrs or 0), "jobs": int(jobs or 0),
            "tb": float(tb or 0), "active": int(act or 0),
            "eff": float(m_eff or 0),
            "hl": int(m_hl or 0), "ul": int(m_ul or 0),
            "an": int(m_an or 0), "bal": int(m_bal or 0),
            "state": state,
            "heat": heat_data.get(mn, [])
        })

    top_data = [{"master": r[0].replace("cbkms",""),
                 "server": r[1].split(".")[0] if r[1] else "—",
                 "jobs": int(r[2] or 0), "tb": float(r[3] or 0),
                 "active": int(r[4] or 0), "eff": float(r[5] or 0),
                 "dr": float(r[6] or 0), "status": r[7] or ""}
                for r in top_servers]

    cards_json = _js.dumps(cards_data)
    top_json   = _js.dumps(top_data)

    html_src = f"""<!DOCTYPE html><html><head>
<meta charset="utf-8">
<style>
*{{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,-apple-system,sans-serif;}}
body{{background:#f8fafc;padding:20px;color:#1e293b;}}
.kpi-row{{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:20px;}}
.kpi{{background:#fff;border:0.5px solid #e2e8f0;border-radius:10px;padding:14px 16px;}}
.kpi-v{{font-size:26px;font-weight:500;line-height:1;}}
.kpi-l{{font-size:10px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.4px;margin:5px 0 4px;}}
.kpi-s{{font-size:11px;font-weight:500;}}
.legend{{display:flex;align-items:center;gap:8px;margin-bottom:14px;font-size:11px;}}
.lbl{{font-size:11px;color:#94a3b8;margin-right:4px;}}
.pill{{padding:3px 10px;border-radius:20px;font-size:10px;font-weight:500;cursor:pointer;border:none;}}
.pill-hl{{background:#FCEBEB;color:#A32D2D;}}
.pill-an{{background:#FAEEDA;color:#854F0B;}}
.pill-ok{{background:#EAF3DE;color:#3B6D11;}}
.pill-ul{{background:#EAF3DE;color:#3B6D11;}}
.pill-bl{{background:#E6F1FB;color:#185FA5;}}
.filter-row{{display:flex;gap:8px;margin-bottom:16px;align-items:center;}}
.fbtn{{padding:5px 14px;border-radius:20px;border:0.5px solid #e2e8f0;
       background:#fff;color:#64748b;font-size:11px;cursor:pointer;font-weight:500;}}
.fbtn.active{{background:#185FA5;color:#fff;border-color:#185FA5;}}
.grid{{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px;}}
.card{{background:#fff;border:0.5px solid #e2e8f0;border-radius:10px;overflow:hidden;}}
.card-head{{padding:10px 14px;border-bottom:0.5px solid #f1f5f9;}}
.card-name{{font-size:13px;font-weight:500;display:flex;align-items:center;gap:8px;}}
.card-sub{{font-size:10px;color:#94a3b8;margin-top:2px;}}
.badge{{font-size:10px;font-weight:500;padding:2px 8px;border-radius:20px;}}
.metrics{{display:grid;grid-template-columns:repeat(4,1fr);border-bottom:0.5px solid #f1f5f9;background:#f8fafc;}}
.met{{padding:10px 4px;text-align:center;border-right:0.5px solid #f1f5f9;}}
.met:last-child{{border-right:none;}}
.met-v{{font-size:17px;font-weight:500;}}
.met-l{{font-size:9px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.3px;margin-top:3px;}}
.heat{{padding:8px 12px;display:flex;flex-wrap:wrap;gap:3px;border-bottom:0.5px solid #f1f5f9;min-height:34px;}}
.htag{{font-size:9px;padding:2px 5px;border-radius:3px;color:#fff;}}
.pills{{padding:8px 12px;display:flex;flex-wrap:wrap;gap:5px;}}
.section-hdr{{font-size:13px;font-weight:500;margin-bottom:10px;}}
.tbl-wrap{{background:#fff;border:0.5px solid #e2e8f0;border-radius:10px;overflow:hidden;}}
.tbl-hdr{{padding:12px 16px;border-bottom:0.5px solid #f1f5f9;font-size:13px;font-weight:500;}}
table{{width:100%;border-collapse:collapse;}}
th{{padding:7px 12px;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;
    font-weight:500;color:#64748b;background:#f8fafc;border-bottom:0.5px solid #e2e8f0;}}
th.r{{text-align:right;}}
td{{padding:7px 12px;font-size:11px;border-bottom:0.5px solid #f8fafc;}}
td.r{{text-align:right;}}
td.mono{{font-family:monospace;font-size:10px;color:#64748b;}}
tr:hover td{{background:#f8fafc;}}
tr:last-child td{{border-bottom:none;}}
</style></head><body>

<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;">
  <div>
    <div style="font-size:18px;font-weight:500;">Media server intelligence</div>
    <div style="font-size:11px;color:#94a3b8;margin-top:3px;">{total_m} masters · {total_s} servers · updated {latest}</div>
  </div>
  <div style="display:flex;gap:8px;">
    {"<span class='pill pill-hl'>"+str(hl)+" high load</span>" if hl>0 else ""}
    {"<span class='pill pill-an'>"+str(an)+" anomalies</span>" if an>0 else ""}
  </div>
</div>

<div class="kpi-row">
  <div class="kpi" style="border-left:3px solid #185FA5;">
    <div class="kpi-v">{total_s}</div>
    <div class="kpi-l">Media servers</div>
    <div class="kpi-s" style="color:#185FA5;">{total_m} masters</div>
  </div>
  <div class="kpi" style="border-left:3px solid {'#E24B4A' if hl>0 else '#639922'};">
    <div class="kpi-v" style="color:{'#A32D2D' if hl>0 else '#3B6D11'};">{hl}</div>
    <div class="kpi-l">High load</div>
    <div class="kpi-s" style="color:{'#A32D2D' if hl>0 else '#3B6D11'};">{round(hl/max(total_s,1)*100)}% of fleet</div>
  </div>
  <div class="kpi" style="border-left:3px solid {'#EF9F27' if an>0 else '#639922'};">
    <div class="kpi-v" style="color:{'#854F0B' if an>0 else '#3B6D11'};">{an}</div>
    <div class="kpi-l">Anomalies</div>
    <div class="kpi-s" style="color:{'#854F0B' if an>0 else '#3B6D11'};">{"needs review" if an>0 else "all clear"}</div>
  </div>
  <div class="kpi" style="border-left:3px solid #639922;">
    <div class="kpi-v" style="color:#3B6D11;">{health_pct}%</div>
    <div class="kpi-l">Balanced</div>
    <div class="kpi-s" style="color:#3B6D11;">{bal} healthy</div>
  </div>
  <div class="kpi" style="border-left:3px solid #185FA5;">
    <div class="kpi-v">{total_tb} TB</div>
    <div class="kpi-l">Data processed</div>
    <div class="kpi-s" style="color:#185FA5;">last 24h</div>
  </div>
  <div class="kpi" style="border-left:3px solid {'#E24B4A' if active>50 else '#185FA5'};">
    <div class="kpi-v">{total_j:,}</div>
    <div class="kpi-l">Total jobs</div>
    <div class="kpi-s" style="color:{'#A32D2D' if active>50 else '#475569'};">active: {active}</div>
  </div>
</div>

<div style="display:flex;align-items:center;gap:6px;margin-bottom:14px;flex-wrap:wrap;">
  <span style="font-size:11px;color:#94a3b8;">Status key:</span>
  <span class="pill pill-hl">High load</span>
  <span class="pill pill-an">Anomaly</span>
  <span class="pill pill-bl">Balanced</span>
  <span class="pill pill-ok">Underutilised</span>
</div>

<div class="filter-row">
  <span style="font-size:11px;color:#94a3b8;">Filter:</span>
  <button class="fbtn active" onclick="filter('all',this)">All</button>
  <button class="fbtn" onclick="filter('hl',this)">High load</button>
  <button class="fbtn" onclick="filter('an',this)">Anomaly</button>
  <button class="fbtn" onclick="filter('ok',this)">Healthy</button>
</div>

<div class="section-hdr">Master server overview</div>
<div class="grid" id="grid"></div>

<div class="section-hdr">Top media servers by active jobs</div>
<div class="tbl-wrap">
  <div class="tbl-hdr">Top servers · sorted by active jobs · latest snapshot</div>
  <table>
    <thead><tr>
      <th>Master</th><th>Server</th>
      <th class="r">Active</th><th class="r">Jobs</th>
      <th class="r">Data TB</th><th class="r">Eff TB/hr</th>
      <th class="r">Dup ratio</th><th>Status</th>
    </tr></thead>
    <tbody id="tbl-body"></tbody>
  </table>
</div>

<script>
var CARDS = {cards_json};
var TOP   = {top_json};

var ST_COLOR = {{HIGH_LOAD:"#E24B4A",ANOMALY:"#EF9F27",UNDERUTILIZED:"#639922",BALANCED:"#4A90D9"}};
var ST_BG    = {{HIGH_LOAD:"#FCEBEB",ANOMALY:"#FAEEDA",UNDERUTILIZED:"#EAF3DE",BALANCED:"#E6F1FB"}};
var ST_TC    = {{HIGH_LOAD:"#A32D2D",ANOMALY:"#854F0B",UNDERUTILIZED:"#3B6D11",BALANCED:"#185FA5"}};

function badge(state){{
  var m={{hl:["High load","#FCEBEB","#A32D2D"],an:["Anomaly","#FAEEDA","#854F0B"],
          ok:["Healthy","#EAF3DE","#3B6D11"]}};
  var r=m[state]||m.ok;
  return '<span class="badge" style="background:'+r[1]+';color:'+r[2]+';">'+r[0]+'</span>';
}}

function borderColor(state){{
  return state==="hl"?"#E24B4A":state==="an"?"#EF9F27":"#639922";
}}

function buildCard(c){{
  var bc=borderColor(c.state);
  var heat=c.heat.map(function(h){{
    var col=ST_COLOR[h.st]||"#888";
    return '<span class="htag" style="background:'+col+';">'+h.ms+'</span>';
  }}).join("");
  var pills=[];
  if(c.hl>0) pills.push('<span class="pill pill-hl">'+c.hl+' HIGH_LOAD</span>');
  if(c.an>0) pills.push('<span class="pill pill-an">'+c.an+' ANOMALY</span>');
  if(c.ul>0) pills.push('<span class="pill pill-ul">'+c.ul+' UNDERUTIL</span>');
  if(c.bal>0) pills.push('<span class="pill pill-bl">'+c.bal+' BALANCED</span>');
  if(!pills.length) pills.push('<span class="pill pill-ok">All healthy</span>');
  return '<div class="card" data-state="'+c.state+'">'+
    '<div class="card-head" style="border-left:3px solid '+bc+';">'+
      '<div class="card-name">'+c.short+' '+badge(c.state)+'</div>'+
      '<div class="card-sub">'+c.name+'</div>'+
    '</div>'+
    '<div class="metrics">'+
      '<div class="met"><div class="met-v">'+c.servers+'</div><div class="met-l">Servers</div></div>'+
      '<div class="met"><div class="met-v" style="color:'+(c.active>40?"#A32D2D":"inherit")+';">'+c.active+'</div><div class="met-l">Active</div></div>'+
      '<div class="met"><div class="met-v">'+c.jobs.toLocaleString()+'</div><div class="met-l">Jobs</div></div>'+
      '<div class="met"><div class="met-v">'+(c.eff>0?c.eff.toFixed(4):"—")+'</div><div class="met-l">TB/hr</div></div>'+
    '</div>'+
    '<div class="heat">'+(heat||'<span style="font-size:10px;color:#94a3b8;">No data</span>')+'</div>'+
    '<div class="pills">'+pills.join("")+'</div>'+
  '</div>';
}}

function renderCards(state){{
  var grid=document.getElementById("grid");
  grid.innerHTML=CARDS.filter(function(c){{
    return state==="all"||c.state===state;
  }}).map(buildCard).join("");
}}

function renderTable(){{
  var tbody=document.getElementById("tbl-body");
  tbody.innerHTML=TOP.map(function(r){{
    var sc=ST_COLOR[r.status]||"#888";
    var bg=ST_BG[r.status]||"#f8fafc";
    var tc=ST_TC[r.status]||"#475569";
    var st=r.status.replace("_"," ");
    return "<tr>"+
      "<td class='mono'>"+r.master+"</td>"+
      "<td style='font-weight:500;'>"+r.server+"</td>"+
      "<td class='r' style='color:"+(r.active>40?"#A32D2D":"inherit")+";font-weight:"+(r.active>40?"500":"400")+";'>"+r.active+"</td>"+
      "<td class='r'>"+r.jobs.toLocaleString()+"</td>"+
      "<td class='r'>"+r.tb.toFixed(2)+"</td>"+
      "<td class='r'>"+(r.eff>0?r.eff.toFixed(4):"—")+"</td>"+
      "<td class='r' style='color:"+(r.dr>5?"#A32D2D":"inherit")+"'>"+(r.dr>0?r.dr.toFixed(3):"—")+"</td>"+
      "<td><span style='font-size:10px;font-weight:500;padding:2px 8px;border-radius:20px;background:"+bg+";color:"+tc+";'>"+st+"</span></td>"+
    "</tr>";
  }}).join("");
}}

function filter(state,btn){{
  document.querySelectorAll(".fbtn").forEach(function(b){{b.classList.remove("active");}});
  btn.classList.add("active");
  renderCards(state);
}}

renderCards("all");
renderTable();
</script>
</body></html>"""

    n_cards = len(masters)
    card_rows = (n_cards + 1) // 2
    iframe_h = 340 + 240 + (card_rows * 280) + (min(len(top_servers),30) * 40) + 300
    return html.Div([
        html.Iframe(
            srcDoc=html_src,
            style={"width":"100%","border":"none",
                   "height":f"{iframe_h}px","display":"block"}
        )
    ], style={"padding":"0"})


def ans_media_servers(master_f=None, status_f=None, query=""):
    """Return rich media server table for Vaultix AI."""
    import sqlite3 as _sq, pandas as _pd
    con = _sq.connect(DB_UNIFIED)
    q = """
        SELECT m1.master_name, m1.media_server, m1.ai_status,
               m1.active_jobs, m1.total_jobs,
               ROUND(m1.data_tb,2) AS data_tb,
               ROUND(m1.efficiency,4) AS efficiency,
               ROUND(m1.dup_ratio,4) AS dup_ratio,
               m1.timestamp
        FROM media_metrics_unified m1
        WHERE m1.timestamp=(
            SELECT MAX(m2.timestamp) FROM media_metrics_unified m2
            WHERE m2.media_server=m1.media_server)
    """
    params = []
    if master_f and master_f not in ("all","fleet",""):
        q += " AND m1.master_name=?"; params.append(master_f)
    if status_f and status_f not in ("all",""):
        q += " AND m1.ai_status=?"; params.append(status_f)
    q += " ORDER BY m1.ai_status DESC, m1.active_jobs DESC, m1.total_jobs DESC"
    df = _pd.read_sql_query(q, con, params=params)
    con.close()

    if df.empty:
        return html.Div("No media server data found for this filter.",
                        style={"padding":"12px","color":"#E24B4A","fontSize":"11px"})

    hl  = len(df[df["ai_status"]=="HIGH_LOAD"])
    an  = len(df[df["ai_status"]=="ANOMALY"])
    bal = len(df[df["ai_status"]=="BALANCED"])
    uu  = len(df[df["ai_status"]=="UNDERUTILIZED"])
    label = (master_f or "Fleet").upper()

    SC = {"HIGH_LOAD":"#E24B4A","ANOMALY":"#EF9F27",
          "BALANCED":"#4A90D9","UNDERUTILIZED":"#639922"}
    BG = {"HIGH_LOAD":"#fef2f2","ANOMALY":"#fffbeb",
          "BALANCED":"#eff6ff","UNDERUTILIZED":"#f0fdf4"}

    # Narrative
    if hl > 0:
        narr = (f"⚠️ {label} has {hl} HIGH_LOAD media server(s) — "
                f"immediate action recommended to prevent backup SLA breach. "
                f"{an} showing efficiency anomaly.")
        nb = "#fef2f2"; nc = "#dc2626"; nbl = "#fecaca"
    elif an > 0:
        narr = (f"⚡ {label}: {an} media server(s) show ANOMALY "
                f"(efficiency dropped >40% vs baseline). "
                f"Investigate storage/network issues.")
        nb = "#fffbeb"; nc = "#d97706"; nbl = "#fde68a"
    else:
        narr = (f"✅ {label}: All {len(df)} media server(s) are healthy. "
                f"{bal} BALANCED, {uu} UNDERUTILIZED (spare capacity available).")
        nb = "#f0fdf4"; nc = "#16a34a"; nbl = "#bbf7d0"

    # KPI strip
    kpis = html.Div([
        html.Div([
            html.Div(str(len(df)),
                style={"fontSize":"18px","fontWeight":"800","color":"#2563eb"}),
            html.Div("Total",
                style={"fontSize":"8px","color":"#94a3b8","textTransform":"uppercase"}),
        ], style={"textAlign":"center","flex":"1","padding":"8px",
                  "background":"#eff6ff","borderRadius":"6px"}),
        html.Div([
            html.Div(str(hl),
                style={"fontSize":"18px","fontWeight":"800",
                       "color":"#dc2626" if hl>0 else "#16a34a"}),
            html.Div("High Load",
                style={"fontSize":"8px","color":"#94a3b8","textTransform":"uppercase"}),
        ], style={"textAlign":"center","flex":"1","padding":"8px",
                  "background":"#fef2f2" if hl>0 else "#f0fdf4","borderRadius":"6px"}),
        html.Div([
            html.Div(str(an),
                style={"fontSize":"18px","fontWeight":"800",
                       "color":"#d97706" if an>0 else "#16a34a"}),
            html.Div("Anomaly",
                style={"fontSize":"8px","color":"#94a3b8","textTransform":"uppercase"}),
        ], style={"textAlign":"center","flex":"1","padding":"8px",
                  "background":"#fffbeb" if an>0 else "#f0fdf4","borderRadius":"6px"}),
        html.Div([
            html.Div(str(bal),
                style={"fontSize":"18px","fontWeight":"800","color":"#2563eb"}),
            html.Div("Balanced",
                style={"fontSize":"8px","color":"#94a3b8","textTransform":"uppercase"}),
        ], style={"textAlign":"center","flex":"1","padding":"8px",
                  "background":"#eff6ff","borderRadius":"6px"}),
    ], style={"display":"flex","gap":"6px","marginBottom":"10px"})

    # Table rows
    t_rows = []
    for _, r in df.iterrows():
        st   = str(r.get("ai_status",""))
        sc   = SC.get(st,"#94a3b8")
        sbg  = BG.get(st,"#f8fafc")
        short = r["media_server"].split(".")[0]
        eff   = float(r.get("efficiency") or 0)
        dup   = float(r.get("dup_ratio") or 0)
        t_rows.append(html.Tr([
            html.Td(short,
                style={"padding":"5px 8px","fontSize":"10px","fontWeight":"600",
                       "color":"#1e3a5f","fontFamily":"monospace"}),
            html.Td(r["master_name"],
                style={"padding":"5px 8px","fontSize":"9px","color":"#64748b"}),
            html.Td(html.Span(st,
                style={"background":sbg,"color":sc,"borderRadius":"6px",
                       "padding":"1px 7px","fontSize":"8px","fontWeight":"700",
                       "border":f"1px solid {sc}33"}),
                style={"padding":"5px 8px"}),
            html.Td(str(int(r.get("active_jobs") or 0)),
                style={"padding":"5px 8px","fontSize":"10px","textAlign":"right",
                       "color":"#dc2626" if int(r.get("active_jobs") or 0)>40 else "#334155",
                       "fontWeight":"700" if int(r.get("active_jobs") or 0)>40 else "400"}),
            html.Td(f"{int(r.get('total_jobs') or 0):,}",
                style={"padding":"5px 8px","fontSize":"10px",
                       "textAlign":"right","color":"#334155"}),
            html.Td(f"{float(r.get('data_tb') or 0):.2f} TB",
                style={"padding":"5px 8px","fontSize":"10px",
                       "textAlign":"right","color":"#334155"}),
            html.Td(f"{eff:.4f}" if eff > 0 else "—",
                style={"padding":"5px 8px","fontSize":"10px",
                       "textAlign":"right","color":"#334155"}),
            html.Td(f"{dup:.3f}" if dup > 0 else "—",
                style={"padding":"5px 8px","fontSize":"10px",
                       "textAlign":"right",
                       "color":"#dc2626" if dup>0.45 else "#334155"}),
        ], style={"borderBottom":"1px solid #f1f5f9",
                  "background":sbg if st in ("HIGH_LOAD","ANOMALY") else "#fff"}))

    table = html.Div([
        html.Div([
            html.Span(f"🖥️ Media Servers — {label}",
                style={"fontSize":"11px","fontWeight":"600","color":"#1e3a5f"}),
            html.Span(f"{len(df)} servers",
                style={"fontSize":"9px","color":"#94a3b8","marginLeft":"8px"}),
        ], style={"background":"#1e3a5f","padding":"8px 12px",
                  "borderRadius":"6px 6px 0 0"}),
        html.Table([
            html.Thead(html.Tr([
                html.Th(h, style={"padding":"6px 8px","background":"#f0f4fa",
                    "fontSize":"9px","color":"#1e3a5f","fontWeight":"600",
                    "textTransform":"uppercase","letterSpacing":"0.5px",
                    "textAlign":"right" if i>2 else "left"})
                for i, h in enumerate(["Server","Master","Status",
                                        "Active","Jobs","Data TB",
                                        "Eff TB/hr","Dup Ratio"])
            ])),
            html.Tbody(t_rows),
        ], style={"width":"100%","borderCollapse":"collapse","background":"#fff"}),
    ], style={"border":"1px solid #e2e8f0","borderRadius":"0 0 6px 6px",
              "overflow":"hidden"})

    return html.Div([
        html.Div(narr, style={"background":nb,"border":f"1px solid {nbl}",
                               "borderLeft":f"4px solid {nc}",
                               "borderRadius":"6px","padding":"10px 14px",
                               "fontSize":"11px","color":nc,"marginBottom":"10px",
                               "lineHeight":"1.6"}),
        kpis,
        table,
    ])




def tab_backup_jobs():
    """📊 Backup Jobs — Option 2 Architect Intelligence View."""
    import sqlite3 as _sq, pandas as _pd, json as _json

    try:
        con = _sq.connect(DB_UNIFIED)

        # Summary per schedule
        fleet_df = _pd.read_sql_query("""
            SELECT schedule, backup_type,
                   COUNT(DISTINCT server_name) AS servers,
                   SUM(total_jobs) AS total_jobs,
                   SUM(success_jobs) AS success_jobs,
                   SUM(failed_jobs) AS failed_jobs,
                   ROUND(AVG(success_rate),1) AS avg_rate,
                   ROUND(SUM(total_volume_tb),2) AS total_tb,
                   SUM(unique_clients) AS total_clients,
                   ROUND(AVG(avg_throughput_mbps),1) AS avg_tp,
                   ROUND(AVG(backup_window_hours),1) AS avg_win,
                   MAX(report_date) AS latest
            FROM backup_jobs_summary
            GROUP BY schedule ORDER BY schedule
        """, con)

        # Per server detail (latest date per schedule)
        srv_df = _pd.read_sql_query("""
            SELECT * FROM backup_jobs_summary
            WHERE report_date=(SELECT MAX(report_date) FROM backup_jobs_summary)
            ORDER BY success_rate ASC
        """, con)

        # Error codes fleet-wide
        err_df = _pd.read_sql_query("""
            SELECT error_code, SUM(count) AS total
            FROM backup_error_codes
            WHERE report_date=(SELECT MAX(report_date) FROM backup_error_codes)
            GROUP BY error_code ORDER BY total DESC LIMIT 6
        """, con)

        # Failing clients
        fail_df = _pd.read_sql_query("""
            SELECT client_name, server_name, schedule,
                   success_rate, total_jobs, failed_jobs
            FROM backup_failing_clients
            WHERE report_date=(SELECT MAX(report_date) FROM backup_failing_clients)
            ORDER BY success_rate ASC LIMIT 10
        """, con)

        # 7-day heatmap data
        hm_df = _pd.read_sql_query("""
            SELECT server_name, report_date, schedule, success_rate
            FROM backup_jobs_summary
            ORDER BY report_date DESC LIMIT 200
        """, con)

        con.close()
    except Exception as e:
        return html.Div(f"Backup Jobs data unavailable: {e}",
                       style={"padding":"24px","color":"#E24B4A"})

    if srv_df.empty:
        return html.Div("No backup job data yet. Run sync_backup_jobs.py",
                       style={"padding":"24px","color":"#888"})

    W = "#fff"; BG = "#f0f2f7"; BORDER = "#e2e8f0"; MUT = "#94a3b8"
    SCHED_COLORS = {
        "DAILY":  ("#2563eb","#eff6ff","#bfdbfe"),
        "WEEKLY": ("#c2410c","#fff7ed","#fed7aa"),
        "MONTHLY":("#7e22ce","#faf5ff","#e9d5ff"),
        "YEARLY": ("#be185d","#fdf2f8","#fbcfe8"),
    }

    # ── Schedule selector store ───────────────────────────────────────────────
    sched_btns = html.Div([
        html.Button(
            [html.Span("●", style={"marginRight":"4px",
                "color":SCHED_COLORS.get(s,("#888","#fff","#888"))[0]}),
             s],
            id={"type":"bj_sched_btn","index":s},
            n_clicks=0,
            style={"background": SCHED_COLORS.get(s,("#888","#f8fafc","#e2e8f0"))[1],
                   "border":f"1px solid {SCHED_COLORS.get(s,('#888','#fff','#e2e8f0'))[2]}",
                   "color": SCHED_COLORS.get(s,("#888","#fff","#888"))[0],
                   "borderRadius":"16px","padding":"4px 14px",
                   "fontSize":"10px","fontWeight":"700","cursor":"pointer",
                   "marginRight":"6px","letterSpacing":"0.3px"})
        for s in (fleet_df["schedule"].tolist() if not fleet_df.empty
                  else ["DAILY","WEEKLY","MONTHLY"])
    ], style={"display":"flex","alignItems":"center"})

    # ── Fleet score ribbon ────────────────────────────────────────────────────
    if not fleet_df.empty:
        fd = fleet_df.iloc[0]  # Default to first schedule (DAILY)
        fleet_rate   = float(fd["avg_rate"] or 0)
        fleet_jobs   = int(fd["total_jobs"] or 0)
        fleet_fail   = int(fd["failed_jobs"] or 0)
        fleet_tb     = float(fd["total_tb"] or 0)
        fleet_cli    = int(fd["total_clients"] or 0)
        fleet_tp     = float(fd["avg_tp"] or 0)
        fleet_win    = float(fd["avg_win"] or 0)
        fleet_srvs   = int(fd["servers"] or 0)
    else:
        fleet_rate=fleet_jobs=fleet_fail=fleet_tb=fleet_cli=fleet_tp=fleet_win=fleet_srvs=0

    rate_color = ("#16a34a" if fleet_rate>=95
                  else "#d97706" if fleet_rate>=85
                  else "#dc2626")

    def rb_kpi(label, val, color, sub=""):
        return html.Div([
            html.Div(style={"position":"absolute","top":"0","left":"0",
                           "right":"0","height":"2px","background":color,
                           "borderRadius":"8px 8px 0 0"}),
            html.Div(label, style={"fontSize":"8px","color":MUT,
                "textTransform":"uppercase","letterSpacing":"0.6px",
                "marginBottom":"4px","marginTop":"2px"}),
            html.Div(str(val), style={"fontSize":"17px","fontWeight":"800",
                "color":color,"lineHeight":"1","marginBottom":"1px"}),
            html.Div(sub, style={"fontSize":"8px","color":MUT}),
        ], style={"background":W,"border":f"1px solid {BORDER}",
                  "borderRadius":"8px","padding":"8px 10px 10px",
                  "position":"relative","overflow":"hidden","flex":"1"})

    ribbon = html.Div([
        rb_kpi("Fleet Success", f"{fleet_rate}%", rate_color,
               f"{fleet_srvs} masters reporting"),
        rb_kpi("Total Jobs", f"{fleet_jobs:,}", "#2563eb",
               "across all servers"),
        rb_kpi("Failed Jobs", f"{fleet_fail:,}",
               "#dc2626" if fleet_fail>0 else "#16a34a",
               f"{round(fleet_fail/max(fleet_jobs,1)*100,1)}% failure rate"),
        rb_kpi("Data Protected", f"{fleet_tb} TB", "#7c3aed",
               "total volume processed"),
        rb_kpi("Unique Clients", f"{fleet_cli:,}", "#0f766e",
               "protected assets"),
        rb_kpi("Avg Throughput", f"{fleet_tp} MB/s", "#0284c7",
               "network transfer rate"),
        rb_kpi("Avg Window", f"{fleet_win}h", "#f59e0b",
               "backup window duration"),
    ], style={"display":"flex","gap":"7px","marginBottom":"10px"})

    # ── Heatmap ───────────────────────────────────────────────────────────────
    hm_colors = {"crit":"#ef4444","warn":"#f59e0b",
                 "ok":"#22c55e","good":"#dcfce7"}

    def hm_color(rate):
        r = float(rate or 0)
        if r < 80:   return "#ef4444"
        if r < 90:   return "#f59e0b"
        if r < 95:   return "#22c55e"
        return "#dcfce7"

    MASTERS_14 = ["cpcinp1cbkms","cpcinp2cbkms","cpcind1cbkms","cpcind2cbkms",
                  "cazinp1cbkms","cocinp1cbkms","cazusp1cbkms","cgcukp1cbkms",
                  "cpceup1cbkms","cpcfrp1cbkms","cpcgep1cbkms","cpcphp1cbkms",
                  "cpcchp1cbkms","cpcusp1cbkms"]

    # Get dates
    if not hm_df.empty:
        dates = sorted(hm_df["report_date"].unique())[-7:]
    else:
        from datetime import date, timedelta
        dates = [(date.today()-timedelta(days=i)).strftime("%Y-%m-%d")
                 for i in range(6,-1,-1)]

    hm_rows = []
    # Date header
    hm_rows.append(html.Div([
        html.Div(style={"width":"100px"}),
        html.Div([
            html.Div(d[-5:], style={"flex":"1","fontSize":"8px",
                "color":MUT,"textAlign":"center"})
            for d in dates
        ], style={"display":"flex","flex":"1","gap":"2px"}),
        html.Div(style={"width":"40px"}),
    ], style={"display":"flex","marginBottom":"3px"}))

    for master in MASTERS_14:
        cells = []
        for d in dates:
            row = hm_df[(hm_df["server_name"]==master) &
                        (hm_df["report_date"]==d)]
            if not row.empty:
                rate = float(row.iloc[0]["success_rate"])
                bc   = hm_color(rate)
                tip  = f"{master} {d}: {rate:.1f}%"
            else:
                bc  = "#f1f5f9"
                tip = f"{master} {d}: no data"
                rate = None
            cells.append(html.Div(
                title=tip,
                style={"flex":"1","height":"14px","background":bc,
                       "borderRadius":"2px","cursor":"default"}))

        # Latest rate for this master
        latest = hm_df[hm_df["server_name"]==master]
        latest_rate = float(latest.iloc[0]["success_rate"]) if not latest.empty else 0
        rc = ("#dc2626" if latest_rate<85 else "#d97706" if latest_rate<95
              else "#16a34a")

        hm_rows.append(html.Div([
            html.Div(master, style={"width":"100px","fontSize":"8px",
                "color":"#334155","overflow":"hidden",
                "textOverflow":"ellipsis","whiteSpace":"nowrap",
                "fontFamily":"monospace"}),
            html.Div(cells, style={"display":"flex","flex":"1","gap":"2px"}),
            html.Div(f"{latest_rate:.1f}%" if latest_rate else "—",
                style={"width":"40px","textAlign":"right","fontSize":"8px",
                       "fontWeight":"700","color":rc}),
        ], style={"display":"flex","alignItems":"center","gap":"4px",
                  "marginBottom":"2px"}))

    _hm_legend_items = [
        html.Span("7-Day Success Rate Heatmap",
            style={"fontSize":"11px","fontWeight":"600","color":"#334155"}),
    ] + [
        html.Div([
            html.Span(style={"width":"9px","height":"9px",
                "background":c,"borderRadius":"2px",
                "display":"inline-block","marginRight":"3px"}),
            html.Span(l, style={"fontSize":"9px","color":MUT}),
        ], style={"display":"flex","alignItems":"center","marginRight":"10px"})
        for c,l in [("#dcfce7","≥95%"),("#22c55e","90-95%"),
                    ("#f59e0b","80-90%"),("#ef4444","<80%")]
    ]
    heatmap_panel = html.Div([
        html.Div(_hm_legend_items,
            style={"padding":"8px 12px","borderBottom":f"1px solid {BORDER}",
                   "display":"flex","alignItems":"center","gap":"8px",
                   "background":"#fafbfd","flexWrap":"wrap"}),
        html.Div(hm_rows, style={"padding":"8px 12px 10px"}),
    ], style={"background":W,"border":f"1px solid {BORDER}",
              "borderRadius":"10px","overflow":"hidden"})

    # ── Backup window timeline ────────────────────────────────────────────────
    # 12h axis: 20:00 → 08:00
    def tl_bar(start_t, win_h, color):
        try:
            h, m = map(int, str(start_t or "22:30").split(":")[:2])
            # Normalise to 0-12h axis (20:00=0, 08:00=12)
            start_norm = ((h - 20) % 24)
            pct_left  = start_norm / 12 * 100
            pct_width = min(win_h / 12 * 100, 100 - pct_left)
            return pct_left, pct_width
        except Exception:
            return 20, 40

    tl_rows = []
    srv_sample = srv_df[srv_df["schedule"]=="DAILY"] if not srv_df.empty else srv_df
    for _, r in srv_sample.iterrows():
        rate = float(r.get("success_rate") or 0)
        win  = float(r.get("backup_window_hours") or 5)
        fs   = str(r.get("first_start","22:30") or "22:30")
        le   = str(r.get("last_end","04:00") or "04:00")
        lc   = ("#ef4444" if rate<85 else "#f59e0b" if rate<95 else "#3b82f6")
        pl, pw = tl_bar(fs, win, lc)
        srv_short = r["server_name"][:14]
        tl_rows.append(html.Div([
            html.Div(srv_short, style={"width":"100px","fontSize":"8px",
                "color":"#334155","fontFamily":"monospace",
                "overflow":"hidden","textOverflow":"ellipsis",
                "whiteSpace":"nowrap"}),
            html.Div([
                html.Div(style={"position":"absolute","top":"0","left":"0",
                    "width":"100%","height":"100%","background":"#f1f5f9",
                    "borderRadius":"5px"}),
                html.Div(style={"position":"absolute","top":"0",
                    "left":f"{pl}%","width":f"{pw}%","height":"100%",
                    "background":lc,"borderRadius":"5px","opacity":"0.8"}),
            ], style={"flex":"1","height":"10px","position":"relative",
                      "borderRadius":"5px"}),
            html.Div(f"{win:.1f}h",
                style={"width":"32px","textAlign":"right","fontSize":"8px",
                       "fontWeight":"700","color":lc}),
        ], style={"display":"flex","alignItems":"center","gap":"6px",
                  "marginBottom":"3px"}))
        if len(tl_rows) >= 14: break

    timeline_panel = html.Div([
        html.Div([
            html.Span("Backup Window Timeline",
                style={"fontSize":"11px","fontWeight":"600","color":"#334155"}),
            html.Span("20:00 → 08:00",
                style={"fontSize":"9px","color":MUT,"marginLeft":"8px"}),
        ], style={"padding":"8px 12px","borderBottom":f"1px solid {BORDER}",
                  "background":"#fafbfd"}),
        html.Div([
            html.Div([
                html.Div(style={"width":"100px"}),
                html.Div([
                    html.Div(t, style={"flex":"1","fontSize":"8px",
                        "color":MUT,"textAlign":"center"})
                    for t in ["20:00","22:00","00:00","02:00","04:00","06:00","08:00"]
                ], style={"display":"flex","flex":"1"}),
                html.Div(style={"width":"32px"}),
            ], style={"display":"flex","marginBottom":"4px"}),
        ] + tl_rows + [
            html.Div("⚠️ Bars extending past 06:00 risk overlapping business hours",
                style={"fontSize":"9px","color":MUT,
                       "marginTop":"5px","borderTop":f"1px solid {BORDER}",
                       "paddingTop":"5px"}),
        ], style={"padding":"8px 12px 10px"}),
    ], style={"background":W,"border":f"1px solid {BORDER}",
              "borderRadius":"10px","overflow":"hidden"})

    # ── Error codes ───────────────────────────────────────────────────────────
    err_rows = []
    if not err_df.empty:
        max_err = int(err_df.iloc[0]["total"]) if len(err_df)>0 else 1
        ERR_LABELS = {96:"Client backup failed",24:"Socket read failed",
                      41:"Network error",6:"Backup aborted",
                      71:"None required",58:"Can't connect",
                      2:"None required",1:"Partially success"}
        for _, er in err_df.iterrows():
            code = int(er["error_code"])
            cnt  = int(er["total"])
            pct  = int(cnt/max_err*100)
            lbl  = ERR_LABELS.get(code, f"NBU error {code}")
            bar_c = ("#ef4444" if pct>60 else "#f59e0b" if pct>30 else "#fbbf24")
            err_rows.append(html.Tr([
                html.Td(str(code),
                    style={"padding":"5px 8px","fontFamily":"monospace",
                           "fontSize":"10px","fontWeight":"700","color":"#dc2626"}),
                html.Td(lbl,
                    style={"padding":"5px 8px","fontSize":"9px","color":"#475569"}),
                html.Td([
                    html.Div([
                        html.Div(style={"position":"absolute","top":"0","left":"0",
                            "width":f"{pct}%","height":"100%",
                            "background":bar_c,"borderRadius":"2px"}),
                    ], style={"width":"80px","height":"5px","background":"#f1f5f9",
                              "borderRadius":"2px","position":"relative"}),
                ], style={"padding":"5px 8px"}),
                html.Td(f"{cnt:,}",
                    style={"padding":"5px 8px","fontSize":"9px",
                           "fontWeight":"700","color":"#334155",
                           "textAlign":"right"}),
            ], style={"borderBottom":f"1px solid #f8fafc"}))

    error_panel = html.Div([
        html.Div([
            html.Span("Error Code Distribution",
                style={"fontSize":"11px","fontWeight":"600","color":"#334155"}),
            html.Span("Fleet-wide today",
                style={"fontSize":"9px","color":MUT,"marginLeft":"8px"}),
        ], style={"padding":"8px 12px","borderBottom":f"1px solid {BORDER}",
                  "background":"#fafbfd"}),
        html.Table([
            html.Thead(html.Tr([
                html.Th(h, style={"padding":"5px 8px","background":"#f0f4fa",
                    "fontSize":"8px","color":"#1e3a5f","fontWeight":"600",
                    "textTransform":"uppercase","letterSpacing":"0.4px",
                    "textAlign":"left"})
                for h in ["Code","Description","Frequency","Count"]
            ])),
            html.Tbody(err_rows),
        ], style={"width":"100%","borderCollapse":"collapse","background":W}),
        html.Div(
            f"Error 96 = {round(int(err_df.iloc[0]['total'])/max(int(err_df['total'].sum()),1)*100)}% of all failures — primary focus area" if not err_df.empty else "",
            style={"fontSize":"9px","color":MUT,"padding":"5px 12px",
                   "borderTop":f"1px solid {BORDER}"}),
    ], style={"background":W,"border":f"1px solid {BORDER}",
              "borderRadius":"10px","overflow":"hidden"})

    # ── Client risk register ──────────────────────────────────────────────────
    cli_rows = []
    if not fail_df.empty:
        for _, cr in fail_df.iterrows():
            rate = float(cr.get("success_rate") or 0)
            srv  = str(cr.get("server_name","")).replace("cbkms","")
            if rate == 0:
                risk_style = {"background":"#fef2f2","color":"#dc2626",
                              "borderRadius":"4px","padding":"1px 5px",
                              "fontSize":"8px","fontWeight":"700"}
                risk_lbl = "CRITICAL"
                row_bg = "#fef2f2"
            elif rate < 60:
                risk_style = {"background":"#fffbeb","color":"#d97706",
                              "borderRadius":"4px","padding":"1px 5px",
                              "fontSize":"8px","fontWeight":"700"}
                risk_lbl = "HIGH"
                row_bg = "#fffbeb"
            else:
                risk_style = {"background":"#fff7ed","color":"#c2410c",
                              "borderRadius":"4px","padding":"1px 5px",
                              "fontSize":"8px","fontWeight":"700"}
                risk_lbl = "MEDIUM"
                row_bg = "#fff"

            cli_rows.append(html.Tr([
                html.Td(str(cr.get("client_name",""))[:24],
                    style={"padding":"5px 8px","fontFamily":"monospace",
                           "fontSize":"9px","color":"#1e3a5f"}),
                html.Td(srv,
                    style={"padding":"5px 8px","fontSize":"9px","color":MUT}),
                html.Td(str(cr.get("schedule","")),
                    style={"padding":"5px 8px","fontSize":"9px","color":MUT}),
                html.Td(f"{rate:.0f}%",
                    style={"padding":"5px 8px","fontSize":"9px",
                           "fontWeight":"700","color":
                           "#dc2626" if rate<30 else "#d97706" if rate<70
                           else "#16a34a"}),
                html.Td(html.Span(risk_lbl, style=risk_style),
                    style={"padding":"5px 8px"}),
            ], style={"borderBottom":f"1px solid #f8fafc","background":row_bg}))

    client_panel = html.Div([
        html.Div([
            html.Span("Client Risk Register",
                style={"fontSize":"11px","fontWeight":"600","color":"#334155"}),
            html.Span(f"{len(fail_df)} clients at risk",
                style={"fontSize":"9px","color":"#dc2626","marginLeft":"8px",
                       "fontWeight":"600"}),
        ], style={"padding":"8px 12px","borderBottom":f"1px solid {BORDER}",
                  "background":"#fafbfd"}),
        html.Table([
            html.Thead(html.Tr([
                html.Th(h, style={"padding":"5px 8px","background":"#f0f4fa",
                    "fontSize":"8px","color":"#1e3a5f","fontWeight":"600",
                    "textTransform":"uppercase","letterSpacing":"0.4px"})
                for h in ["Client","Server","Schedule","Success","Risk"]
            ])),
            html.Tbody(cli_rows),
        ], style={"width":"100%","borderCollapse":"collapse","background":W}),
    ], style={"background":W,"border":f"1px solid {BORDER}",
              "borderRadius":"10px","overflow":"hidden"})

    # ── Throughput panel ──────────────────────────────────────────────────────
    tp_rows = []
    srv_tp = srv_df[srv_df["schedule"]=="DAILY"].sort_values(
        "avg_throughput_mbps", ascending=False) if not srv_df.empty else srv_df
    max_tp = float(srv_tp["avg_throughput_mbps"].max()) if not srv_tp.empty else 1
    for _, r in srv_tp.iterrows():
        tp = float(r.get("avg_throughput_mbps") or 0)
        pct = int(tp/max_tp*100) if max_tp>0 else 0
        tp_rows.append(html.Div([
            html.Div(r["server_name"][:14],
                style={"width":"100px","fontSize":"9px","color":"#334155",
                       "fontFamily":"monospace","overflow":"hidden",
                       "textOverflow":"ellipsis","whiteSpace":"nowrap"}),
            html.Div([
                html.Div(style={"position":"absolute","top":"0","left":"0",
                    "width":f"{pct}%","height":"100%",
                    "background":"linear-gradient(90deg,#3b82f6,#0f766e)",
                    "borderRadius":"4px"}),
            ], style={"flex":"1","height":"8px","background":"#f1f5f9",
                      "borderRadius":"4px","position":"relative"}),
            html.Div(f"{tp:.0f} MB/s",
                style={"width":"55px","textAlign":"right","fontSize":"9px",
                       "fontWeight":"600","color":"#334155"}),
        ], style={"display":"flex","alignItems":"center","gap":"6px",
                  "padding":"4px 12px","borderBottom":f"1px solid #f8fafc"}))
        if len(tp_rows)>=8: break

    tp_panel = html.Div([
        html.Div("Throughput per Server",
            style={"padding":"8px 12px","borderBottom":f"1px solid {BORDER}",
                   "fontSize":"11px","fontWeight":"600","color":"#334155",
                   "background":"#fafbfd"}),
        html.Div(tp_rows),
    ], style={"background":W,"border":f"1px solid {BORDER}",
              "borderRadius":"10px","overflow":"hidden"})

    # ── AI recommendations ────────────────────────────────────────────────────
    ai_items = []
    # Generate live recommendations from data
    if not srv_df.empty:
        critical = srv_df[srv_df["success_rate"]<85]
        for _, r in critical.head(2).iterrows():
            rate = float(r["success_rate"])
            fail = int(r["failed_jobs"])
            errc = {}
            try:
                errc = _json.loads(str(r.get("top_error_codes","{}") or "{}"))
            except Exception:
                pass
            top_err = max(errc, key=lambda k: errc[k]) if errc else "96"
            ai_items.append(("P1","#fef2f2","#dc2626",
                f"{r['server_name'].upper()} — {rate:.1f}% success rate is below 85% SLA. "
                f"{fail:,} failed jobs. Error {top_err} is dominant. "
                f"Action: Check bpbrm logs, restart NBU client service on affected hosts."))

        warning = srv_df[(srv_df["success_rate"]>=85) & (srv_df["success_rate"]<95)]
        for _, r in warning.head(2).iterrows():
            ai_items.append(("P2","#fffbeb","#d97706",
                f"{r['server_name'].upper()} — {float(r['success_rate']):.1f}% "
                f"approaching SLA threshold (95%). Monitor closely. "
                f"Review failing client list and agent connectivity."))

    # Capacity forecast
    daily_tb = float(srv_df[srv_df["schedule"]=="DAILY"]["total_volume_tb"].sum()
                     if not srv_df.empty else 0)
    ai_items.append(("P3","#eff6ff","#2563eb",
        f"Capacity forecast: {daily_tb:.1f} TB daily × 30 = "
        f"{daily_tb*30:.0f} TB/month incremental. "
        f"Full backup baseline estimated at {daily_tb*20:.0f} TB. "
        f"Plan {daily_tb*45:.0f} TB storage with 1.5× retention buffer."))

    ai_panel = html.Div([
        html.Div([
            html.Span("AI Recommendations — Architect View",
                style={"fontSize":"11px","fontWeight":"600","color":"#334155"}),
            html.Span("P1: Immediate",
                style={"fontSize":"9px","padding":"2px 7px","borderRadius":"8px",
                       "background":"#fef2f2","color":"#dc2626",
                       "border":"1px solid #fecaca","fontWeight":"700"}),
        ], style={"padding":"8px 12px","borderBottom":f"1px solid {BORDER}",
                  "display":"flex","alignItems":"center",
                  "justifyContent":"space-between","background":"#fafbfd"}),
        html.Div([
            html.Div([
                html.Span(pri, style={"fontSize":"8px","fontWeight":"700",
                    "padding":"1px 5px","borderRadius":"4px",
                    "background":bg,"color":col,"marginRight":"8px",
                    "flexShrink":"0","display":"inline-block",
                    "marginTop":"1px"}),
                html.Span(msg, style={"fontSize":"9px","color":"#475569",
                                      "lineHeight":"1.5"}),
            ], style={"padding":"7px 12px","borderBottom":f"1px solid #f8fafc",
                      "display":"flex","alignItems":"flex-start"})
            for pri, bg, col, msg in ai_items
        ]),
    ], style={"background":W,"border":f"1px solid {BORDER}",
              "borderRadius":"10px","overflow":"hidden"})

    # ── Capacity grid ─────────────────────────────────────────────────────────
    monthly_proj = daily_tb * 30
    weekly_full  = daily_tb * 7 * 3
    recommended  = daily_tb * 45

    cap_panel = html.Div([
        html.Div("Capacity & Infrastructure Planning",
            style={"padding":"8px 12px","borderBottom":f"1px solid {BORDER}",
                   "fontSize":"11px","fontWeight":"600","color":"#334155",
                   "background":"#fafbfd"}),
        html.Div([
            html.Div([
                html.Div(f"{daily_tb:.1f} TB",
                    style={"fontSize":"16px","fontWeight":"800","color":"#2563eb"}),
                html.Div("Daily Change Rate",
                    style={"fontSize":"8px","color":MUT,"textTransform":"uppercase",
                           "letterSpacing":"0.5px","marginTop":"2px"}),
            ], style={"padding":"10px 14px","borderRight":f"1px solid {BORDER}",
                      "borderBottom":f"1px solid {BORDER}","flex":"1"}),
            html.Div([
                html.Div(f"~{monthly_proj:.0f} TB",
                    style={"fontSize":"16px","fontWeight":"800","color":"#7c3aed"}),
                html.Div("Monthly Projection",
                    style={"fontSize":"8px","color":MUT,"textTransform":"uppercase",
                           "letterSpacing":"0.5px","marginTop":"2px"}),
            ], style={"padding":"10px 14px","borderBottom":f"1px solid {BORDER}",
                      "flex":"1"}),
            html.Div([
                html.Div(f"~{weekly_full:.0f} TB",
                    style={"fontSize":"16px","fontWeight":"800","color":"#c2410c"}),
                html.Div("Weekly Full Est.",
                    style={"fontSize":"8px","color":MUT,"textTransform":"uppercase",
                           "letterSpacing":"0.5px","marginTop":"2px"}),
            ], style={"padding":"10px 14px","borderRight":f"1px solid {BORDER}",
                      "flex":"1"}),
            html.Div([
                html.Div(f"~{recommended:.0f} TB",
                    style={"fontSize":"16px","fontWeight":"800","color":"#0f766e"}),
                html.Div("Recommended Buffer",
                    style={"fontSize":"8px","color":MUT,"textTransform":"uppercase",
                           "letterSpacing":"0.5px","marginTop":"2px"}),
            ], style={"padding":"10px 14px","flex":"1"}),
        ], style={"display":"flex"}),
    ], style={"background":W,"border":f"1px solid {BORDER}",
              "borderRadius":"10px","overflow":"hidden"})

    # ── Export bar ────────────────────────────────────────────────────────────
    bj_export = html.Div([
        html.Div([
            html.Span("Schedule:",
                style={"fontSize":"10px","color":"#64748b","marginRight":"6px",
                       "fontWeight":"500"}),
            dcc.Dropdown(
                id="bj_schedule_filter",
                options=[{"label":s,"value":s}
                         for s in ["DAILY","WEEKLY","MONTHLY","YEARLY"]],
                value="DAILY", clearable=False,
                style={"width":"130px","fontSize":"10px","minHeight":"28px"}),
        ], style={"display":"flex","alignItems":"center","gap":"4px"}),
        html.Div([
            html.Span("Export:", style={"fontSize":"10px","color":"#64748b",
                "marginRight":"6px","fontWeight":"500"}),
            html.Button("⬇ CSV", id="bj_export_csv", n_clicks=0,
                style={"background":"#1e3a5f","color":"#fff","border":"none",
                       "borderRadius":"6px","padding":"4px 12px","fontSize":"10px",
                       "cursor":"pointer","fontWeight":"500","marginRight":"4px"}),
            html.Button("📧 Email Report", id="bj_export_email", n_clicks=0,
                style={"background":"#0f766e","color":"#fff","border":"none",
                       "borderRadius":"6px","padding":"4px 12px","fontSize":"10px",
                       "cursor":"pointer","fontWeight":"500"}),
        ], style={"display":"flex","alignItems":"center"}),
    ], style={"display":"flex","alignItems":"center","justifyContent":"space-between",
              "padding":"8px 14px","background":"#f8fafc",
              "border":"1px solid #e2e8f0","borderRadius":"8px",
              "marginBottom":"10px"})

    # ── Fleet overview summary (for Fleet Overview tab) ───────────────────────
    return html.Div([
        sched_btns,
        html.Div(style={"height":"8px"}),
        ribbon,
        # Row 1: Heatmap + Timeline
        html.Div([
            html.Div(heatmap_panel, style={"flex":"1","minWidth":"0"}),
            html.Div(timeline_panel, style={"flex":"1","minWidth":"0"}),
        ], style={"display":"flex","gap":"10px","marginBottom":"10px"}),
        # Row 2: Errors + Clients + Throughput
        html.Div([
            html.Div(error_panel, style={"flex":"1","minWidth":"0"}),
            html.Div(client_panel, style={"flex":"1","minWidth":"0"}),
            html.Div(tp_panel, style={"flex":"1","minWidth":"0"}),
        ], style={"display":"flex","gap":"10px","marginBottom":"10px"}),
        # Row 3: AI + Capacity
        html.Div([
            html.Div(ai_panel, style={"flex":"2","minWidth":"0"}),
            html.Div(cap_panel, style={"flex":"1","minWidth":"0"}),
        ], style={"display":"flex","gap":"10px"}),
    ], style={"padding":"14px","background":"#f0f2f7","minHeight":"100vh"})


def slm_answer_full(query, history=None):
    # ── Resolve last referenced server from history (pronoun resolution) ──
    if history and any(w in query.lower() for w in
                       ["that server","same server","it","same","this one","that one"]):
        for h in reversed(history[-5:]):
            for s in known_servers():
                if s in h.get("q","").lower():
                    query = query + " " + s
                    break
    q=query.lower()
    isbj = any(k in q for k in [
        "backup job","backup jobs","backup success","backup failure",
        "backup rate","backup window","backup volume","failed backup",
        "schedule backup","daily backup","weekly backup","monthly backup",
        "backup client","client failure","error code","nbu error",
        "backup throughput","backup capacity","change rate","bpbrm",
        "backup status","how many jobs","jobs failed","jobs ran",
    ])
    isms = any(k in q for k in [
        "media server","media servers","media svr","mediaserver",
        "high load media","overloaded media","media load",
        "media efficiency","media jobs","media status",
        "media anomaly","media high","which media","show media",
        "media server status","media server report",
        "how high load","show high load","high load server",
        "overload server","media utilization","backup media",
    ]) or ("high load" in q and any(s in q for s in [
        "cpcinp1","cpcinp2","cpcind1","cpcind2","cazinp1","cocinp1",
        "cazusp1","cgcukp1","cpceup1","cpcfrp1","cpcgep1","cpcphp1",
        "cpcchp1","cpcusp1","india","europe","us server","apac",
    ]))
    is3 =any(k in q for k in [
        "3rd","third","3rdsite","worm","dedup","dedupe","throughput","gbps",
        "total_data_tb","transfer","external airgap","external vault","off-site",
        "off site","wan vault","remote vault","offsite","msdp vault","vault dedup",
        "immutable retention","dedup vault","off-prem vault","external airgap vault",
        "3rd site","thirdsite","3rdsite","ext vault","ext airgap",
        "external airgap vault","external vault history",
    ])
    is_compare = any(k in q for k in [
        "compare","comparison","vs","versus","side by side","rank",
        "which is worst","which is best","highest","lowest","top servers",
    ])
    isl =any(k in q for k in [
        "lag","duplication lag","backlog","sla","above sla","not_started_remote",
        "in_process_remote","pending images","duplication queue","queue depth",
        "queue breach","dup queue","stuck jobs","delayed images","dup backlog",
        "replication queue","images pending","queue status","pending jobs",
    ])
    isd =any(k in q for k in ["diskpool","disk pool","capacity","puredisk","free space","near full","storage pool"])
    # Status-filter queries — fleet-wide filtered pool results
    isd_down    = any(k in q for k in ["pool down","pools down","pool is down","pools that are down","down pool","down status","status down","which pools are down","pools with down"])
    isd_crit    = any(k in q for k in ["critical pool","pools critical","critical capacity","critical storage","critical disk","pool critical","above 85","over 85"])
    isd_warn    = any(k in q for k in ["warning pool","pools warning","near capacity","near limit","pool warning","above 70","over 70","approaching capacity"])
    isd_top     = any(k in q for k in ["top pool","top storage","highest pool","most used pool","top 10 pool","top 5 pool","largest pool","busiest pool"])
    isd_filter  = isd_down or isd_crit or isd_warn or isd_top
    isc =any(k in q for k in ["catalog","catalog backup","catalog health","catalog size","vvr","health score","catalog date","bpimagelist","catalog delayed","backup delayed"])
    # isag = Internal Airgap Vault (NOT external)
    isag=any(k in q for k in [
        "air-gap","airgap slp","air gap","retention compliance",
        "weekly backup","monthly backup","yearly backup","air master",
        "nbstlutil","slp replication","internal airgap","internal vault",
        "recovery vault","isolation vault","slp vault","compliance vault",
        "immutable vault","vault retention","vault replication","vault backlog",
        "vault breach","vault status","weekly vault","monthly vault",
        "internal airgap vault",
    ])
    if "tb" in q and not is3 and not isl and not isc and not isag: isd=True
    is_temporal=any(k in q for k in [
        "last week","last 7","last 3","last 5","last 14","last 30",
        "last 2 week","last month","this month","yesterday","today",
        "trend","history","how has","was it worse","over time",
        "30 days","14 days","7 days","3 days","5 days","2 days",
        "past month","past week","weekly trend","changed",
        "over the past","last 1","last 2","last 4","last 6",
        "last 10","this week","this year","last year",
    ])
    isa =any(k in q for k in ["anomal","spike","unusual","outlier","detect","alert","flagged","last 7","recent alert"])
    is_digest=any(k in q for k in [
        "digest","daily digest","morning report","fleet digest",
        "daily summary","fleet report","daily report",
    ])
    issum=any(k in q for k in ["summar","overview","health","global","all servers","fleet","everything","fleet health","fleet status"])
    try:
        # Use fuzzy resolver from vaultix_agent if available
        if _INTELLIGENCE_LOADED:
            matched_list = _resolve_server(q, known_servers())
            m            = matched_list[0] if matched_list else None
            server_filter= matched_list if matched_list else []
        else:
            m            = next((s for s in known_servers() if s in q), None)
            server_filter= [m] if m else []
        # ── Media server queries ─────────────────────────────────────────────
        # ── Backup jobs queries ──────────────────────────────────────────────
        if isbj and _INTELLIGENCE_LOADED:
            try:
                import sqlite3 as _bj_sq, pandas as _bj_pd
                _bj_con = _bj_sq.connect(DB_UNIFIED)
                _srv_b = (server_filter[0]
                          if server_filter and len(server_filter)==1
                          else None)
                _q_bj = """
                    SELECT * FROM backup_jobs_summary
                    WHERE report_date=(SELECT MAX(report_date)
                                       FROM backup_jobs_summary)
                """
                _p_bj = []
                if _srv_b:
                    _q_bj += " AND server_name=?"; _p_bj.append(_srv_b)
                if "daily" in q: _q_bj += " AND schedule='DAILY'"
                elif "weekly" in q: _q_bj += " AND schedule='WEEKLY'"
                elif "monthly" in q: _q_bj += " AND schedule='MONTHLY'"
                _q_bj += " ORDER BY success_rate ASC LIMIT 20"
                _bj_df = _bj_pd.read_sql_query(_q_bj, _bj_con, params=_p_bj)
                _bj_con.close()

                if not _bj_df.empty:
                    _bj_rows = []
                    for _, _br in _bj_df.iterrows():
                        _rate = float(_br.get("success_rate",0))
                        _sc = ("#dc2626" if _rate<85 else
                               "#d97706" if _rate<95 else "#16a34a")
                        _sbg = ("#fef2f2" if _rate<85 else
                                "#fffbeb" if _rate<95 else "#fff")
                        _bj_rows.append(html.Tr([
                            html.Td(str(_br["server_name"]),
                                style={"padding":"4px 8px","fontSize":"10px",
                                       "fontFamily":"monospace","color":"#1e3a5f",
                                       "fontWeight":"600"}),
                            html.Td(str(_br.get("schedule","")),
                                style={"padding":"4px 8px","fontSize":"9px",
                                       "color":"#64748b"}),
                            html.Td(str(_br.get("backup_type",""))[:20],
                                style={"padding":"4px 8px","fontSize":"9px",
                                       "color":"#64748b"}),
                            html.Td(f"{int(_br.get('total_jobs',0)):,}",
                                style={"padding":"4px 8px","fontSize":"10px",
                                       "textAlign":"right"}),
                            html.Td(f"{_rate:.1f}%",
                                style={"padding":"4px 8px","fontSize":"10px",
                                       "fontWeight":"700","color":_sc,
                                       "textAlign":"right"}),
                            html.Td(f"{int(_br.get('failed_jobs',0)):,}",
                                style={"padding":"4px 8px","fontSize":"10px",
                                       "textAlign":"right","color":_sc}),
                            html.Td(f"{float(_br.get('total_volume_tb',0)):.2f} TB",
                                style={"padding":"4px 8px","fontSize":"10px",
                                       "textAlign":"right","color":"#334155"}),
                            html.Td(f"{float(_br.get('backup_window_hours',0)):.1f}h",
                                style={"padding":"4px 8px","fontSize":"10px",
                                       "textAlign":"right","color":"#334155"}),
                        ], style={"borderBottom":"1px solid #f1f5f9",
                                  "background":_sbg}))

                    _bj_result = html.Div([
                        html.Div(
                            f"📊 Backup Jobs — "
                            f"{_srv_b.upper() if _srv_b else 'Fleet'} "
                            f"({len(_bj_df)} servers)",
                            style={"fontSize":"11px","fontWeight":"600",
                                   "color":"#1e3a5f","marginBottom":"8px"}),
                        html.Table([
                            html.Thead(html.Tr([
                                html.Th(h, style={"padding":"5px 8px",
                                    "background":"#f0f4fa","fontSize":"9px",
                                    "color":"#1e3a5f","fontWeight":"600",
                                    "textTransform":"uppercase",
                                    "textAlign":"right" if i>2 else "left"})
                                for i,h in enumerate(["Server","Schedule","Type",
                                    "Jobs","Success","Failed","Volume","Window"])
                            ])),
                            html.Tbody(_bj_rows),
                        ], style={"width":"100%","borderCollapse":"collapse",
                                  "background":"#fff","border":"1px solid #e2e8f0",
                                  "borderRadius":"6px","overflow":"hidden"}),
                        html.Div("→ See 📊 Backup Jobs tab for heatmap, window "
                                 "timeline, error codes and AI recommendations.",
                            style={"fontSize":"9px","color":"#94a3b8",
                                   "marginTop":"6px"}),
                    ])
                    return _bj_result, "backup_jobs", _srv_b or "fleet"
            except Exception as _bje:
                pass

        if isms:
            # Always resolve fresh from query for media — don't inherit server_filter
            _ms_resolved = _resolve_server(q, known_servers()) if _INTELLIGENCE_LOADED else []
            # Only use single-master scope; multi-server = fleet view
            if _ms_resolved and len(_ms_resolved) == 1:
                master_f = _ms_resolved[0]
            elif _ms_resolved and len(_ms_resolved) <= 4:
                # Small group (e.g. india p1+p2) — show all, no filter
                master_f = None
            else:
                master_f = None
            # Status filter from query keywords
            st_f = None
            if any(k in q for k in ["high load","overload","high_load"]): st_f="HIGH_LOAD"
            elif "anomaly" in q: st_f="ANOMALY"
            elif "balance" in q or "balanced" in q: st_f="BALANCED"
            elif "underutil" in q or "idle" in q: st_f="UNDERUTILIZED"
            return ans_media_servers(master_f=master_f, status_f=st_f, query=query), "media", master_f or "fleet"

                # Fleet status queries — intercept before temporal routing
        if not any([isl,isd,is3,isc,isag]) and _INTELLIGENCE_LOADED:
            if any(k in q for k in [
                "critical","which server","server issue","not working",
                "failing","breach today","status today","fleet status",
                "healthy server","worst server","servers are critical",
                "servers have issue","servers down",
            ]):
                try:
                    from vaultix_agent import build_fleet_summary
                    summary = build_fleet_summary()
                    if summary:
                        return summary,"fleet","fleet"
                except Exception:
                    pass

        # Temporal query routing
        if 'is_temporal' in dir() and is_temporal and _INTELLIGENCE_LOADED and not any([isc,is3,isag]) and len(server_filter) != 1:
            try:
                servers_to_query = server_filter if server_filter else ([m] if m else [])
                if servers_to_query:
                    if len(servers_to_query) == 1:
                        return _temporal_answer(servers_to_query[0], q),"temporal",servers_to_query[0]
                    else:
                        # Multi-server temporal — stack narratives
                        parts = []
                        for srv_t in servers_to_query:
                            try:
                                txt = _temporal_answer(srv_t, q)
                                # txt can be str or Dash component
                                srv_header = html.Div(srv_t.upper(),
                                    style={"fontSize":"11px","fontWeight":"700",
                                           "color":BRAND,"marginBottom":"4px",
                                           "marginTop":"8px","paddingBottom":"4px",
                                           "borderBottom":f"1px solid {BRAND}"})
                                if isinstance(txt, str):
                                    content = html.Div(txt,
                                        style={"fontSize":"11px","color":"#333",
                                               "lineHeight":"1.7","padding":"10px",
                                               "background":"#f0f4fa",
                                               "borderRadius":"6px",
                                               "borderLeft":f"3px solid {BRAND}",
                                               "marginBottom":"8px"})
                                else:
                                    content = html.Div(txt,
                                        style={"marginBottom":"12px"})
                                parts.append(html.Div([srv_header, content]))
                            except Exception:
                                pass
                        if parts:
                            label = ", ".join(s.upper() for s in servers_to_query[:3])
                            if len(servers_to_query) > 3:
                                label += f" +{len(servers_to_query)-3} more"
                            # Determine correct header icon and label
                            if isc:
                                _hdr_icon, _hdr_label = "📋", "Catalog Health"
                            elif isag:
                                _hdr_icon, _hdr_label = "🔒", "Internal Airgap Vault"
                            elif is3:
                                _hdr_icon, _hdr_label = "🌐", "External Airgap Vault"
                            elif isd:
                                _hdr_icon, _hdr_label = "💽", "Storage Pool History"
                            else:
                                _hdr_icon, _hdr_label = "📉", "Duplication Queue History"
                            return html.Div([
                                html.Div(f"{_hdr_icon} {_hdr_label} — {label}",
                                    style={"fontSize":"12px","fontWeight":"600",
                                           "color":BRAND,"marginBottom":"10px"}),
                            ] + parts), "temporal", label
            except Exception:
                pass
        # Digest query routing
        if 'is_digest' in dir() and is_digest and _INTELLIGENCE_LOADED:
            try:
                from nbu_unified_db import get_conn
                import pandas as pd
                rows = pd.read_sql_query("SELECT * FROM v_server_latest",
                                          get_conn(DB_UNIFIED))
                narrative = daily_digest_narrative(rows.to_dict("records"))
                return narrative,"digest",""
            except Exception as e:
                return f"Daily digest unavailable: {e}","digest",""
        # ── Fleet-wide status filter (down/critical/warning pools) ─────────
        if isd and isd_filter and not any([isl,is3,isc,isag]):
            import sqlite3 as _sqf
            _con = _sqf.connect(DB_UNIFIED)
            if isd_down:
                _filter_sql = "AND status='Down'"
                _filter_lbl = "Down pools — fleet"
                _filter_msg = "All storage pools with Down status across the fleet."
            elif isd_crit:
                _filter_sql = "AND health='CRITICAL'"
                _filter_lbl = "Critical pools — fleet"
                _filter_msg = "All storage pools at critical capacity (≥85%) across the fleet."
            elif isd_warn:
                _filter_sql = "AND health IN ('WARNING','CRITICAL')"
                _filter_lbl = "Warning/Critical pools — fleet"
                _filter_msg = "All storage pools at warning or critical capacity across the fleet."
            else:
                _filter_sql = "ORDER BY pct_used DESC LIMIT 20"
                _filter_lbl = "Top pools by usage — fleet"
                _filter_msg = "Top storage pools by capacity usage across the fleet."
            _rows = _con.execute(f"""
                SELECT server_name, diskpool,
                       ROUND(used_tb,2), ROUND(total_tb,2),
                       ROUND(pct_used,1), health, status
                FROM diskpool_daily
                WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily)
                AND diskpool_group != 'Recovery Vault'
                {_filter_sql if not isd_top else ""}
                {"ORDER BY pct_used DESC LIMIT 20" if not isd_top else _filter_sql}
            """).fetchall()
            _con.close()
            _th  = {"padding":"6px 10px","fontSize":"10px","textTransform":"uppercase",
                    "letterSpacing":"0.4px","fontWeight":"500","color":"#64748b",
                    "background":"#f8fafc","borderBottom":"0.5px solid #e2e8f0"}
            _thr = {**_th,"textAlign":"right"}
            _thc = {**_th,"textAlign":"center"}
            _tbl_rows = []
            for _srv,_pool,_used,_total,_pct,_health,_status in (_rows or []):
                _hc = "#A32D2D" if _health=="CRITICAL" else "#854F0B" if _health=="WARNING" else "#3B6D11"
                _sc = "#3B6D11" if _status=="Up" else "#A32D2D"
                _tbl_rows.append(html.Tr([
                    html.Td(_srv.replace("cbkms",""),
                            style={"padding":"6px 10px","fontFamily":"monospace","fontSize":"10px","fontWeight":"500"}),
                    html.Td(_pool[:32]+"…" if len(_pool)>32 else _pool,
                            style={"padding":"6px 10px","fontSize":"10px","color":"#64748b"}),
                    html.Td(f"{_used} TB",style={"padding":"6px 10px","textAlign":"right","fontWeight":"500"}),
                    html.Td(f"{_total} TB",style={"padding":"6px 10px","textAlign":"right","color":"#64748b"}),
                    html.Td(f"{_pct}%",style={"padding":"6px 10px","textAlign":"right","fontWeight":"500","color":_hc}),
                    html.Td(_health,style={"padding":"6px 10px","textAlign":"center","color":_hc,"fontWeight":"500"}),
                    html.Td(_status,style={"padding":"6px 10px","textAlign":"center","color":_sc,"fontWeight":"500"}),
                ], style={"borderBottom":"0.5px solid #f1f5f9",
                          "background":"#FCEBEB" if _health=="CRITICAL" else
                                       "#FAEEDA" if _health=="WARNING" else
                                       "#fff0f0" if _status=="Down" else "#fff"}))
            if not _tbl_rows:
                _tbl_rows = [html.Tr([html.Td("No pools found matching this filter.",
                    colspan=7, style={"padding":"12px","color":"#94a3b8","textAlign":"center"})])]
            _result = html.Div([
                html.Div([
                    html.Span("💽 ",style={"fontSize":"13px","marginRight":"7px"}),
                    html.Span(_filter_lbl,style={"fontSize":"12px","fontWeight":"500"}),
                    html.Span(f" ({len(_rows)} pools)",
                              style={"fontSize":"11px","color":"#94a3b8","marginLeft":"6px"}),
                ],style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
                html.Div(_filter_msg,
                         style={"fontSize":"11px","color":"#64748b","marginBottom":"10px"}),
                html.Table([
                    html.Thead(html.Tr([
                        html.Th("Server",style=_th),html.Th("Pool",style=_th),
                        html.Th("Used TB",style=_thr),html.Th("Total TB",style=_thr),
                        html.Th("% Used",style=_thr),html.Th("Health",style=_thc),
                        html.Th("Status",style=_thc),
                    ])),
                    html.Tbody(_tbl_rows),
                ],style={"width":"100%","borderCollapse":"collapse",
                         "border":"0.5px solid #e2e8f0","borderRadius":"8px","overflow":"hidden"}),
            ])
            return _result,"diskpool","fleet"

        # ── Single server — exact match ──────────────────────────────────
        if m and len(server_filter) == 1:
            if isl  and not any([is3,isd,isc,isag]):
                # Route to temporal if time-range query
                if 'is_temporal' in dir() and is_temporal and _INTELLIGENCE_LOADED:
                    try:
                        result = _temporal_answer(m, q)
                        return result,"temporal",m
                    except Exception:
                        pass
                return _wrap_with_narrative(ans_srv_lag(m), m, "lag"),"lag",m
            if is3  and not any([isl,isd,isc,isag]):
                if 'is_temporal' in dir() and is_temporal and _INTELLIGENCE_LOADED:
                    try:
                        result = _temporal_answer(m, q)
                        return result,"temporal",m
                    except Exception:
                        pass
                return _wrap_with_narrative(ans_srv_3rd(m), m, "3rdsite"),"3rdsite",m
            if isd  and not any([isl,is3,isc,isag]):
                # Fleet-wide status filter queries
                if isd_filter:
                    import sqlite3 as _sqf
                    _con = _sqf.connect(DB_UNIFIED)
                    if isd_down:
                        _filter_sql = "AND status='Down'"
                        _filter_lbl = "Down pools — fleet"
                        _filter_msg = "All storage pools with Down status across the fleet."
                    elif isd_crit:
                        _filter_sql = "AND health='CRITICAL'"
                        _filter_lbl = "Critical pools — fleet"
                        _filter_msg = "All storage pools at critical capacity (≥85%) across the fleet."
                    elif isd_warn:
                        _filter_sql = "AND health IN ('WARNING','CRITICAL')"
                        _filter_lbl = "Warning/Critical pools — fleet"
                        _filter_msg = "All storage pools at warning or critical capacity across the fleet."
                    else:
                        _filter_sql = ""
                        _filter_lbl = "Top pools by usage — fleet"
                        _filter_msg = "Top storage pools by capacity usage across the fleet."
                    _rows = _con.execute(f"""
                        SELECT server_name, diskpool,
                               ROUND(used_tb,2), ROUND(total_tb,2),
                               ROUND(pct_used,1), health, status
                        FROM diskpool_daily
                        WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily)
                        AND diskpool_group != 'Recovery Vault'
                        {_filter_sql}
                        ORDER BY pct_used DESC LIMIT 50
                    """).fetchall()
                    _con.close()
                    if not _rows:
                        return html.Div(f"💽 No pools found matching filter.",
                                        style={{"padding":"12px","color":"#94a3b8"}}), "diskpool", "fleet"
                    _th = {{"padding":"6px 10px","fontSize":"10px","textTransform":"uppercase",
                            "letterSpacing":"0.4px","fontWeight":"500","color":"#64748b",
                            "background":"#f8fafc","borderBottom":"0.5px solid #e2e8f0"}}
                    _thr = {{**_th,"textAlign":"right"}}
                    _thc = {{**_th,"textAlign":"center"}}
                    _tbl_rows = []
                    for _srv, _pool, _used, _total, _pct, _health, _status in _rows:
                        _hc = "#A32D2D" if _health=='CRITICAL' else "#854F0B" if _health=='WARNING' else "#3B6D11"
                        _sc = "#3B6D11" if _status=="Up" else "#A32D2D"
                        _tbl_rows.append(html.Tr([
                            html.Td(_srv.replace("cbkms",""),
                                    style={{"padding":"6px 10px","fontFamily":"monospace","fontSize":"10px","fontWeight":"500"}}),
                            html.Td(_pool[:32]+"…" if len(_pool)>32 else _pool,
                                    style={{"padding":"6px 10px","fontSize":"10px","color":"#64748b"}}),
                            html.Td(f"{{_used}} TB",style={{"padding":"6px 10px","textAlign":"right","fontWeight":"500"}}),
                            html.Td(f"{{_total}} TB",style={{"padding":"6px 10px","textAlign":"right","color":"#64748b"}}),
                            html.Td(f"{{_pct}}%",style={{"padding":"6px 10px","textAlign":"right","fontWeight":"500","color":_hc}}),
                            html.Td(_health,style={{"padding":"6px 10px","textAlign":"center","color":_hc,"fontWeight":"500"}}),
                            html.Td(_status,style={{"padding":"6px 10px","textAlign":"center","color":_sc,"fontWeight":"500"}}),
                        ], style={{"borderBottom":"0.5px solid #f1f5f9",
                                   "background":"#FCEBEB" if _health=='CRITICAL' else
                                                "#FAEEDA" if _health=='WARNING' else
                                                "#fff0f0" if _status=='Down' else "#fff"}}))
                    _result = html.Div([
                        html.Div([
                            html.Span("💽 ", style={{"fontSize":"13px","marginRight":"7px"}}),
                            html.Span(_filter_lbl, style={{"fontSize":"12px","fontWeight":"500"}}),
                            html.Span(f" ({len(_rows)} pools)",
                                      style={{"fontSize":"11px","color":"#94a3b8","marginLeft":"6px"}}),
                        ], style={{"display":"flex","alignItems":"center","marginBottom":"8px"}}),
                        html.Div(_filter_msg,
                                 style={{"fontSize":"11px","color":"#64748b","marginBottom":"10px"}}),
                        html.Table([
                            html.Thead(html.Tr([
                                html.Th("Server",style=_th),html.Th("Pool",style=_th),
                                html.Th("Used TB",style=_thr),html.Th("Total TB",style=_thr),
                                html.Th("% Used",style=_thr),html.Th("Health",style=_thc),
                                html.Th("Status",style=_thc),
                            ])),
                            html.Tbody(_tbl_rows),
                        ], style={{"width":"100%","borderCollapse":"collapse",
                                   "border":"0.5px solid #e2e8f0","borderRadius":"8px","overflow":"hidden"}}),
                    ])
                    return _result, "diskpool", "fleet"
                if 'is_temporal' in dir() and is_temporal and _INTELLIGENCE_LOADED:
                    try:
                        result = _temporal_answer(m, q)
                        return result,"temporal",m
                    except Exception:
                        pass
                return _wrap_with_narrative(ans_srv_dp(m), m, "diskpool"),"diskpool",m
            if isc  and not any([isl,is3,isd,isag]):
                if 'is_temporal' in dir() and is_temporal and _INTELLIGENCE_LOADED:
                    try:
                        result = _temporal_answer(m, q)
                        return result,"temporal",m
                    except Exception:
                        pass
                return _wrap_with_narrative(ans_srv_catalog(m), m, "catalog"),"catalog",m
            if isag and not any([isl,is3,isd,isc]):
                if 'is_temporal' in dir() and is_temporal and _INTELLIGENCE_LOADED:
                    try:
                        result = _temporal_answer(m, q)
                        return result,"temporal",m
                    except Exception:
                        pass
                return _wrap_with_narrative(ans_srv_airgap(m), m, "airgap"),"airgap",m
            return ans_srv_full(m),"server_full",m

        # ── Comparison chart (explicit compare request) ──────────────────
        if 'is_compare' in dir() and is_compare and _INTELLIGENCE_LOADED:
            target_servers = server_filter if server_filter else known_servers()
            days_match = __import__('re').search(r'last\s+(\d+)\s+day', q)
            chart_days = int(days_match.group(1)) if days_match else 14
            if "last week" in q: chart_days = 7
            if "last month" in q or "last 30" in q: chart_days = 30
            metric = ("lag"   if isl else
                      "disk"  if isd else
                      "catalog" if isc else "lag")
            try:
                chart = _build_comparison_chart(target_servers[:8],
                                                metric, days=chart_days)
                if chart:
                    metric_labels = {
                        "lag":     "Duplication Queue",
                        "disk":    "Storage Pool Usage",
                        "catalog": "Backup Health Index",
                    }
                    srv_labels = ", ".join(
                        s.upper() for s in target_servers[:4])
                    if len(target_servers) > 4:
                        srv_labels += f" +{len(target_servers)-4} more"
                    return html.Div([
                        html.Div(
                            f"📊 {metric_labels.get(metric,'Comparison')} — "
                            f"{srv_labels} — last {chart_days} days",
                            style={"fontSize":"12px","fontWeight":"600",
                                   "color":"#1A3C5E","marginBottom":"8px"}),
                        chart,
                    ]), "temporal", srv_labels
            except Exception as _ce:
                pass

        # ── Multi-server group (country/region alias resolved) ────────────
        if server_filter and len(server_filter) > 1:
            label = ", ".join(s.upper() for s in server_filter)
            if isl  and not any([is3,isd,isc,isag]):
                # Compare chart
                if 'is_compare' in dir() and is_compare:
                    try:
                        chart = _build_comparison_chart(server_filter, "lag", days=14)
                        if chart:
                            return html.Div([
                                html.Div(f"📉 Duplication Queue Comparison — {label}",
                                    style={"fontSize":"12px","fontWeight":"600",
                                           "color":"#1A3C5E","marginBottom":"8px"}),
                                chart
                            ]),"temporal",label
                    except Exception:
                        pass
                # If temporal query, route to temporal handler for each server
                if 'is_temporal' in dir() and is_temporal and _INTELLIGENCE_LOADED:
                    parts = []
                    for srv_t in server_filter:
                        try:
                            result = _temporal_answer(srv_t, q)
                            srv_label = html.Div(srv_t.upper(),
                                style={"fontSize":"10px","fontWeight":"700",
                                       "color":"#1A3C5E","marginBottom":"4px",
                                       "marginTop":"8px"})
                            parts.append(html.Div([srv_label, result]))
                        except Exception:
                            pass
                    if parts:
                        return html.Div([
                            html.Div(f"📉 Duplication Queue History — {label}",
                                style={"fontSize":"12px","fontWeight":"600",
                                       "color":"#1A3C5E","marginBottom":"10px"}),
                        ] + parts), "temporal", label
                return ans_lag_filtered(server_filter, label),"lag",label
            if is3  and not any([isl,isd,isc,isag]):
                return ans_3rd_filtered(server_filter, label),"3rdsite",label
            if isd  and not any([isl,is3,isc,isag]):
                return ans_dp_filtered(server_filter, label),"diskpool",label
            if isc  and not any([isl,is3,isd,isag]):
                if 'is_temporal' in dir() and is_temporal and _INTELLIGENCE_LOADED:
                    parts = []
                    for srv_t in server_filter:
                        try:
                            result = _temporal_answer(srv_t, q)
                            srv_hdr = html.Div(srv_t.upper(),
                                style={"fontSize":"11px","fontWeight":"700",
                                       "color":"#1A3C5E","marginBottom":"4px",
                                       "marginTop":"8px","paddingBottom":"4px",
                                       "borderBottom":"1px solid #1A3C5E"})
                            content = (html.Div(result, style={"marginBottom":"12px"})
                                       if not isinstance(result, str)
                                       else html.Div(result, style={"fontSize":"11px",
                                           "padding":"8px","background":"#eef4ff",
                                           "borderRadius":"6px","marginBottom":"8px"}))
                            parts.append(html.Div([srv_hdr, content]))
                        except Exception:
                            pass
                    if parts:
                        return html.Div([
                            html.Div(f"📋 Catalog Health — {label}",
                                style={"fontSize":"12px","fontWeight":"600",
                                       "color":"#1A3C5E","marginBottom":"10px"}),
                        ] + parts), "temporal", label
                return ans_catalog_filtered(server_filter, label),"catalog",label
            if isag and not any([isl,is3,isd,isc]):
                if 'is_temporal' in dir() and is_temporal and _INTELLIGENCE_LOADED:
                    parts = []
                    for srv_t in server_filter:
                        try:
                            result = _temporal_answer(srv_t, q)
                            srv_hdr = html.Div(srv_t.upper(),
                                style={"fontSize":"11px","fontWeight":"700",
                                       "color":"#1A3C5E","marginBottom":"4px",
                                       "marginTop":"8px","paddingBottom":"4px",
                                       "borderBottom":"1px solid #1A3C5E"})
                            content = (html.Div(result, style={"marginBottom":"12px"})
                                       if not isinstance(result, str)
                                       else html.Div(result, style={"fontSize":"11px",
                                           "padding":"8px","background":"#eef4ff",
                                           "borderRadius":"6px","marginBottom":"8px"}))
                            parts.append(html.Div([srv_hdr, content]))
                        except Exception:
                            pass
                    if parts:
                        return html.Div([
                            html.Div(f"🔒 Internal Airgap Vault — {label}",
                                style={"fontSize":"12px","fontWeight":"600",
                                       "color":"#1A3C5E","marginBottom":"10px"}),
                        ] + parts), "temporal", label
                return ans_airgap_filtered(server_filter, label),"airgap",label
            # Default: show full report for each server in group
            return ans_group_full(server_filter, label),"server_full",label

        # ── Fleet-wide queries (no server specified) ──────────────────────
        if is3  and not isl: return ans_3rd(q),"3rdsite",""
        if isl  and not is3: return ans_lag(q),"lag",""
        if isc:              return ans_catalog(q),"catalog",""
        if isag:             return ans_airgap(q),"airgap",""
        if isd:
            # Try intelligent temporal/analytical answer first
            _intel = _intelligent_pool_answer(query, q)
            if _intel: return _intel,"diskpool","fleet"
            return ans_dp(q),"diskpool",""
        if isa:              return ans_anomaly(),"anomaly",""
        if issum:
            if _MCP_AVAILABLE:
                mcp_result = _mcp_answer(query, q, "summary", [], "fleet")
                if mcp_result:
                    return mcp_result,"mcp_intelligence","fleet"
            return ans_summary(),"summary",""
        label = label if 'label' in dir() else "fleet"
        # Try MCP intelligence first
        if _MCP_AVAILABLE:
            _mcp_label = label if 'label' in dir() and label else (server_filter[0] if server_filter else "fleet")
            mcp_result = _mcp_answer(query, q, "rag_fallback",
                                     server_filter, _mcp_label)
            if mcp_result:
                return mcp_result,"mcp_intelligence",server_filter[0] if server_filter else "fleet"
        fb=rag_fallback(query)
        return fb,"rag_fallback",""
    except Exception as e:
        logger.error(f"slm_answer_full: {e}"); return f"⚠️ Error: {e}","error",""

def ans_srv_full(srv):
    # Add cross-report narrative if intelligence loaded
    narrative_block = None
    if _INTELLIGENCE_LOADED:
        try:
            narrative_txt = build_server_narrative(srv)
            narrative_block = html.Div(narrative_txt,
                style={"fontSize":"11px","color":"#444","lineHeight":"1.7",
                       "marginBottom":"12px","padding":"10px 13px",
                       "background":"#f0f4fa","borderRadius":"6px",
                       "borderLeft":f"3px solid {BRAND}"})
        except Exception:
            narrative_block = None

    lag=qrow(DB_UNIFIED,f"SELECT * FROM lag_history WHERE server_name='{srv}' ORDER BY date DESC LIMIT 1")
    dp =qrow(DB_UNIFIED,f"SELECT COUNT(*) as pools,SUM(CASE WHEN health='CRITICAL' THEN 1 ELSE 0 END) as crit,ROUND(AVG(pct_used),1) as avg_pct FROM diskpool_daily WHERE server_name='{srv}' AND run_date=(SELECT MAX(run_date) FROM diskpool_daily WHERE server_name='{srv}')")
    ts =qrow(DB_UNIFIED,f"SELECT total_data_tb,avg_dedup_percent,max_worm_days FROM thirdsite_summary WHERE server_name='{srv}' ORDER BY report_date DESC LIMIT 1")
    cat=qrow(DB_UNIFIED,f"SELECT catalog_status,health_score FROM catalog_health WHERE server_name='{srv}' ORDER BY checked_at DESC LIMIT 1")
    ag =qrow(DB_UNIFIED,f"SELECT image_count,status FROM airgap_replication WHERE server_name='{srv}' ORDER BY checked_at DESC LIMIT 1")
    ag_ret=qrow(DB_UNIFIED,f"SELECT weekly_compliant,monthly_compliant,yearly_compliant,weekly_backups,monthly_backups,yearly_backups FROM airgap_retention WHERE server_name='{srv}' ORDER BY checked_at DESC LIMIT 1")
    def row(icon,label,val,st):
        return html.Div([html.Span(icon,style={"width":"18px","flexShrink":"0"}),html.Span(label,style={"width":"80px","flexShrink":"0","color":"#888","fontSize":"10px"}),html.Span(val,style={"flex":"1","fontSize":"10px","fontWeight":"500"}),st],
            style={"display":"flex","alignItems":"center","padding":"6px 12px","borderBottom":"0.5px solid #f0f0f0","gap":"8px"})
    rows=[]
    if lag: rows.append(row("📉","Lag",f"{lag['total']} images",pill("QUEUE BREACH","danger") if lag['above_sla'] else pill("OK","success")))
    if dp:  rows.append(row("💽","Disk pools",f"{dp['pools']} pools · {dp['crit']}🔴 · avg {dp['avg_pct']:.0f}%",pill("CRITICAL","danger") if dp['crit']>0 else pill("OK","success")))
    if ts:  rows.append(row("🌐","3rd-site",f"{ts['total_data_tb']:.3f} TB · dedup {ts['avg_dedup_percent']:.1f}% · WORM {ts['max_worm_days']:.0f}d",pill("LOW WORM","danger") if ts['max_worm_days']<30 else pill("OK","success")))
    if cat: rows.append(row("📋","Catalog",f"{cat['catalog_status']} · score {cat['health_score']:.0f}/100",pill(cat['catalog_status'],_status_color(cat['catalog_status']))))
    if ag:
        ret_str=""
        if ag_ret: ret_str=f" · W{'✓' if ag_ret['weekly_compliant'] else '✗'} M{'✓' if ag_ret['monthly_compliant'] else '✗'} Y{'✓' if ag_ret['yearly_compliant'] else '✗'}"
        all_ok=ag_ret and ag_ret['weekly_compliant'] and ag_ret['monthly_compliant'] and ag_ret['yearly_compliant']
        rows.append(row("🔄","Airgap",f"{ag['status']} · backlog {ag['image_count']}{ret_str}",pill("OK","success") if all_ok else pill("VAULT BREACH","danger")))
    children = []
    if narrative_block:
        children.append(narrative_block)
    children.append(html.Div([
        html.Div([html.Span(srv.upper(),style={"fontSize":"12px","fontWeight":"500","color":"#fff","letterSpacing":"0.5px"}),html.Span("Full report",style={"fontSize":"9px","color":"rgba(255,255,255,0.6)","marginLeft":"auto"})],
                 style={"background":BRAND,"padding":"8px 12px","borderRadius":"6px 6px 0 0","display":"flex","alignItems":"center"}),
        html.Div(rows or [html.Div("No unified data. Run sync.",style={"padding":"10px 12px","fontSize":"11px","color":"#E24B4A"})],
                 style={"background":"#fff","border":"0.5px solid #e0e0e0","borderTop":"none","borderRadius":"0 0 6px 6px"})
    ],style={"borderRadius":"6px","overflow":"hidden"}))
    return html.Div(children)

def ans_lag(q):
    df=qdf(DB_LAG,"SELECT server,total,not_started_remote,in_process_remote,not_started_duplicate,in_process_duplicate,date FROM lag_history WHERE date=(SELECT MAX(date) FROM lag_history) ORDER BY total DESC")
    if df.empty: return "📉 No lag data."
    above=df[df["total"]>SLA_THRESH]; healthy=df[df["total"]==0]; date_val=df["date"].iloc[0]
    def rows(df):
        r=[]
        for _,row in df.iterrows():
            t=int(row["total"]); bg="#fff0f0" if t>SLA_THRESH else "#fff8ec" if t>SLA_THRESH*0.8 else None
            r.append(("_color",bg,[row["server"],int(row["not_started_remote"]),int(row["in_process_remote"]),int(row["not_started_duplicate"]),int(row["in_process_duplicate"]),html.Span(str(t),style={"fontWeight":"500","color":_lag_color(t)}),pill("QUEUE BREACH","danger") if t>SLA_THRESH else pill("NEAR","warning") if t>SLA_THRESH*0.8 else pill("OK","success")]))
        return r
    return html.Div([resp_header("📉","Duplication Queue — all servers",f"{date_val}"),resp_kpis([("Queue depth",int(df["total"].sum()),"#E24B4A"),("Breaching SLA",len(above),"#E24B4A"),("Healthy",len(healthy),"#639922"),(f"SLA={SLA_THRESH}","",BRAND)]),rich_table(["Server","NS Repl","IP Repl","NS Dup","IP Dup","Total","Status"],rows(df))])

def ans_3rd(q):
    df=qdf(DB_3RDSITE,"SELECT ds.master_server,ROUND(ds.total_data_tb,3) AS tb,ROUND(ds.avg_dedup_percent,1) AS dedup,ROUND(ds.avg_gbps,4) AS gbps,ROUND(ds.max_worm_days,1) AS worm,r.date FROM duplication_summary ds JOIN reports r ON ds.report_id=r.id WHERE ds.report_id=(SELECT MAX(id) FROM reports) ORDER BY ds.avg_dedup_percent DESC")
    if df.empty: return "🌐 No 3rd-site data."
    date_val=df["date"].iloc[0][:10]
    def rows(df):
        r=[]
        for _,row in df.iterrows():
            d=row["dedup"]; bg="#fff0f0" if d<30 else "#fff8ec" if d<50 else None
            r.append(("_color",bg,[row["master_server"],f"{row['tb']:.3f}",f"{row['gbps']:.4f}",mini_bar(min(d,100)),f"{row['worm']:.0f}d",pill("LOW","danger") if row['worm']<30 else pill("OK","success"),pill("GOOD","success") if d>=50 else pill("MODERATE","warning") if d>=30 else pill("LOW","danger")]))
        return r
    return html.Div([resp_header("🌐","External Airgap Vault — dedup efficiency",f"{date_val}"),resp_kpis([("Vaulted (TB)",f"{df['tb'].sum():.3f}",BRAND),("Vault dedup",f"{df['dedup'].mean():.1f}%","#639922"),("Servers",len(df),"#378ADD"),("WORM <30d",int((df['worm']<30).sum()),"#E24B4A")]),rich_table(["Server","Vaulted (TB)","Avg GB/s","Dedup %","Immutable retention (d)","WORM","Dedup status"],rows(df))])

def ans_dp(q):
    lim=5 if "top 5" in q else 10
    df=qdf(DB_DISKPOOL,f"SELECT server,diskpool,ROUND(used_tb,2) AS used,ROUND(total_tb,2) AS total,ROUND(free_tb,2) AS free,ROUND(used_tb*100.0/total_tb,1) AS pct FROM diskpool_daily WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily) ORDER BY pct DESC LIMIT {lim}")
    if df.empty: return "💽 No diskpool data."
    def rows(df):
        r=[]
        for _,row in df.iterrows():
            p=row["pct"]; bg="#fff0f0" if p>=85 else "#fff8ec" if p>=70 else None
            r.append(("_color",bg,[row["diskpool"],row["server"],f"{row['used']}",f"{row['total']}",f"{row['free']}",mini_bar(p),pill("CRITICAL","danger") if p>=85 else pill("WARNING","warning") if p>=70 else pill("HEALTHY","success")]))
        return r
    return html.Div([resp_header("💽",f"Top {lim} diskpools by utilization"),rich_table(["Pool","Server","Used TB","Total TB","Free TB","% Used","Status"],rows(df))])

def ans_catalog(q):
    df=qdf(DB_CATALOG,"SELECT server,catalog_date,catalog_status,health_score,anomaly_detected FROM health_records hr1 WHERE timestamp=(SELECT MAX(timestamp) FROM health_records WHERE server=hr1.server) ORDER BY health_score ASC")
    if df.empty: return "📋 No catalog data."
    def rows(df):
        r=[]
        for _,row in df.iterrows():
            s=row["health_score"]; bg="#fff0f0" if s<60 else "#fff8ec" if s<80 else None
            r.append(("_color",bg,[row["server"],pill(row["catalog_status"],_status_color(row["catalog_status"])),mini_bar(s),str(row["catalog_date"])[:10],pill("Yes","danger") if row.get("anomaly_detected") else pill("No","secondary")]))
        return r
    return html.Div([resp_header("📋","Catalog backup health — all servers"),resp_kpis([("Success",int((df["catalog_status"]=="SUCCESS").sum()),"#639922"),("Delayed",int((df["catalog_status"]=="DELAYED").sum()),"#EF9F27"),("Errors",int((df["catalog_status"]=="ERROR").sum()),"#E24B4A"),("Avg score",round(df["health_score"].mean(),1),BRAND)]),rich_table(["Server","Status","Health score","Catalog date","Anomaly"],rows(df))])

def ans_airgap(q):
    rep=qdf(DB_AIRGAP,"SELECT server,image_count,status,air_master FROM replication_status rs1 WHERE timestamp=(SELECT MAX(timestamp) FROM replication_status WHERE server=rs1.server) ORDER BY image_count DESC")
    ret=qdf(DB_AIRGAP,"SELECT server,weekly_backups,monthly_backups,yearly_backups,weekly_compliant,monthly_compliant,yearly_compliant FROM retention_compliance rc1 WHERE timestamp=(SELECT MAX(timestamp) FROM retention_compliance WHERE server=rc1.server)")
    if rep.empty: return "🔄 No airgap data."
    df=pd.merge(rep,ret,on="server",how="left") if not ret.empty else rep
    def rows(df):
        r=[]
        for _,row in df.iterrows():
            wc=row.get("weekly_compliant"); mc=row.get("monthly_compliant"); yc=row.get("yearly_compliant"); all_ok=bool(wc) and bool(mc) and bool(yc); bg=None if all_ok else "#fff0f0"; st=row.get("status","—")
            r.append(("_color",bg,[row["server"],pill(st,"success" if st=="Completed" else "warning" if st=="Working" else "danger"),html.Span(str(int(row["image_count"])),style={"fontWeight":"500","color":_lag_color(row["image_count"])}),row.get("air_master","—"),
                html.Span(f"{'✓' if wc else '✗'} {int(row['weekly_backups']) if not pd.isna(row.get('weekly_backups',float('nan'))) else 0}",style={"color":"#639922" if wc else "#E24B4A","fontWeight":"500"}),
                html.Span(f"{'✓' if mc else '✗'} {int(row['monthly_backups']) if not pd.isna(row.get('monthly_backups',float('nan'))) else 0}",style={"color":"#639922" if mc else "#E24B4A","fontWeight":"500"}),
                html.Span(f"{'✓' if yc else '✗'} {int(row['yearly_backups']) if not pd.isna(row.get('yearly_backups',float('nan'))) else 0}",style={"color":"#639922" if yc else "#E24B4A","fontWeight":"500"}),
                pill("OK","success") if all_ok else pill("VAULT BREACH","danger")]))
        return r
    return html.Div([resp_header("🔄","Internal Airgap Vault — replication status"),resp_kpis([("Total backlog",int(rep["image_count"].sum()),"#E24B4A"),("Completed",int((rep["status"]=="Completed").sum()),"#639922"),("Working",int((rep["status"]=="Working").sum()),"#EF9F27"),("Violations",int((~(ret["weekly_compliant"].astype(bool)&ret["monthly_compliant"].astype(bool)&ret["yearly_compliant"].astype(bool))).sum()) if not ret.empty else 0,"#E24B4A")]),rich_table(["Server","Status","Backlog","Air master","Weekly","Monthly","Yearly","Vault retention"],rows(df))])

def ans_srv_lag(srv):
    # Add narrative paragraph if intelligence loaded
    narrative_div = None
    if _INTELLIGENCE_LOADED:
        try:
            r = _qrow_local(DB_UNIFIED,
                "SELECT total, above_sla, not_started_remote, "
                "in_process_remote, not_started_duplicate, in_process_duplicate "
                "FROM lag_history WHERE server_name=? ORDER BY date DESC LIMIT 1",
                (srv,))
            if r:
                from narrative_engine import lag_narrative
                txt = lag_narrative(
                    srv,
                    int(r.get("total",0)),
                    SLA_THRESH,
                    int(r.get("not_started_remote",0)),
                    int(r.get("in_process_remote",0)),
                    int(r.get("not_started_duplicate",0)),
                    int(r.get("in_process_duplicate",0)),
                    above_sla=bool(r.get("above_sla",0)))
                narrative_div = html.Div(txt, style={
                    "fontSize":"11px","color":"#444","lineHeight":"1.7",
                    "marginBottom":"10px","padding":"10px 13px",
                    "background":"#f0f4fa","borderRadius":"6px",
                    "borderLeft":f"3px solid {BRAND}"})
        except Exception:
            pass
    df=qdf(DB_LAG,f"SELECT date,total,not_started_remote,in_process_remote,not_started_duplicate,in_process_duplicate FROM lag_history WHERE server='{srv}' ORDER BY date DESC LIMIT 14")
    if df.empty: return f"📉 No lag data for '{srv}'."
    def rows(df):
        r=[]
        for _,row in df.iterrows():
            t=int(row["total"]); bg="#fff0f0" if t>SLA_THRESH else "#fff8ec" if t>SLA_THRESH*0.8 else None
            r.append(("_color",bg,[row["date"],int(row["not_started_remote"]),int(row["in_process_remote"]),int(row["not_started_duplicate"]),int(row["in_process_duplicate"]),html.Span(str(t),style={"fontWeight":"500","color":_lag_color(t)}),pill("QUEUE BREACH","danger") if t>SLA_THRESH else pill("NEAR","warning") if t>SLA_THRESH*0.8 else pill("OK","success")]))
        return r
    return html.Div([resp_header("📉",f"Duplication Queue history — {srv.upper()}",f"latest: {df.iloc[0]['date']}"),rich_table(["Date","NS Repl","IP Repl","NS Dup","IP Dup","Total","Status"],rows(df))])

def ans_srv_3rd(srv):
    df=qdf(DB_3RDSITE,f"SELECT r.date,ds.total_data_tb,ds.avg_dedup_percent,ds.avg_gbps,ds.max_worm_days FROM duplication_summary ds JOIN reports r ON ds.report_id=r.id WHERE ds.master_server='{srv}' ORDER BY r.date DESC LIMIT 14")
    if df.empty: return f"🌐 No 3rd-site data for '{srv}'."
    def rows(df):
        r=[]
        for _,row in df.iterrows():
            d=row["avg_dedup_percent"]
            r.append(("_color",None,[row["date"],f"{row['total_data_tb']:.3f}",f"{row['avg_gbps']:.4f}",mini_bar(min(d,100)),f"{row['max_worm_days']:.0f}d",pill("LOW","danger") if row['max_worm_days']<30 else pill("OK","success")]))
        return r
    return html.Div([resp_header("🌐",f"External Airgap Vault history — {srv.upper()}"),rich_table(["Date","Vaulted (TB)","Avg GB/s","Dedup %","Immutable retention (d)","WORM status"],rows(df))])

def ans_srv_dp(srv):
    import sqlite3 as _sq
    con = _sq.connect(DB_UNIFIED)
    rows_db = con.execute("""
        SELECT server_name, diskpool,
               ROUND(used_tb,2), ROUND(total_tb,2),
               ROUND(pct_used,1), health, status
        FROM diskpool_daily
        WHERE server_name=? AND run_date=(SELECT MAX(run_date) FROM diskpool_daily WHERE server_name=?)
        AND diskpool_group != 'Recovery Vault'
        ORDER BY pct_used DESC
    """, (srv, srv)).fetchall()
    total_used = con.execute(
        "SELECT ROUND(SUM(used_tb),2) FROM diskpool_daily WHERE server_name=? AND run_date=(SELECT MAX(run_date) FROM diskpool_daily WHERE server_name=?) AND diskpool_group!='Recovery Vault'",
        (srv, srv)).fetchone()[0] or 0
    total_cap = con.execute(
        "SELECT ROUND(SUM(total_tb),2) FROM diskpool_daily WHERE server_name=? AND run_date=(SELECT MAX(run_date) FROM diskpool_daily WHERE server_name=?) AND diskpool_group!='Recovery Vault'",
        (srv, srv)).fetchone()[0] or 1
    con.close()
    if not rows_db: return f"💽 No diskpool data for '{srv}'."
    pct_fleet = round(total_used/total_cap*100,1)
    crit = sum(1 for r in rows_db if r[5]=='CRITICAL')
    warn = sum(1 for r in rows_db if r[5]=='WARNING')
    summary = (f"{srv.upper()} has {len(rows_db)} storage pool(s)"
               f"{f' — {crit} pool(s) at critical capacity (≥85%) — backup jobs may begin failing.' if crit else ''}"
               f" Total used: {total_used} TB of {total_cap} TB ({pct_fleet}% fleet utilisation).")
    if crit:
        summary += " Recommended: expire old images using bpexpdate, expand pool capacity, or add media servers."

    th = {"padding":"6px 10px","fontSize":"10px","textTransform":"uppercase",
          "letterSpacing":"0.4px","fontWeight":"500","color":"#64748b",
          "background":"#f8fafc","borderBottom":"0.5px solid #e2e8f0"}
    thr = {**th,"textAlign":"right"}
    thc = {**th,"textAlign":"center"}

    tbl_rows = []
    for srv_n, pool, used, total, pct, health, status in rows_db:
        hc = "#A32D2D" if health=='CRITICAL' else "#854F0B" if health=='WARNING' else "#3B6D11"
        sc = "#3B6D11" if status=="Up" else "#A32D2D"
        tbl_rows.append(html.Tr([
            html.Td(srv_n.replace("cbkms",""),
                    style={"padding":"6px 10px","fontFamily":"monospace","fontSize":"10px","fontWeight":"500"}),
            html.Td(pool[:30]+"…" if len(pool)>30 else pool,
                    style={"padding":"6px 10px","fontSize":"10px","color":"#64748b"}),
            html.Td(f"{used} TB",style={"padding":"6px 10px","textAlign":"right","fontWeight":"500"}),
            html.Td(f"{total} TB",style={"padding":"6px 10px","textAlign":"right","color":"#64748b"}),
            html.Td(f"{pct}%",
                    style={"padding":"6px 10px","textAlign":"right","fontWeight":"500","color":hc}),
            html.Td(health,style={"padding":"6px 10px","textAlign":"center","color":hc,"fontWeight":"500"}),
            html.Td(status,style={"padding":"6px 10px","textAlign":"center","color":sc,"fontWeight":"500"}),
        ], style={"borderBottom":"0.5px solid #f1f5f9",
                  "background":"#FCEBEB" if health=='CRITICAL' else
                               "#FAEEDA" if health=='WARNING' else "#fff"}))

    return html.Div([
        html.Div([
            html.Span("💽 ", style={"fontSize":"13px","marginRight":"7px"}),
            html.Span(f"Disk pools — {srv.upper()}",
                      style={"fontSize":"12px","fontWeight":"500"}),
        ], style={"display":"flex","alignItems":"center","marginBottom":"10px"}),
        html.Div(summary, style={"fontSize":"11px","color":"#64748b",
                                  "marginBottom":"10px","lineHeight":"1.5"}),
        html.Table([
            html.Thead(html.Tr([
                html.Th("Server",style=th),
                html.Th("Pool",style=th),
                html.Th("Used TB",style=thr),
                html.Th("Total TB",style=thr),
                html.Th("% Used",style=thr),
                html.Th("Health",style=thc),
                html.Th("Status",style=thc),
            ])),
            html.Tbody(tbl_rows),
        ], style={"width":"100%","borderCollapse":"collapse",
                  "border":"0.5px solid #e2e8f0","borderRadius":"8px","overflow":"hidden"}),
    ])

def ans_srv_catalog(srv):
    df=qdf(DB_CATALOG,f"SELECT timestamp,catalog_date,catalog_status,health_score,anomaly_detected,anomaly_reason FROM health_records WHERE server='{srv}' ORDER BY timestamp DESC LIMIT 1")
    if df.empty: return f"📋 No catalog data for '{srv}'."
    r=df.iloc[0]; s=r["health_score"]
    return html.Div([resp_header("📋",f"Catalog health — {srv.upper()}",f"checked: {str(r['timestamp'])[:19]}"),
        html.Div([html.Div([html.Div("Status",style={"fontSize":"9px","color":"#888"}),html.Div(pill(r["catalog_status"],_status_color(r["catalog_status"])),style={"marginTop":"4px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
            html.Div([html.Div("Health score",style={"fontSize":"9px","color":"#888"}),html.Div(mini_bar(s),style={"marginTop":"6px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"2"}),
            html.Div([html.Div("Catalog date",style={"fontSize":"9px","color":"#888"}),html.Div(str(r["catalog_date"])[:10],style={"fontSize":"12px","fontWeight":"500","marginTop":"4px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
            html.Div([html.Div("Anomaly",style={"fontSize":"9px","color":"#888"}),html.Div(pill("Yes","danger") if r.get("anomaly_detected") else pill("No","secondary"),style={"marginTop":"4px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
        ],style={"display":"flex","gap":"8px"})])

def ans_srv_airgap(srv):
    rep=qdf(DB_AIRGAP,f"SELECT timestamp,image_count,status,air_master FROM replication_status WHERE server='{srv}' ORDER BY timestamp DESC LIMIT 1")
    if rep.empty: return f"🔄 No airgap data for '{srv}'."
    r=rep.iloc[0]; st=r["status"]
    ret=qdf(DB_AIRGAP,f"SELECT weekly_backups,monthly_backups,yearly_backups,weekly_compliant,monthly_compliant,yearly_compliant FROM retention_compliance WHERE server='{srv}' ORDER BY timestamp DESC LIMIT 1")
    ret_part=html.Span()
    if not ret.empty:
        rv=ret.iloc[0]
        ret_part=html.Div([html.Div("Retention compliance",style={"fontSize":"10px","fontWeight":"500","color":"#555","marginBottom":"6px","marginTop":"10px"}),
            html.Div([html.Div([html.Div("Weekly",style={"fontSize":"9px","color":"#888"}),html.Span(f"{'✓' if rv['weekly_compliant'] else '✗'} {int(rv['weekly_backups'])}",style={"fontSize":"13px","fontWeight":"500","color":"#639922" if rv['weekly_compliant'] else "#E24B4A"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
                html.Div([html.Div("Monthly",style={"fontSize":"9px","color":"#888"}),html.Span(f"{'✓' if rv['monthly_compliant'] else '✗'} {int(rv['monthly_backups'])}",style={"fontSize":"13px","fontWeight":"500","color":"#639922" if rv['monthly_compliant'] else "#E24B4A"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
                html.Div([html.Div("Yearly",style={"fontSize":"9px","color":"#888"}),html.Span(f"{'✓' if rv['yearly_compliant'] else '✗'} {int(rv['yearly_backups'])}",style={"fontSize":"13px","fontWeight":"500","color":"#639922" if rv['yearly_compliant'] else "#E24B4A"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
            ],style={"display":"flex","gap":"8px"})])
    return html.Div([resp_header("🔄",f"Internal Airgap Vault — {srv.upper()}",f"checked: {str(r['timestamp'])[:19]}"),
        html.Div([html.Div([html.Div("Status",style={"fontSize":"9px","color":"#888"}),html.Div(pill(st,"success" if st=="Completed" else "warning" if st=="Working" else "danger"),style={"marginTop":"4px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
            html.Div([html.Div("Backlog",style={"fontSize":"9px","color":"#888"}),html.Div(str(int(r["image_count"])),style={"fontSize":"15px","fontWeight":"500","color":_lag_color(r["image_count"]),"marginTop":"2px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"1"}),
            html.Div([html.Div("Air master",style={"fontSize":"9px","color":"#888"}),html.Div(str(r.get("air_master","—")),style={"fontSize":"11px","fontWeight":"500","marginTop":"4px"})],style={"background":"#f7f8fa","borderRadius":"6px","padding":"8px 10px","flex":"2"}),
        ],style={"display":"flex","gap":"8px"}),ret_part])

def ans_anomaly():
    return html.Div([resp_header("🤖","Anomaly detection"),html.Div("Check the AI Insights tab for the full cross-report event timeline, including disk pool alerts, 3rd-site AI insights, and lag threshold breaches.",style={"fontSize":"11px","color":"#555","lineHeight":"1.6"})])

def ans_summary():
    lt=scalar(DB_LAG,"SELECT SUM(total) FROM lag_history WHERE date=(SELECT MAX(date) FROM lag_history)") or 0
    return html.Div([resp_header("🌐","NBU-CTS Fleet Summary"),resp_kpis([("Lag images",int(lt),"#E24B4A"),("Report dbs",5,BRAND),("Status","Live","#639922")]),html.Div("Use the tabs above for full detail on each report, or ask Vaultix about a specific server.",style={"fontSize":"11px","color":"#888","marginTop":"8px","lineHeight":"1.6"})])

# ── RAG Engine ────────────────────────────────────────────────────────────────
_hybrid_loaded=False; _hybrid_model=None; _hybrid_index=None; _hybrid_bm25=None; _hybrid_meta=None

def _load_hybrid():
    global _hybrid_loaded,_hybrid_model,_hybrid_index,_hybrid_bm25,_hybrid_meta
    if _hybrid_loaded: return True
    try:
        import os,pickle,faiss
        from sentence_transformers import SentenceTransformer
        os.environ['TRANSFORMERS_OFFLINE']='1'; os.environ['HF_HUB_OFFLINE']='1'; os.environ['SENTENCE_TRANSFORMERS_HOME']='/usr/nbu-cts-v2/slm/models'
        with open('/usr/nbu-cts-v2/slm/hybrid_meta.pkl','rb') as f: _hybrid_meta=pickle.load(f)
        with open('/usr/nbu-cts-v2/slm/bm25_index.pkl','rb') as f:  _hybrid_bm25=pickle.load(f)
        _hybrid_index=faiss.read_index('/usr/nbu-cts-v2/slm/faiss_index.bin'); _hybrid_model=SentenceTransformer(_hybrid_meta['model_path'])
        _hybrid_loaded=True; logger.info(f"Hybrid engine loaded: {_hybrid_meta['n_examples']} pairs"); return True
    except Exception as e: logger.warning(f"Hybrid load failed: {e}"); return False

def _intelligent_pool_answer(query, q):
    """Local intelligence for complex pool queries using historical DB data."""
    import sqlite3 as _sq, re as _re
    con = _sq.connect(DB_UNIFIED)

    # Detect temporal modifier
    is_yesterday  = any(k in q for k in ["yesterday","last day","previous day"])
    is_continuous = any(k in q for k in ["continuously","persistent","always down",
                                          "been down","longest","how long","chronic",
                                          "recurring","never up","same pool"])
    is_trend      = any(k in q for k in ["trend","getting worse","improving",
                                          "increasing","decreasing","over time","history"])
    is_compare    = any(k in q for k in ["compare","vs","versus","difference","changed"])
    is_new_down   = any(k in q for k in ["new down","newly down","just went down",
                                          "recently down","went down today"])

    th  = {"padding":"6px 10px","fontSize":"10px","textTransform":"uppercase",
           "letterSpacing":"0.4px","fontWeight":"500","color":"#64748b",
           "background":"#f8fafc","borderBottom":"0.5px solid #e2e8f0"}
    thr = {**th,"textAlign":"right"}
    thc = {**th,"textAlign":"center"}

    try:
        if is_yesterday:
            # Pools down yesterday but not today (recovered) or still down
            dates = con.execute(
                "SELECT DISTINCT run_date FROM diskpool_daily ORDER BY run_date DESC LIMIT 2"
            ).fetchall()
            if len(dates) < 2:
                con.close()
                return None
            today_dt, yest_dt = dates[0][0], dates[1][0]
            yest_down = set(con.execute(
                "SELECT server_name||'|' ||diskpool FROM diskpool_daily "
                "WHERE run_date=? AND status='Down'", (yest_dt,)
            ).fetchall())
            today_down = set(con.execute(
                "SELECT server_name||'|'||diskpool FROM diskpool_daily "
                "WHERE run_date=? AND status='Down'", (today_dt,)
            ).fetchall())
            yest_down = {r[0] for r in yest_down}
            today_down = {r[0] for r in today_down}
            still_down   = yest_down & today_down
            recovered    = yest_down - today_down
            newly_down   = today_down - yest_down

            rows_db = con.execute("""
                SELECT server_name, diskpool, ROUND(used_tb,2), ROUND(total_tb,2),
                       ROUND(pct_used,1), health, status
                FROM diskpool_daily WHERE run_date=? AND status='Down'
                ORDER BY pct_used DESC
            """, (yest_dt,)).fetchall()
            con.close()

            tbl_rows = []
            for srv,pool,used,total,pct,health,status in rows_db:
                key = f"{srv}|{pool}"
                tag = "Still down" if key in still_down else "Recovered ✓"
                tag_c = "#A32D2D" if key in still_down else "#3B6D11"
                hc = "#A32D2D" if health=="CRITICAL" else "#854F0B" if health=="WARNING" else "#3B6D11"
                tbl_rows.append(html.Tr([
                    html.Td(srv.replace("cbkms",""),
                            style={"padding":"6px 10px","fontFamily":"monospace","fontSize":"10px","fontWeight":"500"}),
                    html.Td(pool[:30]+"…" if len(pool)>30 else pool,
                            style={"padding":"6px 10px","fontSize":"10px","color":"#64748b"}),
                    html.Td(f"{pct}%",style={"padding":"6px 10px","textAlign":"right","color":hc,"fontWeight":"500"}),
                    html.Td(tag,style={"padding":"6px 10px","textAlign":"center","color":tag_c,"fontWeight":"500","fontSize":"11px"}),
                ], style={"borderBottom":"0.5px solid #f1f5f9",
                          "background":"#f0fff4" if key in recovered else "#fff0f0"}))

            summary = (f"Yesterday ({yest_dt}): {len(rows_db)} pools were Down. "
                       f"{len(still_down)} still down today, "
                       f"{len(recovered)} recovered, "
                       f"{len(newly_down)} new downs since yesterday.")
            return html.Div([
                html.Div([html.Span("💽 ",style={"fontSize":"13px","marginRight":"7px"}),
                          html.Span(f"Down pools — yesterday ({yest_dt})",style={"fontSize":"12px","fontWeight":"500"})],
                         style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
                html.Div(summary,style={"fontSize":"11px","color":"#64748b","marginBottom":"10px","lineHeight":"1.6"}),
                html.Table([
                    html.Thead(html.Tr([html.Th("Server",style=th),html.Th("Pool",style=th),
                        html.Th("% Used",style=thr),html.Th("Status today",style=thc)])),
                    html.Tbody(tbl_rows or [html.Tr([html.Td("No down pools yesterday.",
                        colSpan=4,style={"padding":"12px","color":"#3B6D11","textAlign":"center"})])]),
                ],style={"width":"100%","borderCollapse":"collapse","border":"0.5px solid #e2e8f0","borderRadius":"8px","overflow":"hidden"}),
            ])

        elif is_continuous or is_new_down:
            # Find consecutive down days per pool
            all_dates = [r[0] for r in con.execute(
                "SELECT DISTINCT run_date FROM diskpool_daily ORDER BY run_date DESC LIMIT 14"
            ).fetchall()]
            latest = all_dates[0] if all_dates else None
            if not latest:
                con.close(); return None

            # For each currently down pool, count how many consecutive days it was down
            cur_down = con.execute("""
                SELECT server_name, diskpool FROM diskpool_daily
                WHERE run_date=? AND status='Down'
                AND diskpool_group != 'Recovery Vault'
            """, (latest,)).fetchall()

            pool_streaks = []
            for srv, pool in cur_down:
                streak = 0
                for dt in all_dates:
                    st = con.execute(
                        "SELECT status FROM diskpool_daily WHERE server_name=? AND diskpool=? AND run_date=?",
                        (srv, pool, dt)).fetchone()
                    if st and st[0] == "Down":
                        streak += 1
                    else:
                        break
                pool_streaks.append((streak, srv, pool))

            pool_streaks.sort(reverse=True)
            con.close()

            if is_new_down:
                new_downs = [(st,srv,pool) for st,srv,pool in pool_streaks if st==1]
                display = new_downs
                lbl = f"Newly down pools — {latest}"
                msg = f"{len(new_downs)} pool(s) went Down today that were Up yesterday."
            else:
                display = pool_streaks
                lbl = f"Persistent down pools — {latest}"
                msg = (f"{len(pool_streaks)} pool(s) currently Down. "
                       f"Longest streak: {pool_streaks[0][0]} days ({pool_streaks[0][2][:25]}) "
                       f"if {pool_streaks} else ''.")

            tbl_rows = []
            for streak, srv, pool in display:
                sc = "#A32D2D" if streak >= 7 else "#854F0B" if streak >= 3 else "#64748b"
                tbl_rows.append(html.Tr([
                    html.Td(srv.replace("cbkms",""),
                            style={"padding":"6px 10px","fontFamily":"monospace","fontSize":"10px","fontWeight":"500"}),
                    html.Td(pool[:30]+"…" if len(pool)>30 else pool,
                            style={"padding":"6px 10px","fontSize":"10px","color":"#64748b"}),
                    html.Td(f"{streak} day{'s' if streak!=1 else ''}",
                            style={"padding":"6px 10px","textAlign":"center","fontWeight":"500","color":sc}),
                    html.Td("🔴 Critical" if streak>=7 else "🟠 Attention" if streak>=3 else "🟡 Recent",
                            style={"padding":"6px 10px","textAlign":"center","fontSize":"11px"}),
                ], style={"borderBottom":"0.5px solid #f1f5f9",
                          "background":"#FCEBEB" if streak>=7 else "#FAEEDA" if streak>=3 else "#fff"}))

            return html.Div([
                html.Div([html.Span("💽 ",style={"fontSize":"13px","marginRight":"7px"}),
                          html.Span(lbl,style={"fontSize":"12px","fontWeight":"500"})],
                         style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
                html.Div(msg,style={"fontSize":"11px","color":"#64748b","marginBottom":"10px","lineHeight":"1.6"}),
                html.Table([
                    html.Thead(html.Tr([html.Th("Server",style=th),html.Th("Pool",style=th),
                        html.Th("Down streak",style=thc),html.Th("Priority",style=thc)])),
                    html.Tbody(tbl_rows or [html.Tr([html.Td(
                        "No pools match." ,colSpan=4,
                        style={"padding":"12px","color":"#94a3b8","textAlign":"center"})])]),
                ],style={"width":"100%","borderCollapse":"collapse","border":"0.5px solid #e2e8f0","borderRadius":"8px","overflow":"hidden"}),
            ])

        elif is_trend:
            # Show down pool trend over last 7 days
            trend = con.execute("""
                SELECT run_date,
                       SUM(CASE WHEN status='Down' THEN 1 ELSE 0 END) as down_cnt,
                       SUM(CASE WHEN health='CRITICAL' THEN 1 ELSE 0 END) as crit_cnt,
                       COUNT(*) as total_pools
                FROM diskpool_daily
                WHERE run_date >= date('now','-7 days')
                AND diskpool_group != 'Recovery Vault'
                GROUP BY run_date ORDER BY run_date DESC
            """).fetchall()
            con.close()
            if not trend: return None

            tbl_rows = []
            prev_down = None
            for dt, down, crit, total in trend:
                delta = ""
                if prev_down is not None:
                    diff = down - prev_down
                    delta = f"{'↑' if diff>0 else '↓' if diff<0 else '→'} {abs(diff)}"
                    delta_c = "#A32D2D" if diff>0 else "#3B6D11" if diff<0 else "#64748b"
                else:
                    delta_c = "#64748b"
                prev_down = down
                tbl_rows.append(html.Tr([
                    html.Td(dt,style={"padding":"6px 10px","fontSize":"10px","fontWeight":"500"}),
                    html.Td(str(total),style={"padding":"6px 10px","textAlign":"right","color":"#64748b"}),
                    html.Td(str(down),style={"padding":"6px 10px","textAlign":"right",
                                              "color":"#A32D2D" if down>5 else "#334155","fontWeight":"500"}),
                    html.Td(str(crit),style={"padding":"6px 10px","textAlign":"right",
                                              "color":"#A32D2D" if crit>0 else "#334155"}),
                    html.Td(delta,style={"padding":"6px 10px","textAlign":"center",
                                          "color":delta_c,"fontWeight":"500"}),
                ],style={"borderBottom":"0.5px solid #f1f5f9"}))

            first_down = trend[-1][1]; last_down = trend[0][1]
            trend_dir = "worsening ↑" if last_down > first_down else "improving ↓" if last_down < first_down else "stable →"
            return html.Div([
                html.Div([html.Span("💽 ",style={"fontSize":"13px","marginRight":"7px"}),
                          html.Span("Storage pool health trend — 7 days",style={"fontSize":"12px","fontWeight":"500"})],
                         style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
                html.Div(f"Trend is {trend_dir}. Started at {first_down} down pools, currently {last_down}.",
                         style={"fontSize":"11px","color":"#64748b","marginBottom":"10px"}),
                html.Table([
                    html.Thead(html.Tr([html.Th("Date",style=th),html.Th("Total",style=thr),
                        html.Th("Down",style=thr),html.Th("Critical",style=thr),html.Th("Change",style=thc)])),
                    html.Tbody(tbl_rows),
                ],style={"width":"100%","borderCollapse":"collapse","border":"0.5px solid #e2e8f0","borderRadius":"8px","overflow":"hidden"}),
            ])

    except Exception as _e:
        logger.debug(f"_intelligent_pool_answer: {_e}")
        try: con.close()
        except: pass

    return None


# ── MCP Tool imports (direct call, no network) ───────────────────────────────
def _mcp_tools_available():
    """Check if MCP tools are importable."""
    try:
        import sys as _s
        if '/usr/nbu-cts-v2' not in _s.path:
            _s.path.insert(0, '/usr/nbu-cts-v2')
        from nbu_mcp_server import (get_fleet_summary, get_lag_status,
            get_diskpool_status, get_vault_status, get_airgap_status,
            get_catalog_health, get_media_servers, get_lag_trend)
        return True
    except Exception:
        return False

_MCP_AVAILABLE = _mcp_tools_available()
logger.info(f"MCP tools available for Vaultix: {_MCP_AVAILABLE}")

def _mcp_answer(query, q, intent, server_filter, label):
    """Use MCP tools directly to answer Vaultix queries with rich intelligence."""
    if not _MCP_AVAILABLE:
        return None
    try:
        import sys as _s, json as _js
        if '/usr/nbu-cts-v2' not in _s.path:
            _s.path.insert(0, '/usr/nbu-cts-v2')
        from nbu_mcp_server import (get_fleet_summary, get_lag_status,
            get_diskpool_status, get_vault_status, get_airgap_status,
            get_catalog_health, get_media_servers, get_lag_trend)

        # ── Detect what data to fetch ──────────────────────────────────────
        srv = server_filter[0] if len(server_filter)==1 else "all"
        if len(server_filter) > 1:
            srv = label or "all"

        # Temporal modifiers
        days = 14
        import re as _re
        dm = _re.search(r'last\s+(\d+)\s+day', q)
        if dm: days = int(dm.group(1))
        elif "last week" in q: days = 7
        elif "last month" in q or "30 day" in q: days = 30

        # ── Fetch relevant data ────────────────────────────────────────────
        data = {}
        if intent in ("lag","rag_fallback","summary") or any(k in q for k in
            ["queue","backlog","lag","dup","duplication","image","pending"]):
            if "trend" in q or "history" in q or "last" in q or days != 14:
                data["lag_trend"] = _js.loads(get_lag_trend(server=srv, days=days))
            else:
                data["lag"] = _js.loads(get_lag_status(server=srv))

        if intent in ("diskpool","rag_fallback") or any(k in q for k in
            ["pool","disk","storage","capacity","down pool","critical pool"]):
            filt = "all"
            if any(k in q for k in ["down","offline"]): filt = "down"
            elif any(k in q for k in ["critical","85%","above 85"]): filt = "critical"
            elif any(k in q for k in ["warning","70%","above 70"]): filt = "warning"
            data["diskpool"] = _js.loads(get_diskpool_status(server=srv, filter=filt))

        if intent in ("3rdsite","rag_fallback") or any(k in q for k in
            ["vault","3rd site","airgap vault","external","dedup","worm","vaulted"]):
            data["vault"] = _js.loads(get_vault_status(server=srv))

        if intent in ("airgap","rag_fallback") or any(k in q for k in
            ["internal airgap","replication","air gap","slp","retention"]):
            data["airgap"] = _js.loads(get_airgap_status(server=srv))

        if intent in ("catalog","rag_fallback") or any(k in q for k in
            ["catalog","health score","bhi","catalog backup"]):
            data["catalog"] = _js.loads(get_catalog_health(server=srv))

        if intent in ("media","rag_fallback") or any(k in q for k in
            ["media server","high load","anomaly","media"]):
            st = "all"
            if "high load" in q or "high_load" in q: st = "HIGH_LOAD"
            elif "anomaly" in q: st = "ANOMALY"
            elif "balanced" in q: st = "BALANCED"
            data["media"] = _js.loads(get_media_servers(master=srv, status=st))

        # Always include fleet summary for context
        if not data or intent in ("summary","fleet","rag_fallback"):
            data["fleet"] = _js.loads(get_fleet_summary())

        if not data:
            return None

        # ── Build intelligent response ─────────────────────────────────────
        return _render_mcp_response(query, q, intent, data, srv, days)

    except Exception as e:
        logger.warning(f"MCP answer error: {e}")
        return None


def _render_mcp_response(query, q, intent, data, server, days):
    """Render MCP tool data into a rich Dash component response."""
    import json as _js

    th  = {"padding":"6px 10px","fontSize":"10px","textTransform":"uppercase",
           "letterSpacing":"0.4px","fontWeight":"500","color":"#64748b",
           "background":"#f8fafc","borderBottom":"0.5px solid #e2e8f0"}
    thr = {**th, "textAlign":"right"}
    thc = {**th, "textAlign":"center"}

    def _pill(txt, color="#185FA5", bg="#E6F1FB"):
        return html.Span(txt, style={"fontSize":"10px","fontWeight":"500",
            "padding":"2px 8px","borderRadius":"20px",
            "background":bg,"color":color,"whiteSpace":"nowrap"})

    def _status_pill(status):
        m = {"CRITICAL":("#A32D2D","#FCEBEB"),"WARNING":("#854F0B","#FAEEDA"),
             "OK":("#3B6D11","#EAF3DE"),"ERROR":("#A32D2D","#FCEBEB"),
             "Working":("#854F0B","#FAEEDA"),"Completed":("#3B6D11","#EAF3DE"),
             "Not Working":("#A32D2D","#FCEBEB"),"Down":("#A32D2D","#FCEBEB"),
             "HIGH_LOAD":("#A32D2D","#FCEBEB"),"ANOMALY":("#854F0B","#FAEEDA"),
             "BALANCED":("#185FA5","#E6F1FB")}
        c,bg = m.get(status,("#475569","#f8fafc"))
        return _pill(status,c,bg)

    def _tbl(headers, rows_data, col_rights=None):
        col_rights = col_rights or []
        thead = html.Thead(html.Tr([
            html.Th(h, style={**thr} if i in col_rights else {**th})
            for i,h in enumerate(headers)
        ]))
        tbody = html.Tbody(rows_data)
        return html.Table([thead, tbody],
            style={"width":"100%","borderCollapse":"collapse",
                   "border":"0.5px solid #e2e8f0","borderRadius":"8px",
                   "overflow":"hidden","marginTop":"8px"})

    def _kpi_row(items):
        cells = []
        for lbl,val,color in items:
            cells.append(html.Div([
                html.Div(str(val), style={"fontSize":"20px","fontWeight":"500",
                                           "color":color,"lineHeight":"1"}),
                html.Div(lbl, style={"fontSize":"10px","color":"#94a3b8",
                                      "textTransform":"uppercase","letterSpacing":"0.4px",
                                      "marginTop":"4px"}),
            ], style={"background":"#f8fafc","borderRadius":"8px","padding":"10px 12px",
                      "flex":"1","textAlign":"center"}))
        return html.Div(cells, style={"display":"flex","gap":"8px","marginBottom":"12px"})

    sections = []

    # ── Fleet summary ──────────────────────────────────────────────────────
    if "fleet" in data:
        f = data["fleet"]
        dq = f.get("duplication_queue",{})
        sp = f.get("storage_pools",{})
        rv = f.get("recovery_vault",{})
        ag = f.get("airgap",{})
        ct = f.get("catalog",{})
        ms = f.get("media_servers",{})

        def _st_col(st):
            return "#A32D2D" if st=="CRITICAL" else "#854F0B" if st=="WARNING" else "#3B6D11"

        sections.append(html.Div([
            html.Div("Fleet health summary",
                     style={"fontSize":"12px","fontWeight":"500","marginBottom":"10px"}),
            _kpi_row([
                ("Dup queue", f"{int(dq.get('fleet_total',0)):,}",
                 _st_col(dq.get("status","OK"))),
                ("Pools down", sp.get("down",0),
                 _st_col(sp.get("status","OK"))),
                (f"Vault {rv.get('pct',0)}%", f"{rv.get('used_tb',0)} TB",
                 _st_col(rv.get("status","OK"))),
                ("Airgap down", ag.get("not_working",0),
                 _st_col(ag.get("status","OK"))),
                ("Catalog errors", ct.get("errors",0),
                 _st_col(ct.get("status","OK"))),
                ("Media HL", ms.get("high_load",0),
                 _st_col(ms.get("status","OK"))),
            ]),
            html.Div(f"Generated: {f.get('generated_at','')} · "
                     f"{len(f.get('fleet',{}).get('servers',[]))} master servers",
                     style={"fontSize":"10px","color":"#94a3b8"}),
        ]))

    # ── Lag / trend ────────────────────────────────────────────────────────
    if "lag" in data:
        d = data["lag"]
        rows_list = d.get("data",[])
        tbl_rows = []
        for r in rows_list:
            tot = int(r.get("total") or 0)
            dlt = r.get("delta_1d") or 0
            tbl_rows.append(html.Tr([
                html.Td(str(r.get("server_name","")).replace("cbkms",""),
                        style={**th,"fontFamily":"monospace","fontWeight":"500"}),
                html.Td(f"{tot:,}",
                        style={**thr,"color":"#A32D2D" if tot>10000 else
                               "#854F0B" if tot>1000 else "#3B6D11",
                               "fontWeight":"500"}),
                html.Td(f"{int(r.get('above_sla') or 0):,}", style=thr),
                html.Td(f"{int(r.get('not_started_duplicate') or 0):,}", style=thr),
                html.Td(f"{'+' if dlt>=0 else ''}{int(dlt):,}" if dlt else "—",
                        style={**thr,"color":"#A32D2D" if int(dlt or 0)>0 else
                               "#3B6D11" if int(dlt or 0)<0 else "#64748b"}),
            ], style={"borderBottom":"0.5px solid #f1f5f9",
                      "background":"#FCEBEB" if tot>30000 else
                                   "#FAEEDA" if tot>10000 else "#fff"}))
        sections.append(html.Div([
            html.Div([
                html.Span("📉 ", style={"marginRight":"6px"}),
                html.Span(f"Duplication queue — "
                          f"{'fleet' if server=='all' else server.replace('cbkms','')}",
                          style={"fontSize":"12px","fontWeight":"500"}),
                html.Span(f" · fleet total: {d.get('fleet_total',0):,}",
                          style={"fontSize":"11px","color":"#94a3b8","marginLeft":"6px"}),
            ], style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
            _tbl(["Server","Queue","Above SLA","Not started","Δ 1d"],
                 tbl_rows, col_rights=[1,2,3,4]),
        ]))

    if "lag_trend" in data:
        d = data["lag_trend"]
        trend_rows = d.get("data",[])
        tbl_rows = []
        for r in trend_rows:
            tot = int(r.get("fleet_total") or r.get("total") or 0)
            tbl_rows.append(html.Tr([
                html.Td(str(r.get("date","")),
                        style={**th,"fontWeight":"500"}),
                html.Td(f"{tot:,}",
                        style={**thr,"color":"#A32D2D" if tot>50000 else
                               "#854F0B" if tot>20000 else "#3B6D11",
                               "fontWeight":"500"}),
                html.Td(str(r.get("servers","—")), style=thr),
            ], style={"borderBottom":"0.5px solid #f1f5f9"}))
        # Trend direction
        if len(trend_rows) >= 2:
            first = int(trend_rows[-1].get("fleet_total") or trend_rows[-1].get("total") or 0)
            last  = int(trend_rows[0].get("fleet_total")  or trend_rows[0].get("total")  or 0)
            delta = last - first
            trend_lbl = f"↑ +{delta:,} worsening" if delta>1000 else                         f"↓ {delta:,} improving" if delta<-1000 else "→ stable"
            trend_color = "#A32D2D" if delta>1000 else "#3B6D11" if delta<-1000 else "#64748b"
        else:
            trend_lbl, trend_color = "—", "#64748b"
        sections.append(html.Div([
            html.Div([
                html.Span("📉 "),
                html.Span(f"Duplication queue trend — last {days} days",
                          style={"fontSize":"12px","fontWeight":"500"}),
                html.Span(f" · {trend_lbl}",
                          style={"fontSize":"11px","color":trend_color,"marginLeft":"6px"}),
            ], style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
            _tbl(["Date","Fleet total","Servers"], tbl_rows, col_rights=[1,2]),
        ]))

    # ── Diskpool ───────────────────────────────────────────────────────────
    if "diskpool" in data:
        d = data["diskpool"]
        pools = d.get("data",[])
        tbl_rows = []
        for r in pools[:30]:
            pct = float(r.get("pct_used") or 0)
            hc = "#A32D2D" if r.get("health")=="CRITICAL" else                  "#854F0B" if r.get("health")=="WARNING" else "#3B6D11"
            sc = "#A32D2D" if r.get("status")=="Down" else "#3B6D11"
            tbl_rows.append(html.Tr([
                html.Td(str(r.get("server_name","")).replace("cbkms",""),
                        style={**th,"fontFamily":"monospace","fontWeight":"500"}),
                html.Td(str(r.get("diskpool",""))[:28]+"…" if len(str(r.get("diskpool","")))>28
                        else str(r.get("diskpool","")),
                        style={**th,"color":"#64748b"}),
                html.Td(f"{r.get('used_tb',0)} TB", style=thr),
                html.Td(f"{r.get('total_tb',0)} TB", style=thr),
                html.Td(f"{pct}%", style={**thr,"color":hc,"fontWeight":"500"}),
                html.Td(str(r.get("health","")),
                        style={**thc,"color":hc,"fontWeight":"500"}),
                html.Td(str(r.get("status","")),
                        style={**thc,"color":sc,"fontWeight":"500"}),
            ], style={"borderBottom":"0.5px solid #f1f5f9",
                      "background":"#FCEBEB" if r.get("health")=="CRITICAL" else
                                   "#FAEEDA" if r.get("health")=="WARNING" else
                                   "#fff0f0" if r.get("status")=="Down" else "#fff"}))
        sections.append(html.Div([
            html.Div([
                html.Span("💽 "),
                html.Span(f"Storage pools — "
                          f"{'fleet' if server=='all' else server.replace('cbkms','')}",
                          style={"fontSize":"12px","fontWeight":"500"}),
                html.Span(f" · {d.get('total',0)} pools · "
                          f"{d.get('down',0)} down · {d.get('critical',0)} critical",
                          style={"fontSize":"11px","color":"#94a3b8","marginLeft":"6px"}),
            ], style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
            _tbl(["Server","Pool","Used TB","Total TB","% Used","Health","Status"],
                 tbl_rows, col_rights=[2,3,4]),
        ]))

    # ── Vault (3rd site) ───────────────────────────────────────────────────
    if "vault" in data:
        d = data["vault"]
        servers = d.get("servers",[])
        tbl_rows = []
        for r in servers:
            dedup = float(r.get("dedup",0) or 0)
            worm  = int(r.get("max_worm_days",0) or 0)
            tbl_rows.append(html.Tr([
                html.Td(str(r.get("server_name","")).replace("cbkms",""),
                        style={**th,"fontFamily":"monospace","fontWeight":"500"}),
                html.Td(f"{r.get('tb',0)} TB", style=thr),
                html.Td(f"{dedup}%",
                        style={**thr,"color":"#A32D2D" if dedup<70 else
                               "#854F0B" if dedup<80 else "#3B6D11","fontWeight":"500"}),
                html.Td(f"{r.get('avg_gbps',0)} GB/s", style=thr),
                html.Td(f"{worm}d",
                        style={**thr,"color":"#A32D2D" if worm<30 else "#3B6D11"}),
            ], style={"borderBottom":"0.5px solid #f1f5f9",
                      "background":"#FAEEDA" if dedup<80 else "#fff"}))
        rv_pct = d.get("vault_pct",0)
        sections.append(html.Div([
            html.Div([
                html.Span("🌐 "),
                html.Span("External Airgap Vault",
                          style={"fontSize":"12px","fontWeight":"500"}),
                html.Span(f" · {d.get('vault_tb',0)} TB / 910 TB ({rv_pct}%)",
                          style={"fontSize":"11px","color":"#94a3b8","marginLeft":"6px"}),
                _status_pill("CRITICAL" if rv_pct>90 else "WARNING" if rv_pct>70 else "OK"),
            ], style={"display":"flex","alignItems":"center","gap":"6px","marginBottom":"8px"}),
            _tbl(["Server","Vaulted TB","Dedup %","Avg GB/s","WORM days"],
                 tbl_rows, col_rights=[1,2,3,4]),
        ]))

    # ── Airgap ────────────────────────────────────────────────────────────
    if "airgap" in data:
        d = data["airgap"]
        servers = d.get("data",[])
        tbl_rows = []
        for r in servers:
            st = str(r.get("ag_status",""))
            sc = "#A32D2D" if st=="Not Working" else "#3B6D11"
            tbl_rows.append(html.Tr([
                html.Td(str(r.get("server_name","")).replace("cbkms",""),
                        style={**th,"fontFamily":"monospace","fontWeight":"500"}),
                html.Td(st, style={**thc,"color":sc,"fontWeight":"500"}),
                html.Td("Yes" if r.get("ag_repl_active") else "No",
                        style={**thc,"color":"#3B6D11" if r.get("ag_repl_active") else "#A32D2D"}),
                html.Td("✓" if r.get("ag_weekly_ok") else "✗",
                        style={**thc,"color":"#3B6D11" if r.get("ag_weekly_ok") else "#A32D2D"}),
                html.Td("✓" if r.get("ag_monthly_ok") else "✗",
                        style={**thc,"color":"#3B6D11" if r.get("ag_monthly_ok") else "#A32D2D"}),
            ], style={"borderBottom":"0.5px solid #f1f5f9",
                      "background":"#FCEBEB" if st=="Not Working" else "#fff"}))
        sections.append(html.Div([
            html.Div([
                html.Span("🔒 "),
                html.Span("Internal Airgap Vault",
                          style={"fontSize":"12px","fontWeight":"500"}),
                html.Span(f" · {d.get('not_working',0)} not working",
                          style={"fontSize":"11px",
                                 "color":"#A32D2D" if d.get("not_working",0)>0 else "#94a3b8",
                                 "marginLeft":"6px"}),
            ], style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
            _tbl(["Server","Status","Repl active","Weekly","Monthly"],
                 tbl_rows, col_rights=[]),
        ]))

    # ── Catalog ───────────────────────────────────────────────────────────
    if "catalog" in data:
        d = data["catalog"]
        servers = d.get("data",[])
        tbl_rows = []
        for r in servers:
            st = str(r.get("cat_status",""))
            sc = float(r.get("cat_health_score") or 0)
            tbl_rows.append(html.Tr([
                html.Td(str(r.get("server_name","")).replace("cbkms",""),
                        style={**th,"fontFamily":"monospace","fontWeight":"500"}),
                html.Td(st, style={**thc,
                        "color":"#A32D2D" if st=="ERROR" else "#3B6D11",
                        "fontWeight":"500"}),
                html.Td(f"{sc:.0f}/100",
                        style={**thr,"color":"#A32D2D" if sc<50 else
                               "#854F0B" if sc<80 else "#3B6D11"}),
                html.Td(str(r.get("cat_anomaly_reason","—") or "—"),
                        style={**th,"color":"#64748b","fontSize":"10px"}),
            ], style={"borderBottom":"0.5px solid #f1f5f9",
                      "background":"#FCEBEB" if st=="ERROR" else "#fff"}))
        sections.append(html.Div([
            html.Div([
                html.Span("📋 "),
                html.Span("Catalog health",
                          style={"fontSize":"12px","fontWeight":"500"}),
                html.Span(f" · {d.get('errors',0)} errors",
                          style={"fontSize":"11px",
                                 "color":"#A32D2D" if d.get("errors",0)>0 else "#94a3b8",
                                 "marginLeft":"6px"}),
            ], style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
            _tbl(["Server","Status","Health score","Anomaly reason"],
                 tbl_rows, col_rights=[2]),
        ]))

    # ── Media servers ──────────────────────────────────────────────────────
    if "media" in data:
        d = data["media"]
        servers = d.get("data",[])
        tbl_rows = []
        for r in servers[:20]:
            st = str(r.get("ai_status",""))
            st_col = {"HIGH_LOAD":"#A32D2D","ANOMALY":"#854F0B",
                      "BALANCED":"#185FA5","UNDERUTILIZED":"#3B6D11"}.get(st,"#64748b")
            st_bg  = {"HIGH_LOAD":"#FCEBEB","ANOMALY":"#FAEEDA",
                      "BALANCED":"#E6F1FB","UNDERUTILIZED":"#EAF3DE"}.get(st,"#f8fafc")
            ac = int(r.get("active_jobs") or 0)
            tbl_rows.append(html.Tr([
                html.Td(str(r.get("master_name","")).replace("cbkms",""),
                        style={**th,"fontFamily":"monospace","color":"#64748b"}),
                html.Td(str(r.get("media_server","")).split(".")[0],
                        style={**th,"fontWeight":"500"}),
                html.Td(str(ac),
                        style={**thr,"color":"#A32D2D" if ac>40 else "#334155",
                               "fontWeight":"500" if ac>40 else "400"}),
                html.Td(f"{int(r.get('total_jobs') or 0):,}", style=thr),
                html.Td(f"{float(r.get('data_tb') or 0):.2f}", style=thr),
                html.Td(html.Span(st.replace("_"," "),
                        style={"fontSize":"10px","fontWeight":"500","padding":"2px 7px",
                               "borderRadius":"20px","background":st_bg,"color":st_col}),
                        style=th),
            ], style={"borderBottom":"0.5px solid #f1f5f9",
                      "background":"#FCEBEB" if st=="HIGH_LOAD" else
                                   "#FAEEDA" if st=="ANOMALY" else "#fff"}))
        sections.append(html.Div([
            html.Div([
                html.Span("🖥️ "),
                html.Span("Media servers",
                          style={"fontSize":"12px","fontWeight":"500"}),
                html.Span(f" · {d.get('total',0)} servers · "
                          f"{d.get('high_load',0)} HIGH_LOAD · "
                          f"{d.get('anomaly',0)} ANOMALY",
                          style={"fontSize":"11px","color":"#94a3b8","marginLeft":"6px"}),
            ], style={"display":"flex","alignItems":"center","marginBottom":"8px"}),
            _tbl(["Master","Server","Active","Jobs","Data TB","Status"],
                 tbl_rows, col_rights=[2,3,4]),
        ]))

    if not sections:
        return None

    return html.Div([
        html.Div([
            html.Span("🤖 ", style={"fontSize":"13px","marginRight":"6px"}),
            html.Span("Vaultix Intelligence",
                      style={"fontSize":"12px","fontWeight":"500","color":"#1e3a5f"}),
            html.Span(" · live fleet data",
                      style={"fontSize":"10px","color":"#94a3b8","marginLeft":"6px"}),
        ], style={"display":"flex","alignItems":"center","marginBottom":"12px"}),
        html.Div(sections, style={"display":"flex","flexDirection":"column","gap":"14px"}),
    ])


def rag_fallback(query):
    # Try intelligence modules first for better answers
    if _INTELLIGENCE_LOADED:
        try:
            from vaultix_agent import (resolve_server, get_all_servers,
                                        build_server_narrative)
            servers = get_all_servers()
            resolved = resolve_server(query.lower(), servers)
            if resolved and len(resolved) == 1:
                narrative = build_server_narrative(resolved[0])
                if narrative and "healthy" in narrative.lower() or                    "issue" in narrative.lower() or "breach" in narrative.lower():
                    return html.Div([
                        html.Div("🧠 Vaultix Cross-Report Analysis",
                            style={"fontSize":"10px","color":"#888",
                                   "marginBottom":"6px","fontWeight":"500"}),
                        html.Div(narrative,
                            style={"fontSize":"11px","color":"#333",
                                   "lineHeight":"1.8","padding":"10px 13px",
                                   "background":"#f0f4fa","borderRadius":"6px",
                                   "borderLeft":f"3px solid {BRAND}"})
                    ])
        except Exception:
            pass
    if not _load_hybrid(): return _rag_fallback_tfidf(query)
    try:
        import numpy as np
        corpus=_hybrid_meta['corpus']; dw,sw=_hybrid_meta.get('dense_weight',0.6),_hybrid_meta.get('sparse_weight',0.4)
        thresh,top_k=_hybrid_meta.get('threshold',0.15),_hybrid_meta.get('top_k',3)
        q_vec=_hybrid_model.encode([query],normalize_embeddings=True,convert_to_numpy=True).astype('float32')
        D,I=_hybrid_index.search(q_vec,min(top_k*5,50))
        dense={int(I[0][i]):float(D[0][i]) for i in range(len(I[0])) if I[0][i]>=0}
        tokens=query.lower().split(); bm25_raw=_hybrid_bm25.get_scores(tokens)
        bm25_max=float(bm25_raw.max()) if bm25_raw.max()>0 else 1.0; bm25_n=bm25_raw/bm25_max
        combined={}
        for idx,ds in dense.items(): combined[idx]=dw*ds+sw*float(bm25_n[idx])
        for idx in bm25_raw.argsort()[::-1][:top_k*3]:
            if idx not in combined: combined[idx]=sw*float(bm25_n[idx])
        ranked=sorted(combined.items(),key=lambda x:-x[1]); seen,hits=[],[]  # noqa
        seen_set=set()
        for idx,score in ranked:
            if score<thresh: continue
            chunk=corpus[idx]; cid=chunk.get('chunk_id') or chunk.get('answer','')[:40]
            if cid in seen_set: continue
            seen_set.add(cid); hits.append((score,chunk))
            if len(hits)>=top_k: break
        if not hits: return _rag_fallback_tfidf(query)
        lines=[]
        for _,(score,chunk) in enumerate(hits,1):
            rtype=chunk.get('report_type','general'); sev=chunk.get('severity','info'); server=chunk.get('server_name',''); date=chunk.get('date','')
            tag=f"[{rtype}]"+(f" {server}" if server else "")+(f" {date}" if date not in('static','latest','') else "")
            icons={'critical':'🔴','warning':'🟡','healthy':'🟢'}; icon=icons.get(sev,'🔷')
            ans=chunk['answer'][:350]; dots='…' if len(chunk['answer'])>350 else ''
            lines.append(f"{icon} {tag}  (score: {round(score,2)})\n{ans}{dots}")
        logger.info(f"Hybrid: query={repr(query[:40])} hits={len(hits)}")
        return "🧠 Vaultix:\n\n"+"\n\n─────\n\n".join(lines)
    except Exception as e: logger.error(f"Hybrid retrieval error: {e}"); return _rag_fallback_tfidf(query)

def _rag_fallback_tfidf(query):
    rag=Path('/usr/nbu-cts-v2/slm/rag_index.pkl'); vec=Path('/usr/nbu-cts-v2/slm/tfidf_vectorizer.pkl')
    if not rag.exists(): return "🤔 No intent matched. Try: lag above SLA, diskpool for <server>, airgap backlog"
    try:
        import pickle
        from sklearn.metrics.pairwise import cosine_similarity
        with open(rag,'rb') as f: model=pickle.load(f)
        with open(vec,'rb') as f: v=pickle.load(f)
        scores=cosine_similarity(v.transform([query]),model['matrix'])[0]
        hits=[(i,scores[i]) for i in scores.argsort()[::-1][:3] if scores[i]>0.15]
        if not hits: return "🤔 No close match found."
        return "🧠 SLM matches:\n\n"+"\n\n".join([f"[{n+1}] {model['corpus'][i]['answer'][:200]}" for n,(i,_) in enumerate(hits)])
    except Exception as e: logger.error(f"TF-IDF fallback: {e}"); return f"⚠️ RAG error: {e}"


# ══════════════════════════════════════════════════════════════════════════════
# APP LAYOUT
# ══════════════════════════════════════════════════════════════════════════════
app=dash.Dash(__name__,external_stylesheets=["/assets/bootstrap.min.css"],title="NBU-CTS Dashboard",suppress_callback_exceptions=True)

app.index_string='''
<!DOCTYPE html>
<html>
<head>
{%metas%}
<title>{%title%}</title>
{%favicon%}
{%css%}
<style>
  body { background: #f5f6f8; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
  .nav-tabs .nav-link { font-size: 12px; color: #555; padding: 8px 16px; border: none; border-bottom: 2px solid transparent; background: transparent; }
  .nav-tabs .nav-link.active { color: #1a3c5e; border-bottom-color: #1a3c5e; font-weight: 500; background: transparent; }
  .nav-tabs { border-bottom: 0.5px solid #e0e0e0; }
  .tab-content { background: #fff; border: 0.5px solid #e0e0e0; border-top: none; border-radius: 0 0 8px 8px; }
  .card { border: 0.5px solid #e0e0e0 !important; box-shadow: none !important; }
  .modebar { display: none !important; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
</style>
</head>
<body>
{%app_entry%}
<footer>{%config%}{%scripts%}{%renderer%}</footer>
<script>
(function(){
  var IDLE=300000,t=setTimeout(doOut,IDLE);
  function reset(){clearTimeout(t);t=setTimeout(doOut,IDLE);}
  function doOut(){window.location.href='/logout?reason=idle';}
  ['mousemove','keydown','click','scroll','touchstart'].forEach(function(e){
    document.addEventListener(e,reset,true);
  });
  setInterval(function(){
    fetch('/heartbeat',{method:'POST',headers:{'Content-Type':'application/json'},
      body:'{"active":true}'}).then(function(r){
        if(r.status===401)doOut();
    }).catch(function(){});
  },60000);
})();
</script>
</body>
</html>
'''





# ── Executive light theme CSS ─────────────────────────────────────────────────
_EXEC_CSS = """
<style id="nbu-exec-light">
body, html { background: #f0f2f7 !important; }
.container-fluid { background: #f0f2f7 !important; padding: 0 !important; }
.tab-content { background: #f0f2f7 !important; }
.nav-tabs {
    background: #1e3a5f !important;
    border: none !important;
    padding: 0 16px !important;
    margin: 0 !important;
}
.nav-tabs .nav-link {
    color: rgba(255,255,255,0.5) !important;
    font-size: 10px !important;
    padding: 8px 11px !important;
    border: none !important;
    border-radius: 5px !important;
    margin: 6px 1px !important;
}
.nav-tabs .nav-link:hover {
    color: rgba(255,255,255,0.85) !important;
    background: rgba(255,255,255,0.1) !important;
}
.nav-tabs .nav-link.active {
    background: rgba(255,255,255,0.18) !important;
    color: #fff !important;
    font-weight: 600 !important;
    border: none !important;
}
.nav-tabs .nav-link.active::after {
    content: '';
    display: block;
    position: absolute;
    bottom: 0; left: 50%;
    transform: translateX(-50%);
    width: 20px; height: 2px;
    background: #60a5fa;
    border-radius: 2px;
}
.tab-pane { padding: 0 !important; }
</style>
"""
app.index_string = app.index_string.replace("</head>", _EXEC_CSS + "</head>")



# ══════════════════════════════════════════════════════════════════════════════
# AUTHENTICATION
# ══════════════════════════════════════════════════════════════════════════════
import os as _os, subprocess as _sp, hashlib as _hl
from flask import request as _req, session as _sess, redirect as _redir

_ALLOWED_USERS  = {"bkpadmin"}
_SESSION_KEY    = "nbu_cts_auth"
_TOKEN_KEY      = "nbu_cts_token"
_LAST_SEEN_KEY  = "nbu_cts_seen"
_SECRET_KEY     = _os.environ.get("NBU_SECRET_KEY",
                   "nbu-cts-2026-" + _hl.md5(b"CPCINCHPV186736").hexdigest()[:16])

# ── Session store: {token: {user, ip, created, last_seen}} ────────────────────
import threading as _thr
_SESSIONS     = {}   # token -> session info
_SESSION_LOCK = _thr.Lock()
_MAX_SESSIONS = 2    # max concurrent sessions per user
_IDLE_TIMEOUT = 300  # 5 min idle
_ABS_TIMEOUT  = 1800 # 30 min absolute

# ── Rate limiting: {ip: {fails, locked_until}} ────────────────────────────────
_RATE_LIMIT   = {}
_RATE_LOCK    = _thr.Lock()
_MAX_FAILS    = 3
_LOCK_SECS    = 300  # 5 min lockout

def _audit(event, user="—", ip="—", detail=""):
    logger.info(f"AUTH [{event}] user={user} ip={ip} {detail}")

def _auth_user(username, password):
    if username not in _ALLOWED_USERS:
        return False
    try:
        r = _sp.run(["su","-c","true",username],
                    input=password+"\n",
                    capture_output=True,text=True,timeout=5)
        return r.returncode == 0
    except Exception as e:
        logger.warning(f"Auth error: {e}")
        return False

def _is_rate_limited(ip):
    import time as _t
    with _RATE_LOCK:
        info = _RATE_LIMIT.get(ip,{})
        if info.get("locked_until",0) > _t.time():
            return True, int(info["locked_until"] - _t.time())
        return False, 0

def _record_fail(ip):
    import time as _t
    with _RATE_LOCK:
        info = _RATE_LIMIT.setdefault(ip, {"fails":0,"locked_until":0})
        info["fails"] += 1
        if info["fails"] >= _MAX_FAILS:
            info["locked_until"] = _t.time() + _LOCK_SECS
            info["fails"] = 0
            return True
    return False

def _clear_fail(ip):
    with _RATE_LOCK:
        _RATE_LIMIT.pop(ip, None)

def _create_session(user, ip):
    import time as _t, secrets as _s
    token = _s.token_hex(32)
    now   = _t.time()
    with _SESSION_LOCK:
        # Remove expired sessions for this user
        expired = [t for t,s in _SESSIONS.items()
                   if s["user"]==user and
                   (now-s["last_seen"]>_IDLE_TIMEOUT or now-s["created"]>_ABS_TIMEOUT)]
        for t in expired:
            del _SESSIONS[t]
        # Count active sessions for user
        active = [t for t,s in _SESSIONS.items() if s["user"]==user]
        if len(active) >= _MAX_SESSIONS:
            # Evict oldest session
            oldest = min(active, key=lambda t: _SESSIONS[t]["created"])
            _audit("SESSION_EVICTED", user, ip, f"evicted token ...{oldest[-6:]}")
            del _SESSIONS[oldest]
        _SESSIONS[token] = {"user":user,"ip":ip,"created":now,"last_seen":now}
    return token

def _validate_session(token):
    import time as _t
    if not token: return None
    with _SESSION_LOCK:
        s = _SESSIONS.get(token)
        if not s: return None
        now = _t.time()
        if now - s["last_seen"] > _IDLE_TIMEOUT:
            del _SESSIONS[token]
            return None
        if now - s["created"] > _ABS_TIMEOUT:
            del _SESSIONS[token]
            return None
        s["last_seen"] = now
        return s["user"]

def _destroy_session(token):
    with _SESSION_LOCK:
        _SESSIONS.pop(token, None)

def _is_logged_in():
    token = _sess.get(_TOKEN_KEY)
    user  = _validate_session(token)
    if user:
        _sess[_SESSION_KEY] = user
        return True
    return False

def _login_page(error=""):
    import sqlite3 as _sq3
    try:
        _c = _sq3.connect(DB_UNIFIED)
        _lag  = _c.execute("SELECT COALESCE(SUM(total),0) FROM lag_history WHERE date=(SELECT MAX(date) FROM lag_history)").fetchone()[0]
        _rv   = _c.execute("SELECT ROUND(COALESCE(SUM(used_tb),0),0) FROM diskpool_daily WHERE diskpool_group='Recovery Vault' AND run_date=(SELECT MAX(run_date) FROM diskpool_daily WHERE diskpool_group='Recovery Vault')").fetchone()[0]
        _rv_pct = round(float(_rv)/910*100,1) if _rv else 0
        _nsrv = _c.execute("SELECT COUNT(*) FROM servers").fetchone()[0]
        _c.close()
    except:
        _lag,_rv,_rv_pct,_nsrv = 0,0,0,14
    err_block = (
        "<div style='background:#FCEBEB;color:#A32D2D;padding:10px 14px;"
        "border-radius:8px;font-size:13px;margin-bottom:16px;"
        "border-left:3px solid #E24B4A;'>" + error + "</div>"
    ) if error else ""
    return """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>NBU-CTS — Sign in</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,-apple-system,sans-serif;}
html,body{height:100%;}
body{display:flex;min-height:100vh;background:#060e1a;}
.left{flex:1;background:linear-gradient(135deg,#0a1628 0%,#0f2847 40%,#0a1f3d 100%);
      display:flex;flex-direction:column;justify-content:space-between;
      padding:44px 48px;position:relative;overflow:hidden;}
.lb{position:absolute;top:0;left:0;right:0;height:3px;
    background:linear-gradient(90deg,#185FA5,#639922,#185FA5);}
.o1{position:absolute;top:-80px;left:-80px;width:280px;height:280px;border-radius:50%;
    background:radial-gradient(circle,rgba(24,95,165,0.3) 0%,transparent 70%);}
.o2{position:absolute;bottom:-60px;right:-60px;width:220px;height:220px;border-radius:50%;
    background:radial-gradient(circle,rgba(99,153,34,0.2) 0%,transparent 70%);}
.brand{display:flex;align-items:center;gap:14px;position:relative;}
.bi{width:48px;height:48px;background:linear-gradient(135deg,#185FA5,#0C447C);
    border-radius:12px;display:flex;align-items:center;justify-content:center;
    font-size:22px;font-weight:500;color:#fff;flex-shrink:0;}
.bn{font-size:18px;font-weight:500;color:#fff;}
.bs{font-size:11px;color:rgba(255,255,255,0.35);margin-top:2px;}
.hl{font-size:10px;text-transform:uppercase;letter-spacing:1.5px;
    color:#185FA5;font-weight:500;margin-bottom:14px;}
.ht{font-size:30px;font-weight:500;color:#fff;line-height:1.25;margin-bottom:14px;}
.ht span{color:#185FA5;}
.hd{font-size:13px;color:rgba(255,255,255,0.4);line-height:1.7;max-width:340px;}
.stats{display:flex;}
.stat{flex:1;padding-top:14px;}
.stat+.stat{padding-left:20px;border-left:0.5px solid rgba(255,255,255,0.08);margin-left:20px;}
.sv{font-size:26px;font-weight:500;color:#fff;line-height:1;}
.sv small{font-size:14px;color:rgba(255,255,255,0.35);}
.sl{font-size:10px;color:rgba(255,255,255,0.35);text-transform:uppercase;
    letter-spacing:0.5px;margin-top:4px;display:flex;align-items:center;gap:5px;}
.sd{width:5px;height:5px;border-radius:50%;background:#639922;flex-shrink:0;}
.right{width:440px;background:#fff;display:flex;flex-direction:column;
       justify-content:center;padding:52px 48px;position:relative;}
.rb{position:absolute;top:0;left:0;right:0;height:3px;
    background:linear-gradient(90deg,#185FA5,#639922);}
.st{position:absolute;top:18px;right:18px;font-size:10px;color:#94a3b8;
    background:#f8fafc;padding:4px 10px;border-radius:20px;border:0.5px solid #e2e8f0;}
.fb{display:flex;align-items:center;gap:10px;margin-bottom:32px;}
.fbi{width:36px;height:36px;background:linear-gradient(135deg,#185FA5,#0C447C);
     border-radius:8px;display:flex;align-items:center;justify-content:center;
     color:#fff;font-size:16px;font-weight:500;flex-shrink:0;}
.fbn{font-size:14px;font-weight:500;color:#1e3a5f;}
.fbs{font-size:10px;color:#94a3b8;margin-top:1px;}
h2{font-size:23px;font-weight:500;color:#1e293b;margin-bottom:6px;}
.fsb{font-size:13px;color:#64748b;margin-bottom:28px;line-height:1.55;}
.fl{font-size:11px;font-weight:500;color:#475569;text-transform:uppercase;
    letter-spacing:0.5px;display:block;margin-bottom:6px;}
input[type=text],input[type=password]{width:100%;padding:11px 14px;
    border:0.5px solid #e2e8f0;border-radius:8px;font-size:13px;color:#1e293b;
    outline:none;margin-bottom:16px;background:#fafafa;}
input:focus{border-color:#185FA5;background:#fff;
            box-shadow:0 0 0 3px rgba(24,95,165,0.08);}
.fbtn{width:100%;padding:12px;background:#185FA5;color:#fff;border:none;
      border-radius:8px;font-size:14px;font-weight:500;cursor:pointer;margin-top:4px;}
.fbtn:hover{background:#0C447C;}
.fdiv{height:0.5px;background:#f1f5f9;margin:22px 0;}
.fst{display:flex;flex-direction:column;gap:8px;}
.fsr{display:flex;align-items:center;justify-content:space-between;font-size:11px;color:#64748b;}
.fsl{display:flex;align-items:center;gap:6px;}
.fdot{width:6px;height:6px;border-radius:50%;flex-shrink:0;}
.pill{font-size:10px;padding:2px 8px;border-radius:10px;font-weight:500;}
.pg{background:#EAF3DE;color:#3B6D11;}
.pa{background:#FAEEDA;color:#854F0B;}
.pb{background:#E6F1FB;color:#0C447C;}
.fc{font-size:10px;color:#cbd5e1;text-align:center;margin-top:22px;}
@media(max-width:700px){body{flex-direction:column;}.left{display:none;}
  .right{width:100%;padding:40px 28px;}}
</style></head><body>
<div class="left"><div class="lb"></div><div class="o1"></div><div class="o2"></div>
  <div class="brand"><div class="bi">N</div>
    <div><div class="bn">NBU-CTS</div>
         <div class="bs">NetBackup Central Tracking System</div></div></div>
  <div><div class="hl">Fleet Intelligence Platform</div>
    <div class="ht">One pane of glass<br>for your <span>entire</span><br>backup fleet.</div>
    <div class="hd">Real-time visibility across """ + str(_nsrv) + """ master servers,
      6 regions, 130 media servers and recovery vault compliance.</div></div>
  <div class="stats">
    <div class="stat"><div class="sv">""" + str(_nsrv) + """</div>
      <div class="sl"><span class="sd"></span>Master servers</div></div>
    <div class="stat"><div class="sv">910<small> TB</small></div>
      <div class="sl"><span class="sd"></span>Vault license</div></div>
    <div class="stat"><div class="sv">6</div>
      <div class="sl"><span class="sd"></span>Global regions</div></div>
    <div class="stat"><div class="sv">24<small>/7</small></div>
      <div class="sl"><span class="sd"></span>Monitoring</div></div>
  </div>
</div>
<div class="right"><div class="rb"></div>
  <div class="st">CPCINCHPV186736</div>
  <div class="fb"><div class="fbi">N</div>
    <div><div class="fbn">NBU-CTS Dashboard</div>
         <div class="fbs">v3.0 &middot; Secure access</div></div></div>
  <h2>Sign in</h2>
  <p class="fsb">Enter your server credentials to access<br>the fleet monitoring dashboard.</p>
  """ + err_block + """
  <form method="POST" action="/login">
    <label class="fl">Username</label>
    <input type="text" name="username" placeholder="bkpadmin"
           autocomplete="username" required>
    <label class="fl">Password</label>
    <input type="password" name="password"
           placeholder="&#x2022;&#x2022;&#x2022;&#x2022;&#x2022;&#x2022;&#x2022;&#x2022;"
           autocomplete="current-password" required>
    <button type="submit" class="fbtn">Sign in &#8594;</button>
  </form>
  <div class="fdiv"></div>
  <div class="fst">
    <div class="fsr">
      <div class="fsl"><div class="fdot" style="background:#639922;"></div>Dashboard online</div>
      <span class="pill pg">Operational</span></div>
    <div class="fsr">
      <div class="fsl"><div class="fdot" style="background:#EF9F27;"></div>Fleet dup queue</div>
      <span class="pill pa">""" + f"{int(_lag):,}" + """ images</span></div>
    <div class="fsr">
      <div class="fsl"><div class="fdot" style="background:#185FA5;"></div>Recovery vault</div>
      <span class="pill pb">""" + str(_rv) + """ TB &middot; """ + str(_rv_pct) + """%</span></div>
  </div>
  <div class="fc">&#169; 2026 Cognizant &middot; NBU-CTS &middot; Restricted access</div>
</div>
<!-- Auto-logout JS injected after successful login -->
</body></html>"""

def _idle_logout_js(idle_secs=300):
    """JS snippet to auto-logout after idle timeout."""
    return f"""
<script>
(function(){{
  var IDLE = {idle_secs} * 1000;
  var t = setTimeout(doLogout, IDLE);
  function reset(){{ clearTimeout(t); t = setTimeout(doLogout, IDLE); }}
  function doLogout(){{
    fetch('/heartbeat', {{method:'POST'}});
    window.location.href = '/logout?reason=idle';
  }}
  ['mousemove','keydown','click','scroll','touchstart'].forEach(function(e){{
    document.addEventListener(e, reset, true);
  }});
  // Heartbeat every 60s to keep session alive on server
  setInterval(function(){{
    fetch('/heartbeat', {{method:'POST',
      headers:{{'Content-Type':'application/json'}},
      body:JSON.stringify({{active:true}})}});
  }}, 60000);
}})();
</script>"""


app.layout=html.Div([

    # ── Fixed dark mode toggle (bottom-left) ─────────────────────────────
    html.Div([
        html.Span("☀️", style={"fontSize":"13px","marginRight":"6px"}),
        html.Button("🌙 Dark", id="dark_mode_btn", n_clicks=0,
            style={"background":"#1A3C5E","color":"#fff","border":"none",
                   "borderRadius":"12px","padding":"4px 12px",
                   "cursor":"pointer","fontSize":"11px","fontWeight":"500"}),
    ], style={"position":"fixed","bottom":"16px","left":"16px",
              "zIndex":"9999","display":"flex","alignItems":"center",
              "background":"rgba(255,255,255,0.95)",
              "padding":"6px 10px","borderRadius":"20px",
              "boxShadow":"0 2px 8px rgba(0,0,0,0.15)",
              "border":"0.5px solid #e0e0e0"}),
    # ── Always-present global components ─────────────────────────────────
    dcc.Store(id="fleet_group_mode", data="all"),
    dcc.Store(id="vaultix_suggestions", data=[[s[0],s[1]] for s in INTENT_SUGGESTIONS.get("fleet",[])][:6]),
    dcc.Store(id="dark_mode", data=False),
    dcc.Store(id="master_filter_store", data={"regions":["all"],"infra":["onprem","azure","oci","gcp"],"masters":["all"],"date_range":"7d","preset":None}),
    dcc.Store(id="filter_sidebar_visible", data=True),
    dcc.Input(id="slm_input", type="text", value="",
        style={"display":"none","position":"absolute","width":"0"}),


    dcc.Download(id="download_csv"),
    dbc.Modal([
        dbc.ModalHeader(dbc.ModalTitle("📧 Email Vaultix Report")),
        dbc.ModalBody([
            html.Div("Recipients", style={"fontSize":"11px","fontWeight":"600",
                "color":"#334155","marginBottom":"4px"}),
            dcc.Input(id="vaultix_email_to", type="text",
                value="Yuvaraja.S2@cognizant.com",
                placeholder="email@company.com, email2@company.com",
                style={"width":"100%","marginBottom":"10px","padding":"7px",
                       "fontSize":"11px","border":"1px solid #e2e8f0",
                       "borderRadius":"6px"}),
            html.Div("Subject", style={"fontSize":"11px","fontWeight":"600",
                "color":"#334155","marginBottom":"4px"}),
            dcc.Input(id="vaultix_email_subject", type="text",
                value="Vaultix AI Report — NBU-CTS",
                style={"width":"100%","marginBottom":"10px","padding":"7px",
                       "fontSize":"11px","border":"1px solid #e2e8f0",
                       "borderRadius":"6px"}),
            html.Div(id="vaultix_email_preview",
                style={"background":"#f8fafc","border":"1px solid #e2e8f0",
                       "borderRadius":"6px","padding":"10px",
                       "fontSize":"10px","color":"#475569",
                       "maxHeight":"120px","overflowY":"auto",
                       "marginBottom":"10px"}),
            html.Div(id="vaultix_email_status",
                style={"fontSize":"11px","color":"#16a34a"}),
        ]),
        dbc.ModalFooter([
            html.Button("📧 Send to Team", id="vaultix_email_send_btn",
                n_clicks=0,
                style={"background":"#1e3a5f","color":"#fff","border":"none",
                       "borderRadius":"6px","padding":"7px 16px",
                       "fontSize":"11px","cursor":"pointer","fontWeight":"600",
                       "marginRight":"8px"}),
            html.Button("Cancel", id="vaultix_email_cancel_btn", n_clicks=0,
                style={"background":"#f1f5f9","border":"1px solid #e2e8f0",
                       "borderRadius":"6px","padding":"7px 14px",
                       "fontSize":"11px","cursor":"pointer"}),
        ]),
    ], id="vaultix_email_modal", is_open=False),
    dcc.Store(id="vaultix_email_content", data=""),

    dcc.Download(id="download_pdf_trigger"),
dbc.Modal([
            dbc.ModalHeader(dbc.ModalTitle("📧 Email Report")),
            dbc.ModalBody([
                dbc.Label("Recipients (comma-separated)"),
                dcc.Input(id="email_recipients", type="text",
                         placeholder="user@company.com, user2@company.com",
                         style={"width":"100%","marginBottom":"10px",
                                "padding":"6px","border":"1px solid #ccc",
                                "borderRadius":"4px","fontSize":"12px"}),
                dbc.Label("Report"),
                dcc.Dropdown(id="email_tab_select",
                    options=[
                        {"label":"Fleet Overview",        "value":"tab_home"},
                        {"label":"Duplication Queue",     "value":"tab_lag"},
                        {"label":"Storage Pools",         "value":"tab_dp"},
                        {"label":"External Airgap Vault", "value":"tab_3rd"},
                        {"label":"Catalog Health",        "value":"tab_cat"},
                        {"label":"Internal Airgap Vault", "value":"tab_ag"},
                    ],
                    value="tab_home", clearable=False,
                    style={"fontSize":"12px","marginBottom":"10px"}),
                dcc.Checklist(id="email_attach_csv",
                    options=[{"label":" Attach CSV","value":"csv"}],
                    value=["csv"],
                    style={"fontSize":"12px","marginBottom":"10px"}),
                html.Div(id="email_send_status",
                    style={"fontSize":"11px","color":"#639922","minHeight":"20px"}),
            ]),
            dbc.ModalFooter([
                html.Button("Send", id="email_send_btn", n_clicks=0,
                    style={"background":"#1A3C5E","color":"#fff",
                           "border":"none","borderRadius":"6px",
                           "padding":"6px 16px","fontSize":"12px",
                           "cursor":"pointer","fontWeight":"500",
                           "marginRight":"8px"}),
                html.Button("Cancel", id="email_modal_close", n_clicks=0,
                    style={"background":"#eee","color":"#333","border":"none",
                           "borderRadius":"6px","padding":"6px 16px",
                           "fontSize":"12px","cursor":"pointer"}),
            ]),
        ], id="email_modal", is_open=False),
    html.Div([
        html.Div([html.Span("🗄️",style={"fontSize":"16px","marginRight":"8px"}),html.Span("NBU Backup CTS — Global Operations Dashboard",style={"fontWeight":"500","fontSize":"15px","color":"#fff","letterSpacing":"0.3px"})],style={"display":"flex","alignItems":"center"}),
        html.Div([
            html.Div(id="live_clock",style={"fontSize":"11px","color":"rgba(255,255,255,0.7)"}),
            html.A("⏻ Sign out", href="/logout",
                   style={"fontSize":"11px","color":"rgba(255,255,255,0.7)",
                          "textDecoration":"none","padding":"4px 10px",
                          "border":"0.5px solid rgba(255,255,255,0.2)",
                          "borderRadius":"6px","marginLeft":"6px"}),
            html.Div(id="sync_freshness",style={"fontSize":"10px","color":"rgba(255,255,255,0.5)","marginTop":"2px"}),
        ],style={"textAlign":"right"})
    ],style={"background":BRAND,"padding":"12px 24px","display":"flex","alignItems":"center","justifyContent":"space-between","marginBottom":"0"}),
    dbc.Container([
        dbc.Tabs([dbc.Tab(label="🏠 Fleet Overview",tab_id="tab_home"),dbc.Tab(label="🤖 AI Insights",tab_id="tab_ai"),dbc.Tab(label="📊 Backup Jobs",tab_id="tab_bj"),dbc.Tab(label="🖥️ Media Servers",tab_id="tab_media"),dbc.Tab(label="📉 Duplication Queue",tab_id="tab_lag"),dbc.Tab(label="🌐 External Airgap Vault",tab_id="tab_3rd"),dbc.Tab(label="🔒 Internal Airgap Vault",tab_id="tab_ag"),dbc.Tab(label="📋 Catalog Health",tab_id="tab_cat"),dbc.Tab(label="💽 Storage Pools",tab_id="tab_dp"),dbc.Tab(label="📊 Reports",tab_id="tab_report"),dbc.Tab(label="🔗 SLP Monitor",tab_id="tab_slp"),dbc.Tab(label="🔷 Vaultix AI",tab_id="tab_slm")],id="main_tabs",active_tab="tab_home"),
        html.Div(id="filter_sidebar_content", style={"display":"none"}),
        html.Div(id="filter_cmd_bar",      style={"display":"none"}),
        html.Div(id="filter_chips_bar",    style={"display":"none"}),
        html.Div(id="filter_pills_bar",    style={"display":"none"}),
        html.Div(id="main_content"),
    ],fluid=True,style={"background":"#fff","borderRadius":"0 0 8px 8px","border":"0.5px solid #e0e0e0","padding":"0","maxWidth":"100%"}),
    dcc.Interval(id="clock_tick",interval=60_000,n_intervals=0),
],style={"minHeight":"100vh","background":"#f5f6f8"})


# ══════════════════════════════════════════════════════════════════════════════
# CALLBACKS
# ══════════════════════════════════════════════════════════════════════════════

def _build_ai_insights_email():
    """Build rich HTML email of current AI insights for ops team."""
    import sqlite3 as _sq
    from datetime import datetime as _dt
    try:
        con = _sq.connect(DB_UNIFIED)
        today = con.execute("SELECT MAX(date) FROM lag_history").fetchone()[0]
        lag = con.execute("""
            SELECT server_name, total, not_started_duplicate, in_process_duplicate
            FROM lag_history WHERE date=? ORDER BY total DESC LIMIT 6
        """, (today,)).fetchall()
        pools_down = con.execute("""
            SELECT server_name, COUNT(*) as cnt
            FROM diskpool_daily
            WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily)
            AND status='Down' GROUP BY server_name ORDER BY cnt DESC
        """).fetchall()
        rv = con.execute("""
            SELECT ROUND(SUM(used_tb),1) FROM diskpool_daily
            WHERE diskpool_group='Recovery Vault'
            AND run_date=(SELECT MAX(run_date) FROM diskpool_daily
                         WHERE diskpool_group='Recovery Vault')
        """).fetchone()[0] or 0
        rv_breach = con.execute("""
            SELECT COUNT(*) FROM (
                SELECT SUM(used_tb) as v FROM diskpool_daily
                WHERE diskpool_group='Recovery Vault' GROUP BY run_date
            ) WHERE v>910
        """).fetchone()[0]
        ag_down = con.execute(
            "SELECT server_name FROM v_server_latest WHERE ag_status='Not Working'"
        ).fetchall()
        cat_err = con.execute(
            "SELECT server_name FROM v_server_latest WHERE cat_status='ERROR'"
        ).fetchall()
        con.close()
    except Exception as ex:
        return f"<p>Error building insights: {ex}</p>"

    ts = _dt.now().strftime("%d %b %Y %H:%M")
    total_lag = sum(r[1] for r in lag)

    def _row(cells, hdr=False):
        tag = "th" if hdr else "td"
        s = "background:#1e3a5f;color:#fff;padding:8px 12px;font-size:12px;" if hdr else             "padding:8px 12px;border-bottom:1px solid #f1f5f9;font-size:12px;color:#334155;"
        return "<tr>" + "".join(f"<{tag} style='{s}'>{c}</{tag}>" for c in cells) + "</tr>"

    def _pill(txt, color):
        colors = {"red":("#FCEBEB","#A32D2D"),"amber":("#FAEEDA","#854F0B"),"green":("#EAF3DE","#3B6D11")}
        bg,fg = colors.get(color,("#f8fafc","#64748b"))
        return f"<span style='background:{bg};color:{fg};padding:2px 8px;border-radius:12px;font-size:11px;'>{txt}</span>"

    def _action(num, color, title, body, steps):
        bc = "#E24B4A" if color=="red" else "#EF9F27"
        bg = "#FCEBEB" if color=="red" else "#FAEEDA"
        tc = "#A32D2D" if color=="red" else "#854F0B"
        sl = "".join(f"<li style='margin:3px 0;font-size:12px;color:#475569;'>{s}</li>" for s in steps)
        return f"""<tr><td style='padding:10px 14px;border-bottom:1px solid #f1f5f9;'>
          <table width='100%'><tr>
            <td width='36' style='vertical-align:top;padding-top:2px;'>
              <div style='width:28px;height:28px;border-radius:50%;background:{bg};color:{tc};
                font-weight:500;font-size:13px;text-align:center;line-height:28px;'>{num}</div>
            </td>
            <td style='padding-left:10px;'>
              <div style='font-size:13px;font-weight:500;color:#1e293b;margin-bottom:4px;'>{title}</div>
              <div style='font-size:12px;color:#64748b;margin-bottom:8px;line-height:1.5;'>{body}</div>
              <ul style='margin:0;padding-left:16px;'>{sl}</ul>
            </td>
          </tr></table></td></tr>"""

    lag_rows  = "".join(_row([r[0].replace("cbkms",""),f"{r[1]:,}",f"{r[2]:,}",
                               _pill("HIGH","red") if r[1]>10000 else _pill("WATCH","amber")])
                        for r in lag)
    pool_rows = "".join(_row([r[0].replace("cbkms",""),str(r[1]),_pill("DOWN","red")])
                        for r in pools_down)
    ag_rows   = "".join(_row([r[0].replace("cbkms",""),"Not Working",_pill("CRITICAL","red")])
                        for r in ag_down)

    a1 = _action(1,"red",f"Fix airgap — {len(ag_down)} servers not working",
        "Airgap replication stalled on cpcinp1/2 and cazinp1. No 3-site protection until fixed.",
        ["Run nbstlutil on each affected server","Check SLP configuration",
         "Verify air-gap master connectivity","Restart SLP jobs if needed"])
    a2 = _action(2,"red",f"Recover Down pools — {sum(r[1] for r in pools_down)} pools",
        "Backup jobs targeting Down pools will fail. One pool at 77.8% near critical.",
        ["Run nbdevquery -listdp","Check media server connectivity",
         "Redirect policies from Down pools","Run bpexpdate on near-critical pools"])
    a3 = _action(3,"red",f"Clear dup backlog — {total_lag:,} images",
        "Structural backlog stable at 60K–72K for 15 days. Fixing steps 1+2 will unblock most.",
        ["After steps 1+2 monitor queue drop","Check STU throughput on cpcinp1 and cazinp1",
         "Review media server load balancing"])
    a4 = _action(4,"amber","Restore catalog backup — APAC",
        "China and Philippines showing ERROR, health 0/100. No catalog DR for APAC.",
        ["Test network to cpcchp1 and cpcphp1","Verify catalog backup policy",
         "Check STU from APAC"])
    a5 = _action(5,"amber",f"Vault before Sat 31 May full backup — {rv} TB / 910 TB",
        f"{rv_breach} historical breach days, peak 968 TB. cocinp1 dedup at 70% is primary driver.",
        ["Run nbdedup -report on cocinp1","Enable client-side dedup for large clients",
         "Monitor vault during Saturday backup window"])

    return f"""<!DOCTYPE html><html><head><meta charset='utf-8'></head>
<body style='margin:0;padding:0;background:#f8fafc;font-family:system-ui,sans-serif;'>
<table width='100%' cellpadding='0' cellspacing='0'>
<tr><td align='center' style='padding:24px 16px;'>
<table width='640' cellpadding='0' cellspacing='0'
       style='background:#fff;border-radius:12px;border:1px solid #e2e8f0;overflow:hidden;'>
  <tr><td style='background:#1e3a5f;padding:20px 28px;'>
    <div style='color:#fff;font-size:18px;font-weight:500;'>Fleet intelligence — action required</div>
    <div style='color:#94a3b8;font-size:12px;margin-top:4px;'>NBU-CTS · {ts} · 14 servers</div>
  </td></tr>
  <tr><td style='padding:16px 28px;border-bottom:1px solid #f1f5f9;'>
    <table width='100%'><tr>
      <td align='center' style='padding:0 8px;border-right:1px solid #f1f5f9;'>
        <div style='font-size:22px;font-weight:500;color:#E24B4A;'>{total_lag:,}</div>
        <div style='font-size:10px;color:#94a3b8;text-transform:uppercase;margin-top:2px;'>Dup queue</div>
      </td>
      <td align='center' style='padding:0 8px;border-right:1px solid #f1f5f9;'>
        <div style='font-size:22px;font-weight:500;color:#E24B4A;'>{sum(r[1] for r in pools_down)}</div>
        <div style='font-size:10px;color:#94a3b8;text-transform:uppercase;margin-top:2px;'>Pools down</div>
      </td>
      <td align='center' style='padding:0 8px;border-right:1px solid #f1f5f9;'>
        <div style='font-size:22px;font-weight:500;color:#185FA5;'>{rv} TB</div>
        <div style='font-size:10px;color:#94a3b8;text-transform:uppercase;margin-top:2px;'>Vault used</div>
      </td>
      <td align='center' style='padding:0 8px;border-right:1px solid #f1f5f9;'>
        <div style='font-size:22px;font-weight:500;color:#E24B4A;'>{len(ag_down)}</div>
        <div style='font-size:10px;color:#94a3b8;text-transform:uppercase;margin-top:2px;'>Airgap down</div>
      </td>
      <td align='center' style='padding:0 8px;'>
        <div style='font-size:22px;font-weight:500;color:#E24B4A;'>{len(cat_err)}</div>
        <div style='font-size:10px;color:#94a3b8;text-transform:uppercase;margin-top:2px;'>Catalog errors</div>
      </td>
    </tr></table>
  </td></tr>
  <tr><td style='padding:16px 28px 8px;'>
    <div style='font-size:13px;font-weight:500;color:#1e293b;'>What to do — in order</div>
  </td></tr>
  <tr><td style='padding:0 28px;'>
    <table width='100%' cellpadding='0' cellspacing='0'>{a1}{a2}{a3}{a4}{a5}</table>
  </td></tr>
  <tr><td style='padding:16px 28px;border-top:1px solid #f1f5f9;'>
    <table width='100%' cellpadding='0' cellspacing='0'>
      <thead>{_row(["Server","Queue","Not started","Status"],hdr=True)}</thead>
      <tbody>{lag_rows}</tbody>
    </table>
  </td></tr>
  <tr><td style='padding:0 28px 16px;'>
    <table width='100%' cellpadding='0' cellspacing='0'>
      <thead>{_row(["Server","Pools down","Status"],hdr=True)}</thead>
      <tbody>{pool_rows or _row(["No pools Down","",""])}</tbody>
    </table>
  </td></tr>
  <tr><td style='background:#f8fafc;padding:16px 28px;border-top:1px solid #e2e8f0;'>
    <div style='font-size:11px;color:#94a3b8;'>
      Generated by NBU-CTS Fleet Intelligence · {ts}<br>
      Next full backup: <strong>Sat 31 May 18:00</strong> · Vault: <strong>{rv} TB / 910 TB</strong>
    </div>
  </td></tr>
</table></td></tr></table></body></html>"""




@app.callback(
    Output("ai-insights-email-result","children"),
    Input("ai-insights-email-btn","n_clicks"),
    prevent_initial_call=True)
def cb_ai_insights_email(n):
    if not n: return dash.no_update
    try:
        from datetime import datetime as _dt
        recipients = ["HCSDPDeliveryTeam@cognizant.com","HCSDPOperationTeam@cognizant.com"]
        subject = f"[NBU-CTS] Fleet Intelligence — Action Required · {_dt.now().strftime('%d %b %Y %H:%M')}"
        html_body = _build_ai_insights_email()
        # Inline SMTP send
        import smtplib
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = "noreply@nbu-cts.cts.com"
        msg["To"]      = ", ".join(recipients)
        msg.attach(MIMEText(html_body, "html", "utf-8"))
        with smtplib.SMTP("localhost", 25, timeout=10) as srv:
            srv.sendmail(msg["From"], recipients, msg.as_string())
        logger.info(f"AI insights email sent to {recipients}")
        return html.Span([
            html.Span("✓ ", style={"color":"#3B6D11","fontWeight":"500"}),
            f"Sent to {len(recipients)} recipients",
        ])
    except Exception as e:
        logger.error(f"AI insights email error: {e}")
        return html.Span(f"Error: {e}", style={"color":"#A32D2D","fontSize":"11px"})


@app.callback(
    Output("live_clock","children"),
    Output("sync_freshness","children"),
    Input("clock_tick","n_intervals"))
def cb_clock(_):
    clock = datetime.now().strftime("🕐 %d-%b-%Y %H:%M")
    try:
        last_sync = scalar(DB_UNIFIED, "SELECT MAX(synced_at) FROM sync_log")
        if last_sync:
            delta = (datetime.now() - datetime.fromisoformat(last_sync[:19])).seconds
            age   = f"{delta//3600}h {(delta%3600)//60}m ago" if delta>=3600 else f"{delta//60}m ago"
            dot   = "🟢" if delta < 3600 else ("🟡" if delta < 86400 else "🔴")
            sync_txt = f"{dot} Data synced {age}"
        else:
            sync_txt = "⚠️ No sync recorded"
    except Exception:
        sync_txt = ""
    return clock, sync_txt


@app.callback(Output("home_server_detail","children"),Output("selected_server","data"),Input({"type":"server_card","index":ALL},"n_clicks"),prevent_initial_call=True)
def cb_server_card(n_list):
    if not ctx.triggered_id or not any(n for n in n_list if n): return dash.no_update,dash.no_update
    srv=ctx.triggered_id["index"]; logger.info(f"Server card: {srv}")
    return build_server_detail_card(srv),srv

@app.callback(Output("main_tabs","active_tab",allow_duplicate=True),Output("slm_input","value",allow_duplicate=True),Input({"type":"ask_vaultix_btn","index":ALL},"n_clicks"),prevent_initial_call=True)
def cb_ask_vaultix(n_list):
    if not ctx.triggered_id or not any(n for n in n_list if n): return dash.no_update,dash.no_update
    triggered_val = ctx.triggered[0]["value"] if ctx.triggered else 0
    if not triggered_val: return dash.no_update,dash.no_update
    srv=ctx.triggered_id["index"]
    return "tab_slm",f"Show full report for {srv}"

@app.callback(Output("slm_input","value"),Input({"type":"vaultix_quick","index":ALL},"n_clicks"),prevent_initial_call=True)
def cb_quick(n_list):
    if ctx.triggered_id and n_list[ctx.triggered_id["index"]]: return QUICK_QUERIES[ctx.triggered_id["index"]][1]
    return dash.no_update

@app.callback(Output("slm_input","value",allow_duplicate=True),Input("slm_clear","n_clicks"),prevent_initial_call=True)
def cb_clear(_): return ""

# ── AI Insights callbacks ──────────────────────────────────────────────────

@app.callback(
    Output("ai_detail_body","children",  allow_duplicate=True),
    Output("ai_detail_title","children", allow_duplicate=True),
    Output("ai_action_row","children",   allow_duplicate=True),
    Output("ai_active_insight","data",   allow_duplicate=True),
    Output("ai_feed_rows","children",    allow_duplicate=True),
    Input({"type":"insight_row","index":ALL},"n_clicks"),
    State("ai_insights_store","data"),
    prevent_initial_call=True)
def cb_insight_row(n_list, store):
    if not ctx.triggered_id or not any(n for n in n_list if n): return (dash.no_update,)*5
    iid=ctx.triggered_id["index"]; store=store or []
    meta=next((s for s in store if s["id"]==iid),None)
    if not meta: return (dash.no_update,)*5
    detail=_rebuild_insight_detail(iid); title=meta["title"]; actions=meta["actions"]
    sev_color_map={"critical":"#E24B4A","warning":"#EF9F27","healthy":"#639922","info":"#378ADD"}
    action_btns=html.Div([
        html.Div(action[0],id={"type":"ai_action_btn","index":f"{action[1]}::{action[2]}"[:120]},n_clicks=0,
            style={"padding":"4px 12px","borderRadius":"6px","fontSize":"10px","cursor":"pointer","display":"inline-flex","alignItems":"center",
                   "background":BRAND if i==len(actions)-1 else "#fff","color":"#fff" if i==len(actions)-1 else "#333",
                   "border":f"0.5px solid {BRAND if i==len(actions)-1 else '#d0d0d0'}"})
        for i,action in enumerate(actions)
    ],id="ai_action_row",style={"display":"flex","gap":"6px"})
    new_feed=[]
    for ins in store:
        is_active=(ins["id"]==iid); sev=ins["sev"]; sev_color=sev_color_map.get(sev,"#ccc")
        parts=ins["id"].split("_",2); source=parts[0].capitalize(); server=parts[2] if len(parts)>2 else "Fleet"
        new_feed.append(html.Div([
            html.Div(style={"width":"3px","borderRadius":"2px","flexShrink":"0","alignSelf":"stretch","minHeight":"40px","background":sev_color}),
            html.Div([html.Div(f"{source} · {server}",style={"fontSize":"9px","color":"#aaa","marginBottom":"2px","textTransform":"uppercase","letterSpacing":"0.5px"}),
                html.Div(ins["title"],style={"fontSize":"11px","fontWeight":"500","color":BRAND if is_active else "#333","lineHeight":"1.3","marginBottom":"3px"}),
                html.Div(pill(ins["pill"],{"critical":"danger","warning":"warning","healthy":"success","info":"info"}.get(sev,"secondary")),style={"display":"flex","alignItems":"center"})],style={"flex":"1"})
        ],id={"type":"insight_row","index":ins["id"]},n_clicks=0,
        style={"padding":"10px 12px","borderBottom":"0.5px solid #ebebeb","cursor":"pointer","display":"flex","gap":"8px","alignItems":"flex-start",
               "background":"#e8f0fe" if is_active else "transparent",
               "borderLeft":f"3px solid {sev_color}" if is_active else "3px solid transparent","transition":"background 0.12s, border-left 0.12s"}))
    return detail,title,action_btns,iid,new_feed

@app.callback(
    Output("ai_feed_rows","children",    allow_duplicate=True),
    Output("ai_filter_all","style",      allow_duplicate=True),
    Output("ai_filter_critical","style", allow_duplicate=True),
    Output("ai_filter_warning","style",  allow_duplicate=True),
    Output("ai_filter_healthy","style",  allow_duplicate=True),
    Output("ai_detail_body","children",  allow_duplicate=True),
    Output("ai_detail_title","children", allow_duplicate=True),
    Output("ai_active_insight","data",   allow_duplicate=True),
    Input("ai_filter_all","n_clicks"),
    Input("ai_filter_critical","n_clicks"),
    Input("ai_filter_warning","n_clicks"),
    Input("ai_filter_healthy","n_clicks"),
    State("ai_insights_store","data"),
    State("ai_active_insight","data"),
    prevent_initial_call=True)
def cb_ai_filter(n_all, n_crit, n_warn, n_ok, store, active_id):
    triggered=ctx.triggered_id
    if not triggered: return (dash.no_update,)*5
    fmap={"ai_filter_all":"all","ai_filter_critical":"critical","ai_filter_warning":"warning","ai_filter_healthy":"healthy"}
    active_filter=fmap.get(triggered,"all")
    def chip_style(is_active):
        return {"padding":"3px 9px","borderRadius":"10px","fontSize":"9px","cursor":"pointer","border":f"0.5px solid {BRAND if is_active else '#d0d0d0'}","background":BRAND if is_active else "#fff","color":"#fff" if is_active else "#555"}
    sev_color_map={"critical":"#E24B4A","warning":"#EF9F27","healthy":"#639922","info":"#378ADD"}
    store=store or []; rows=[]
    for ins in store:
        sev=ins["sev"]
        if active_filter!="all" and sev!=active_filter: continue
        is_active=(ins["id"]==active_id); sev_color=sev_color_map.get(sev,"#ccc")
        parts=ins["id"].split("_",2); source=parts[0].capitalize(); server=parts[2] if len(parts)>2 else "Fleet"
        rows.append(html.Div([
            html.Div(style={"width":"3px","borderRadius":"2px","flexShrink":"0","alignSelf":"stretch","minHeight":"40px","background":sev_color}),
            html.Div([html.Div(f"{source} · {server}",style={"fontSize":"9px","color":"#aaa","marginBottom":"2px","textTransform":"uppercase","letterSpacing":"0.5px"}),
                html.Div(ins["title"],style={"fontSize":"11px","fontWeight":"500","color":BRAND if is_active else "#333","lineHeight":"1.3","marginBottom":"3px"}),
                html.Div(pill(ins["pill"],{"critical":"danger","warning":"warning","healthy":"success","info":"info"}.get(sev,"secondary")),style={"display":"flex","alignItems":"center"})],style={"flex":"1"})
        ],id={"type":"insight_row","index":ins["id"]},n_clicks=0,
        style={"padding":"10px 12px","borderBottom":"0.5px solid #ebebeb","cursor":"pointer","display":"flex","gap":"8px","alignItems":"flex-start",
               "background":"#e8f0fe" if is_active else "transparent",
               "borderLeft":f"3px solid {sev_color}" if is_active else "3px solid transparent","transition":"background 0.12s, border-left 0.12s"}))
    if not rows: rows=[html.Div("No insights for this filter.",style={"padding":"16px 14px","fontSize":"11px","color":"#aaa"})]
    # Find first item in filtered set to show in detail panel
    filtered_store = [i for i in (store or []) if active_filter=="all" or i["sev"]==active_filter]
    if filtered_store:
        first_id    = filtered_store[0]["id"]
        first_title = filtered_store[0]["title"]
        first_detail= _rebuild_insight_detail(first_id)
    else:
        first_id    = active_id
        first_title = "No insights for this filter"
        first_detail= html.Div("No insights match this filter.",style={"padding":"20px","color":"#aaa"})
    return rows,chip_style(active_filter=="all"),chip_style(active_filter=="critical"),chip_style(active_filter=="warning"),chip_style(active_filter=="healthy"),first_detail,first_title,first_id

@app.callback(
    Output("main_tabs","active_tab",allow_duplicate=True),
    Output("slm_input","value",     allow_duplicate=True),
    Input({"type":"ai_action_btn",   "index":ALL},"n_clicks"),
    Input({"type":"insight_rec_btn", "index":ALL},"n_clicks"),
    Input({"type":"insight_srv_chip","index":ALL},"n_clicks"),
    prevent_initial_call=True)
def cb_ai_actions(btn_clicks, rec_clicks, chip_clicks):
    if not ctx.triggered_id: return dash.no_update,dash.no_update
    # Only act if the triggered input has n_clicks > 0
    triggered_val = ctx.triggered[0]["value"] if ctx.triggered else 0
    if not triggered_val: return dash.no_update,dash.no_update
    encoded=ctx.triggered_id.get("index","") if isinstance(ctx.triggered_id,dict) else ""
    if not encoded: return dash.no_update,dash.no_update
    if "::" in encoded:
        dest_tab,query=encoded.split("::",1)
        valid_tabs={"tab_home","tab_lag","tab_dp","tab_3rd","tab_ai","tab_cat","tab_ag","tab_slm"}
        if dest_tab not in valid_tabs: dest_tab="tab_slm"
    else:
        query=encoded; dest_tab="tab_slm"
    return dest_tab,query

# ── Vaultix callbacks ──────────────────────────────────────────────────────

@app.callback(
    Output("vaultix_chat_window","children",  allow_duplicate=True),
    Output("slm_history","data",              allow_duplicate=True),
    Output("vaultix_sessions","data",         allow_duplicate=True),
    Output("vaultix_active_id","data",        allow_duplicate=True),
    Output("vaultix_session_list","children", allow_duplicate=True),
    Input("vaultix_new_chat","n_clicks"),
    State("vaultix_sessions","data"),State("slm_history","data"),State("vaultix_active_id","data"),
    prevent_initial_call=True)
def cb_new_chat(n, sessions, history, active_id):
    if not n: return (dash.no_update,)*5
    sessions=sessions or []
    if history: _upsert_session(sessions,active_id,history)
    new_id=(max(s["id"] for s in sessions)+1) if sessions else 1
    sessions.append({"id":new_id,"label":f"Chat {datetime.now().strftime('%H:%M')}","history":[]})
    return ([_welcome_bubble()],[],sessions,new_id,_build_session_list(sessions,new_id))

@app.callback(
    Output("vaultix_chat_window","children",  allow_duplicate=True),
    Output("slm_history","data",              allow_duplicate=True),
    Output("vaultix_active_id","data",        allow_duplicate=True),
    Output("vaultix_session_list","children", allow_duplicate=True),
    Input({"type":"vaultix_session_btn","index":ALL},"n_clicks"),
    State("vaultix_sessions","data"),
    prevent_initial_call=True)
def cb_switch_session(n_list, sessions):
    if not ctx.triggered_id or not any(n for n in n_list if n): return (dash.no_update,)*4
    sess=next((s for s in (sessions or []) if s["id"]==ctx.triggered_id["index"]),None)
    if not sess: return (dash.no_update,)*4
    bubbles=[_welcome_bubble()]
    for i, h in enumerate(sess.get("history",[])):
        bubbles.append(_user_bubble(h["q"]))
        comp=h.get("a_component")
        bubbles.append(_bot_bubble(comp if comp is not None else h.get("a",""), idx=i))
    return (bubbles,sess.get("history",[]),ctx.triggered_id["index"],_build_session_list(sessions,ctx.triggered_id["index"]))

@app.callback(
    Output("vaultix_chat_window","children",  allow_duplicate=True),
    Output("slm_history","data",              allow_duplicate=True),
    Output("vaultix_sessions","data",         allow_duplicate=True),
    Output("vaultix_session_list","children", allow_duplicate=True),
    Output("vaultix_status","children"),
    Output("slm_input","value",               allow_duplicate=True),
    Output("vaultix_topbar_title","children", allow_duplicate=True),
    Input("slm_submit","n_clicks"),
    Input("slm_input","n_submit"),
    State("slm_input","value"),State("slm_history","data"),State("vaultix_sessions","data"),State("vaultix_active_id","data"),
    prevent_initial_call=True)
def cb_send(_, _ns, query, history, sessions, active_id):
    # Guard: only act if triggered by actual user action (click or Enter)
    if not ctx.triggered: return (dash.no_update,)*7
    triggered_val = ctx.triggered[0]["value"] if ctx.triggered else None
    if not triggered_val: return (dash.no_update,)*7
    if not query or not query.strip(): return (dash.no_update,)*7
    query=query.strip(); history=history or []; sessions=sessions or []
    if not any(s["id"]==active_id for s in sessions):
        active_id=1; sessions.append({"id":1,"label":"Chat 1","history":[]})
    t0=datetime.now()
    answer_component,intent,matched_server=slm_answer_full(query,history=history)
    elapsed=round((datetime.now()-t0).total_seconds(),2)
    # matched_server may be a list (group) or string (single)
    srv_log = matched_server if isinstance(matched_server, str) else str(matched_server)
    logger.info(f"Vaultix: '{query[:50]}' -> intent:{intent} srv:{srv_log} t:{elapsed}s")
    # Extract meaningful text summary for email/history
    def _extract_text(comp):
        """Recursively extract text from Dash component."""
        if comp is None: return ""
        if isinstance(comp, str): return comp
        if isinstance(comp, (int, float)): return str(comp)
        if isinstance(comp, list):
            return " ".join(_extract_text(c) for c in comp if c)
        if hasattr(comp, "children"):
            return _extract_text(comp.children)
        return ""
    raw_text = _extract_text(answer_component)
    # Clean up whitespace
    import re as _re
    raw_text = _re.sub(r"\s{3,}", "  ", raw_text).strip()
    text_summary = raw_text[:1500] if raw_text else f"[{intent}] {matched_server or 'fleet'}"
    # Convert Dash component tree to email-safe HTML
    def _comp_to_html(comp):
        if comp is None: return ""
        if isinstance(comp, str): return str(comp).replace("<","&lt;").replace(">","&gt;")
        if isinstance(comp, (int,float,bool)): return str(comp)
        if isinstance(comp, list):
            return "".join(_comp_to_html(c) for c in comp if c is not None)
        # Dash component — get class name for tag mapping
        cls = type(comp).__name__.lower()
        tag_map = {
            "div":"div","span":"span","table":"table","thead":"thead",
            "tbody":"tbody","tr":"tr","td":"td","th":"th","tr":"tr",
            "h1":"h1","h2":"h2","h3":"h3","h4":"h4","p":"p","br":"br",
            "strong":"strong","em":"em","button":"span","a":"span","li":"li",
            "ul":"ul","ol":"ol","img":"span","iframe":"span",
        }
        html_tag = tag_map.get(cls, "div")
        # Build children
        children_html = ""
        if hasattr(comp, "children") and comp.children is not None:
            children_html = _comp_to_html(comp.children)
        # Build style
        style_str = ""
        if hasattr(comp, "style") and comp.style:
            try:
                import re as _re2
                # Convert camelCase to kebab-case
                def _to_kebab(s):
                    return _re2.sub(r'([A-Z])', lambda m: '-'+m.group(1).lower(), s)
                safe_props = {"color","background","font-weight","font-size",
                              "padding","text-align","border-bottom","font-family",
                              "border-radius","white-space","display","vertical-align",
                              "border","border-left","min-width","width","margin-top",
                              "margin-bottom","letter-spacing","text-transform"}
                parts = []
                for k,v in comp.style.items():
                    kb = _to_kebab(k)
                    if kb in safe_props and v:
                        parts.append(f"{kb}:{v}")
                if parts:
                    style_str = ' style="' + ";".join(parts) + '"'
            except: pass
        if html_tag == "br": return "<br>"
        if html_tag == "span" and not children_html: return ""
        return f"<{html_tag}{style_str}>{children_html}</{html_tag}>"

    try:
        email_html_body = _comp_to_html(answer_component)
        # Validate it looks like HTML not repr
        if "Div(children=" in email_html_body or len(email_html_body) < 10:
            email_html_body = ""
    except Exception:
        email_html_body = ""

    history.append({"q":query,"a":text_summary,"a_html":email_html_body,
                    "a_component":answer_component,"intent":intent,"server":matched_server})
    # Persist to DB for gap analysis and continuous learning
    was_answered = 0 if intent in ("rag_fallback","error") else 1
    try:
        if _save_chat:
            _save_chat(question=query,answer=text_summary,intent=intent,
                       matched_server=matched_server,elapsed_sec=elapsed,
                       was_answered=was_answered)
    except Exception as _e:
        logger.warning(f"chat persist failed: {_e}")
    _upsert_session(sessions,active_id,history)
    bubbles=[_welcome_bubble()]
    for i, h in enumerate(history):
        bubbles.append(_user_bubble(h["q"]))
        comp=h.get("a_component"); bubbles.append(_bot_bubble(comp if comp is not None else h.get("a",""), idx=i))
    # Confidence scoring
    if intent in ("temporal","digest","multi_intent"):
        confidence,conf_color = "LIVE","#639922"
    elif intent in ("lag","diskpool","3rdsite","catalog","airgap",
                    "server_full","lag_history","multi_intent"):
        confidence,conf_color = "HIGH","#639922"
    elif intent == "rag_fallback":
        confidence,conf_color = "LOW","#E24B4A"
    else:
        confidence,conf_color = "MEDIUM","#EF9F27"
    status=[f"⏱ {elapsed}s  ·  intent: ",
            html.Span(intent,style={"background":"#e8f0fe","color":BRAND,
                      "borderRadius":"8px","padding":"1px 7px","fontSize":"9px"}),
            "  ·  confidence: ",
            html.Span(confidence,style={"background":conf_color,"color":"#fff",
                      "borderRadius":"8px","padding":"1px 7px","fontSize":"9px",
                      "fontWeight":"500"})]
    return (bubbles,history,sessions,_build_session_list(sessions,active_id),status,"",_vaultix_topbar_title(history))


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
if __name__=="__main__":
    import ssl as _ssl
    ctx_ssl=_ssl.SSLContext(_ssl.PROTOCOL_TLS_SERVER)
    try:
        ctx_ssl.load_cert_chain(SSL_CERT,SSL_KEY); ssl_args={"ssl_context":ctx_ssl}; logger.info(f"HTTPS enabled ({SSL_CERT})")
    except Exception as e:
        logger.warning(f"SSL skipped: {e} — running HTTP"); ssl_args={}
    logger.info("="*70); logger.info("NBU-CTS Dashboard v3.0 — Full Redesign"); logger.info(f"Port: {PORT}  |  Logs: {LOG_DIR}/dashboard.log"); logger.info("="*70)
    

@app.callback(
    Output("download_csv","data"),
    Input({"type":"export_csv_btn","index":ALL},"n_clicks"),
    prevent_initial_call=True)
def cb_export_csv(n_list):
    if not ctx.triggered_id: return dash.no_update
    triggered_val = ctx.triggered[0]["value"] if ctx.triggered else 0
    if not triggered_val: return dash.no_update
    tab_id = ctx.triggered_id.get("index","tab_home")              if isinstance(ctx.triggered_id, dict) else "tab_home"
    try:
        if _MAILER_LOADED:
            filename, csv_data = get_tab_csv(tab_id)
            return dict(content=csv_data, filename=filename)
        return dash.no_update
    except Exception as e:
        logger.error(f"CSV export failed: {e}")
        return dash.no_update


app.clientside_callback(
    """
    function(n_clicks, is_dark) {
        if (!n_clicks) return [is_dark, '🌙 Dark'];
        const new_dark = !is_dark;

        const existingStyle = document.getElementById('nbu-dark-mode-style');
        if (existingStyle) existingStyle.remove();

        const btn = document.getElementById('dark_mode_btn');

        if (new_dark) {
            const style = document.createElement('style');
            style.id = 'nbu-dark-mode-style';
            style.textContent = `
                body, html { background: #0d1117 !important; color: #c9d1d9 !important; }
                div, section, main { background-color: transparent; }
                div[style*="background:#fff"], div[style*="background: #fff"],
                div[style*="background:white"], div[style*="background: white"],
                div[style*="background:#f8f9fb"], div[style*="background: #f8f9fb"],
                div[style*="background:#f0f4fa"], div[style*="background: #f0f4fa"],
                div[style*="background:#fafbff"], div[style*="background:#eef4ff"],
                div[style*="background:#fff0f0"], div[style*="background:#fff8ec"],
                div[style*="background: rgb(255"],
                div[style*="padding"][style*="border"] { background: #161b22 !important; }
                p, span, div, td, th, label, h1, h2, h3, h4, h5, h6, a
                    { color: #c9d1d9 !important; }
                table { background: #161b22 !important; border-color: #30363d !important; }
                th { background: #21262d !important; color: #58a6ff !important; }
                tr { background: #161b22 !important; }
                td { color: #c9d1d9 !important; border-color: #30363d !important; }
                input, textarea, select {
                    background: #21262d !important; color: #c9d1d9 !important;
                    border-color: #30363d !important; }
                .nav-tabs { border-color: #30363d !important; background: #0d1117 !important; }
                .nav-tabs .nav-link { color: #8b949e !important; background: #0d1117 !important; }
                .nav-tabs .nav-link.active {
                    background: #161b22 !important; color: #58a6ff !important; }
                .modal-content { background: #161b22 !important; color: #c9d1d9 !important; }
                .Select-control, .Select-menu-outer {
                    background: #21262d !important; color: #c9d1d9 !important; }
            `;
            document.head.appendChild(style);
            document.body.style.cssText = 'background: #0d1117 !important;';
            if (btn) { btn.textContent = '☀️ Light'; btn.style.background = '#639922'; }
        } else {
            document.body.style.cssText = 'background: #f8f9fb;';
            if (btn) { btn.textContent = '🌙 Dark'; btn.style.background = '#1A3C5E'; }
        }
        return [new_dark, new_dark ? '☀️ Light' : '🌙 Dark'];
    }
    """,
    Output("dark_mode","data"),
    Output("dark_mode_btn","children"),
    Input("dark_mode_btn","n_clicks"),
    State("dark_mode","data"),
    prevent_initial_call=True)


@app.callback(
    Output("vaultix_quick_dynamic","children"),
    Input("vaultix_suggestions","data"))
def cb_update_suggestions(sugg_data):
    if not sugg_data:
        sugg_data = [[s[0],s[1]] for s in INTENT_SUGGESTIONS.get("fleet",[])][:6]
    chips = []
    for i, item in enumerate(sugg_data):
        icon = item[0] if isinstance(item,(list,tuple)) else "🔷"
        text = item[1] if isinstance(item,(list,tuple)) else str(item)
        chips.append(html.Button(
            [html.Span(icon, style={"marginRight":"3px"}),
             html.Span(text[:45]+("…" if len(text)>45 else ""),
                       style={"fontSize":"10px"})],
            id={"type":"vaultix_suggestion","index":i},
            n_clicks=0, title=text,
            style={"background":"#e8f0fe","border":"0.5px solid #c5d8f8",
                   "borderRadius":"14px","padding":"3px 10px",
                   "cursor":"pointer","fontSize":"10px","color":"#1A3C5E",
                   "whiteSpace":"nowrap","margin":"2px",
                   "fontFamily":"inherit"}))
    return html.Div(chips, style={"display":"flex","flexWrap":"wrap",
                                   "gap":"3px","alignItems":"center"})


@app.callback(
    Output("slm_input","value", allow_duplicate=True),
    Input({"type":"vaultix_suggestion","index":ALL},"n_clicks"),
    State("vaultix_suggestions","data"),
    prevent_initial_call=True)
def cb_suggestion_click(clicks, current_suggestions):
    if not ctx.triggered_id: return dash.no_update
    if not any(c for c in (clicks or []) if c): return dash.no_update
    triggered_idx = (ctx.triggered_id.get("index",0)
                     if isinstance(ctx.triggered_id,dict) else 0)
    sugg = current_suggestions or [[s[0],s[1]] for s in INTENT_SUGGESTIONS.get("fleet",[])]
    if triggered_idx < len(sugg):
        item = sugg[triggered_idx]
        return item[1] if isinstance(item,(list,tuple)) else str(item)
    return dash.no_update


@app.callback(
    Output("vaultix_suggestions","data", allow_duplicate=True),
    Input("slm_history","data"),
    prevent_initial_call=True)
def cb_update_sugg_from_history(history):
    if not history:
        return [[s[0],s[1]] for s in INTENT_SUGGESTIONS.get("fleet",[])][:6]
    last   = history[-1] if history else {}
    intent = last.get("intent","fleet")
    sugg   = INTENT_SUGGESTIONS.get(intent, INTENT_SUGGESTIONS.get("fleet",[]))
    return [[s[0],s[1]] for s in sugg][:6]



# ── Vaultix Email callbacks ───────────────────────────────────────────────────


# ── Media Servers export callbacks ───────────────────────────────────────────

@app.callback(
    Output("download_csv","data", allow_duplicate=True),
    Input("ms_export_csv","n_clicks"),
    State("ms_master_filter","value"),
    State("ms_status_filter","value"),
    prevent_initial_call=True)
def cb_ms_export_csv(n, master_f, status_f):
    if not n: return dash.no_update
    import sqlite3 as _sq, pandas as _pd, io
    con = _sq.connect(DB_UNIFIED)
    q = """
        SELECT master_name, media_server, ai_status,
               active_jobs, total_jobs, ROUND(data_tb,2) AS data_tb,
               ROUND(efficiency,4) AS efficiency,
               ROUND(dup_ratio,4) AS dup_ratio, timestamp
        FROM media_metrics_unified m1
        WHERE timestamp=(SELECT MAX(timestamp) FROM media_metrics_unified m2
                         WHERE m2.media_server=m1.media_server)
    """
    params = []
    if master_f and master_f != "all":
        q += " AND master_name=?"
        params.append(master_f)
    if status_f and status_f != "all":
        q += " AND ai_status=?"
        params.append(status_f)
    q += " ORDER BY master_name, ai_status DESC, active_jobs DESC"
    df = _pd.read_sql_query(q, con, params=params)
    con.close()
    label = f"_{master_f}" if master_f != "all" else "_all"
    return dcc.send_data_frame(df.to_csv, f"media_servers{label}.csv", index=False)


@app.callback(
    Output("vaultix_email_modal","is_open", allow_duplicate=True),
    Output("vaultix_email_content","data", allow_duplicate=True),
    Output("vaultix_email_preview","children", allow_duplicate=True),
    Output("vaultix_email_subject","value", allow_duplicate=True),
    Input("ms_export_email","n_clicks"),
    State("ms_master_filter","value"),
    State("ms_status_filter","value"),
    prevent_initial_call=True)
def cb_ms_export_email(n, master_f, status_f):
    if not n: return dash.no_update, dash.no_update, dash.no_update, dash.no_update
    import sqlite3 as _sq, pandas as _pd
    con = _sq.connect(DB_UNIFIED)
    q = """
        SELECT master_name, media_server, ai_status,
               active_jobs, total_jobs, ROUND(data_tb,2) AS data_tb,
               ROUND(efficiency,4) AS efficiency,
               ROUND(dup_ratio,4) AS dup_ratio
        FROM media_metrics_unified m1
        WHERE timestamp=(SELECT MAX(timestamp) FROM media_metrics_unified m2
                         WHERE m2.media_server=m1.media_server)
    """
    params = []
    if master_f and master_f != "all":
        q += " AND master_name=?"; params.append(master_f)
    if status_f and status_f != "all":
        q += " AND ai_status=?"; params.append(status_f)
    q += " ORDER BY master_name, ai_status DESC, active_jobs DESC"
    df = _pd.read_sql_query(q, con, params=params)
    con.close()
    hl = len(df[df["ai_status"]=="HIGH_LOAD"])
    an = len(df[df["ai_status"]=="ANOMALY"])
    label = master_f.upper() if master_f != "all" else "All Masters"
    subject = f"NBU Media Server Report — {label} — {datetime.now().strftime('%Y-%m-%d')}"
    content = json.dumps({
        "type": "media_report",
        "master_filter": master_f,
        "status_filter": status_f,
        "label": label,
        "hl": hl, "an": an,
        "total": len(df),
        "rows": df.to_dict("records"),
    })
    preview = html.Div([
        html.Div(f"Media Server Report — {label}",
            style={"fontWeight":"600","fontSize":"11px","marginBottom":"4px"}),
        html.Div(f"{len(df)} servers · {hl} HIGH_LOAD · {an} ANOMALY",
            style={"color":"#64748b","fontSize":"10px"}),
    ])
    return True, content, preview, subject


# ── Vaultix email button opens modal ─────────────────────────────────────────

@app.callback(
    Output("vaultix_email_modal","is_open", allow_duplicate=True),
    Output("vaultix_email_content","data", allow_duplicate=True),
    Output("vaultix_email_preview","children", allow_duplicate=True),
    Output("vaultix_email_subject","value", allow_duplicate=True),
    Input({"type":"vaultix_email_btn","index":ALL},"n_clicks"),
    State("slm_history","data"),
    prevent_initial_call=True)
def cb_open_vaultix_email(clicks, history):
    if not ctx.triggered_id or not any(c for c in (clicks or []) if c):
        return (dash.no_update,)*4
    triggered_idx = (ctx.triggered_id.get("index",0)
                     if isinstance(ctx.triggered_id,dict) else 0)
    if not history or triggered_idx >= len(history):
        return (dash.no_update,)*4
    h       = history[triggered_idx]
    q_text  = h.get("q","")
    a_text  = str(h.get("a",""))
    a_html  = h.get("a_html", a_text)
    intent  = h.get("intent","")
    server  = str(h.get("server","fleet") or "fleet")
    ts_str  = datetime.now().strftime("%Y-%m-%d %H:%M")
    subject = (f"NBU-CTS Ops Alert — {intent.upper()} — "
               f"{server.upper()} — {datetime.now().strftime('%d %b %Y %H:%M')}")
    content = json.dumps({
        "type":     "vaultix_answer",
        "question":  q_text,
        "answer":    a_text[:2000],
        "answer_html": a_html[:8000],
        "intent":    intent,
        "server":    server,
        "ts":        ts_str,
    })
    preview = html.Div([
        html.Div(f"Q: {q_text[:100]}",
            style={"fontWeight":"600","fontSize":"10px","marginBottom":"3px"}),
        html.Div(f"A: {a_text[:180]}...",
            style={"color":"#64748b","fontSize":"10px"}),
    ])
    return True, content, preview, subject


# ── Send email with professional HTML report ──────────────────────────────────

@app.callback(
    Output("vaultix_email_status","children"),
    Output("vaultix_email_modal","is_open", allow_duplicate=True),
    Input("vaultix_email_send_btn","n_clicks"),
    State("vaultix_email_to","value"),
    State("vaultix_email_subject","value"),
    State("vaultix_email_content","data"),
    prevent_initial_call=True)
def cb_send_vaultix_email(n, to_addr, subject, content_json):
    if not n: return dash.no_update, dash.no_update
    if not to_addr: return "⚠️ Enter recipient email", True
    try:
        recipients = [r.strip() for r in to_addr.replace(","," ").split()
                      if "@" in r]
        if not recipients:
            return "⚠️ Invalid email address", True

        data    = json.loads(content_json) if content_json else {}
        q_text      = data.get("question","")
        a_text      = data.get("answer","")
        answer_html = data.get("answer_html","")
        intent      = data.get("intent","")
        server      = data.get("server","fleet")
        ts_now      = datetime.now().strftime("%A, %d %B %Y at %H:%M")

        intent_labels = {
            "lag":       ("Duplication Queue",  "#E24B4A"),
            "diskpool":  ("Storage Pools",      "#185FA5"),
            "3rdsite":   ("External Airgap Vault","#639922"),
            "catalog":   ("Catalog Health",     "#854F0B"),
            "airgap":    ("Internal Airgap",    "#7C3AED"),
            "fleet":     ("Fleet Overview",     "#1e3a5f"),
            "media":     ("Media Servers",      "#0891B2"),
        }
        intent_lbl, intent_color = intent_labels.get(intent, ("Vaultix AI","#1e3a5f"))

        # Build clean email table from DB based on intent
        import sqlite3 as _sq2
        def _th(t): return f'<th style="background:#1e3a5f;color:#fff;padding:7px 10px;text-align:left;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;white-space:nowrap;">{t}</th>'
        def _td(t,c="#334155",b=False): fw="font-weight:500;" if b else ""; return f'<td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:11px;color:{c};{fw}vertical-align:middle;">{t}</td>'
        def _tbl(headers, rows):
            thead = "<tr>"+"".join(_th(h) for h in headers)+"</tr>"
            tbody = "".join("<tr>"+"".join(r)+"</tr>" for r in rows)
            return (f'<table cellpadding="0" cellspacing="0" width="100%" '
                    f'style="border-collapse:collapse;width:100%;margin-top:8px;">'
                    f'<thead>{thead}</thead><tbody>{tbody}</tbody></table>')
        def _kpi(items):
            cells = "".join(
                f'<td width="{100//len(items)}%" style="padding:0 4px 10px 0;vertical-align:top;">'
                f'<div style="background:#f8fafc;border-radius:8px;padding:10px 12px;border-left:3px solid {ac};">'
                f'<div style="font-size:18px;font-weight:500;color:{ac};line-height:1;">{v}</div>'
                f'<div style="font-size:10px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.4px;margin-top:3px;">{l}</div>'
                f'</div></td>'
                for l,v,ac in items)
            return f'<table width="100%" cellpadding="0" cellspacing="0"><tr>{cells}</tr></table>'

        try:
            con2 = _sq2.connect(DB_UNIFIED)
            if intent == "3rdsite":
                kpis = con2.execute("""
                    SELECT ROUND(SUM(total_data_tb),3), ROUND(AVG(avg_dedup_percent),1),
                           COUNT(*), SUM(CASE WHEN max_worm_days<30 THEN 1 ELSE 0 END)
                    FROM thirdsite_summary
                    WHERE report_date=(SELECT MAX(report_date) FROM thirdsite_summary)
                """).fetchone()
                rows_db = con2.execute("""
                    SELECT server_name, ROUND(total_data_tb,3),
                           ROUND(avg_gbps,4), ROUND(avg_dedup_percent,1),
                           ROUND(max_worm_days,0),
                           CASE WHEN max_worm_days>=30 THEN 'OK' ELSE 'LOW' END,
                           CASE WHEN avg_dedup_percent>=80 THEN 'GOOD' ELSE 'LOW' END
                    FROM thirdsite_summary
                    WHERE report_date=(SELECT MAX(report_date) FROM thirdsite_summary)
                    ORDER BY avg_dedup_percent DESC
                """).fetchall()
                kpi_html = _kpi([
                    ("Vaulted (TB)", kpis[0] or 0, "#185FA5"),
                    ("Vault dedup",  f"{kpis[1] or 0}%", "#639922"),
                    ("Servers",      kpis[2] or 0, "#185FA5"),
                    ("WORM <30d",    kpis[3] or 0, "#E24B4A"),
                ])
                tbl_html = _tbl(
                    ["Server","Vaulted TB","Avg GB/s","Dedup %","WORM days","WORM","Dedup status"],
                    [[_td(r[0].replace("cbkms","")),
                      _td(r[1]),_td(r[2]),
                      _td(f"{r[3]}%","#E24B4A" if r[3]<80 else "#639922",True),
                      _td(f"{int(r[4])}d" if r[4] else "—"),
                      _td(r[5],"#3B6D11" if r[5]=="OK" else "#A32D2D"),
                      _td(r[6],"#3B6D11" if r[6]=="GOOD" else "#A32D2D")]
                     for r in rows_db])
                response_block = kpi_html + tbl_html

            elif intent == "diskpool":
                rows_db = con2.execute("""
                    SELECT server_name, diskpool,
                           ROUND(used_tb,2), ROUND(total_tb,2),
                           ROUND(pct_used,1), health, status
                    FROM diskpool_daily
                    WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily)
                    AND server_name LIKE ?
                    ORDER BY pct_used DESC LIMIT 20
                """, (f"%{server}%" if server and server!="fleet" else "%",)).fetchall()
                tbl_html = _tbl(
                    ["Server","Pool","Used TB","Total TB","% Used","Health","Status"],
                    [[_td(r[0].replace("cbkms","")),
                      _td(r[1][:25]+"…" if len(r[1])>25 else r[1]),
                      _td(r[2]),_td(r[3]),
                      _td(f"{r[4]}%","#E24B4A" if r[4]>=85 else "#EF9F27" if r[4]>=70 else "#334155",True),
                      _td(r[5],"#E24B4A" if r[5]=="CRITICAL" else "#EF9F27" if r[5]=="WARNING" else "#3B6D11"),
                      _td(r[6],"#E24B4A" if r[6]=="Down" else "#3B6D11")]
                     for r in rows_db])
                response_block = tbl_html

            elif intent == "lag":
                rows_db = con2.execute("""
                    SELECT server_name, total, above_sla,
                           not_started_duplicate, in_process_duplicate, delta_1d
                    FROM lag_history
                    WHERE date=(SELECT MAX(date) FROM lag_history)
                    ORDER BY total DESC
                """).fetchall()
                tbl_html = _tbl(
                    ["Server","Total queue","Above SLA","Not started","In process","Delta 1d"],
                    [[_td(r[0].replace("cbkms","")),
                      _td(f"{r[1]:,}","#E24B4A" if r[1]>10000 else "#334155",True),
                      _td(r[2],"#E24B4A" if r[2]>0 else "#3B6D11"),
                      _td(f"{r[3]:,}"),_td(f"{r[4]:,}"),
                      _td(f"{r[5]:+,}" if r[5] else "—")]
                     for r in rows_db])
                response_block = tbl_html

            elif intent == "catalog":
                rows_db = con2.execute("""
                    SELECT server_name, cat_status, cat_health_score,
                           cat_anomaly, cat_anomaly_reason
                    FROM v_server_latest ORDER BY cat_health_score
                """).fetchall()
                tbl_html = _tbl(
                    ["Server","Status","Health score","Anomaly","Reason"],
                    [[_td(r[0].replace("cbkms","")),
                      _td(r[1],"#E24B4A" if r[1]=="ERROR" else "#3B6D11"),
                      _td(f"{r[2]}/100","#E24B4A" if (r[2] or 100)<50 else "#334155"),
                      _td("Yes" if r[3] else "No","#E24B4A" if r[3] else "#3B6D11"),
                      _td(r[4] or "—")]
                     for r in rows_db])
                response_block = tbl_html

            elif intent == "airgap":
                rows_db = con2.execute("""
                    SELECT server_name, ag_status, ag_repl_active,
                           ag_weekly_ok, ag_monthly_ok, ag_yearly_ok
                    FROM v_server_latest ORDER BY server_name
                """).fetchall()
                tbl_html = _tbl(
                    ["Server","Status","Repl active","Weekly","Monthly","Yearly"],
                    [[_td(r[0].replace("cbkms","")),
                      _td(r[1],"#E24B4A" if r[1]=="Not Working" else "#3B6D11"),
                      _td("Yes" if r[2] else "No","#3B6D11" if r[2] else "#E24B4A"),
                      _td("OK" if r[3] else "FAIL","#3B6D11" if r[3] else "#E24B4A"),
                      _td("OK" if r[4] else "FAIL","#3B6D11" if r[4] else "#E24B4A"),
                      _td("OK" if r[5] else "FAIL","#3B6D11" if r[5] else "#E24B4A")]
                     for r in rows_db])
                response_block = tbl_html

            else:
                # Generic — use plain text summary
                import re as _re
                clean = _re.sub(r'<[^>]+>', ' ', a_text)
                clean = _re.sub(r'\s+', ' ', clean).strip()
                response_block = f'<div style="font-size:12px;color:#334155;line-height:1.7;">{clean}</div>'
            con2.close()
        except Exception as _ex:
            import re as _re
            clean = _re.sub(r'<[^>]+>', ' ', a_text)
            clean = _re.sub(r'\s+', ' ', clean).strip()
            response_block = f'<div style="font-size:12px;color:#334155;line-height:1.7;">{clean}</div>'
        html_body = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body style="margin:0;padding:0;background:#f8fafc;
             font-family:system-ui,-apple-system,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0">
<tr><td align="center" style="padding:24px 16px;">
<table width="680" cellpadding="0" cellspacing="0"
       style="background:#fff;border-radius:12px;
              border:1px solid #e2e8f0;overflow:hidden;">

  <tr><td style="background:#1e3a5f;padding:20px 28px;">
    <table width="100%"><tr>
      <td>
        <div style="color:#93c5fd;font-size:10px;letter-spacing:1px;
                    text-transform:uppercase;margin-bottom:4px;">
          NetBackup CTS — Global Operations</div>
        <div style="color:#fff;font-size:17px;font-weight:500;">
          {intent_lbl} Report</div>
        <div style="color:rgba(255,255,255,0.5);font-size:11px;margin-top:4px;">
          Server: {server.upper()} · {ts_now}</div>
      </td>
      <td align="right">
        <div style="background:rgba(255,255,255,0.12);border-radius:8px;
                    padding:8px 14px;text-align:center;display:inline-block;">
          <div style="color:#fff;font-size:18px;">🔷</div>
          <div style="color:rgba(255,255,255,0.6);font-size:9px;
                      margin-top:2px;">Vaultix AI</div>
        </div>
      </td>
    </tr></table>
  </td></tr>

  <tr><td style="padding:16px 28px;border-bottom:1px solid #f1f5f9;">
    <div style="font-size:10px;text-transform:uppercase;letter-spacing:0.6px;
                color:#94a3b8;margin-bottom:6px;">Query</div>
    <div style="font-size:13px;color:#1e293b;font-weight:500;
                padding:10px 14px;background:#f8fafc;border-radius:8px;
                border-left:3px solid {intent_color};">
      {q_text}</div>
    <div style="font-size:10px;color:#94a3b8;margin-top:6px;">
      Intent: {intent_lbl} · Scope: {server.upper()}
      · {datetime.now().strftime("%Y-%m-%d %H:%M")}</div>
  </td></tr>

  <tr><td style="padding:16px 28px;border-bottom:1px solid #f1f5f9;">
    <div style="font-size:10px;text-transform:uppercase;letter-spacing:0.6px;
                color:#94a3b8;margin-bottom:10px;">Response</div>
    <div style="overflow-x:auto;">{response_block}</div>
  </td></tr>

  <tr><td style="background:#f8fafc;padding:14px 28px;
                 border-radius:0 0 12px 12px;border-top:1px solid #e2e8f0;">
    <div style="font-size:11px;color:#94a3b8;">
      Auto-generated by
      <strong style="color:#1e3a5f;">Vaultix AI</strong>
      &nbsp;&middot;&nbsp; NBU-CTS &nbsp;&middot;&nbsp; {ts_now}<br>
      Do not reply to this email.
    </div>
  </td></tr>

</table></td></tr></table>
</body></html>"""

        import smtplib
        from email.mime.multipart import MIMEMultipart as _MIME
        from email.mime.text import MIMEText as _MIMEText
        msg = _MIME("alternative")
        msg["Subject"] = subject
        msg["From"]    = "noreply@nbu-cts.cts.com"
        msg["To"]      = ", ".join(recipients)
        msg.attach(_MIMEText(html_body, "html", "utf-8"))
        with smtplib.SMTP("localhost", 25, timeout=10) as srv:
            srv.sendmail(msg["From"], recipients, msg.as_string())
        logger.info(f"Vaultix email sent to {recipients} intent={intent}")
        return f"✅ Sent to {', '.join(recipients)}", False
    except Exception as e:
        logger.error(f"cb_send_vaultix_email error: {e}")
        return f"❌ Error: {e}", True


@app.callback(
    Output("main_content","children"),
    Input("main_tabs","active_tab"),
    State("master_filter_store","data"))
def render_tab(tab, filter_data=None):
    filter_data = {"master":"all","status":"all"}
    fd      = filter_data or {}
    master_f = fd.get("master","all")
    status_f = fd.get("status","all")
    TAB_MAP = {
        "tab_home":     lambda: tab_home(),
        "tab_ai":       lambda: tab_ai(),
        "tab_bj":       lambda: tab_backup_jobs(),
        "tab_media":    lambda: tab_media_servers(master_f=master_f, status_f=status_f),
        "tab_lag":      lambda: tab_lag(master_f=master_f),
        "tab_dp":       lambda: tab_diskpool(master_f=master_f),
        "tab_3rd":      lambda: tab_3rdsite(master_f=master_f),
        "tab_cat":      lambda: tab_catalog(master_f=master_f),
        "tab_ag":       lambda: tab_airgap(master_f=master_f),
        "tab_report":   lambda: tab_report(),
        "tab_slp":      lambda: tab_slp(),
        "tab_slm":      lambda: tab_slm(),

    }
    fn = TAB_MAP.get(tab)
    return fn() if fn else html.Div("Select a tab.")




@app.callback(
    Output("master_filter_store","data"),
    Input({"type":"master_filter_dd","index":ALL},"value"),
    Input("ms_master_filter","value"),
    Input("ms_status_filter","value"),
    State("master_filter_store","data"),
    prevent_initial_call=True)
def cb_update_filter_store(tab_filter_vals, ms_master, ms_status, current):
    if not ctx.triggered_id: return dash.no_update
    fd = dict(current or {"master":"all","status":"all"})
    tid = ctx.triggered_id

    # Tab export bar filter changed
    if isinstance(tid, dict) and tid.get("type") == "master_filter_dd":
        val = ctx.triggered[0]["value"]
        if val: fd["master"] = val
        return fd

    # Media server specific filters
    prop = ctx.triggered[0]["prop_id"] if ctx.triggered else ""
    if "ms_master_filter" in prop and ms_master:
        fd["master"] = ms_master
    if "ms_status_filter" in prop and ms_status:
        fd["status"] = ms_status
    return fd

# ══════════════════════════════════════════════════════════════════════════════
# REPORTING CENTRE — tab_report
# ══════════════════════════════════════════════════════════════════════════════
def tab_report():
    """Enterprise Reporting Centre — live data, filters, CSV export, print/PDF."""
    import sqlite3 as _sq, json as _js

    try:
        _con = _sq.connect(DB_UNIFIED)
        _lag = _con.execute("SELECT server_name,total,above_sla,delta_1d,date FROM lag_history WHERE date=(SELECT MAX(date) FROM lag_history) ORDER BY total DESC").fetchall()
        _dp  = _con.execute("SELECT server_name,diskpool,ROUND(used_tb,2),ROUND(total_tb,2),ROUND(pct_used,1),health,status FROM diskpool_daily WHERE run_date=(SELECT MAX(run_date) FROM diskpool_daily) AND diskpool_group!='Recovery Vault' ORDER BY pct_used DESC LIMIT 60").fetchall()
        _ts  = _con.execute("SELECT server_name,ROUND(total_data_tb,3),ROUND(avg_dedup_percent,1),max_worm_days,dup_not_started FROM thirdsite_summary WHERE report_date=(SELECT MAX(report_date) FROM thirdsite_summary) ORDER BY avg_dedup_percent ASC").fetchall()
        _ag  = _con.execute("SELECT server_name,ag_status,ag_repl_active,ag_weekly_ok,ag_monthly_ok,ag_yearly_ok,ag_image_count FROM v_server_latest ORDER BY server_name").fetchall()
        _cat = _con.execute("SELECT server_name,cat_status,cat_health_score,cat_anomaly_reason FROM v_server_latest ORDER BY cat_health_score ASC").fetchall()
        _bj  = _con.execute("SELECT server_name,schedule,total_jobs,success_jobs,failed_jobs,ROUND(success_rate,1) FROM backup_jobs_summary WHERE report_date=(SELECT MAX(report_date) FROM backup_jobs_summary WHERE total_jobs>0) ORDER BY failed_jobs DESC,total_jobs DESC").fetchall()
        _rv  = _con.execute("SELECT ROUND(SUM(used_tb),1) FROM diskpool_daily WHERE diskpool_group='Recovery Vault' AND run_date=(SELECT MAX(run_date) FROM diskpool_daily WHERE diskpool_group='Recovery Vault')").fetchone()[0] or 0
        _lt  = _con.execute("SELECT date,SUM(total) FROM lag_history GROUP BY date ORDER BY date DESC LIMIT 14").fetchall()[::-1]
        _rt  = _con.execute("SELECT run_date,ROUND(SUM(used_tb),1) FROM diskpool_daily WHERE diskpool_group='Recovery Vault' GROUP BY run_date ORDER BY run_date DESC LIMIT 14").fetchall()[::-1]
        _srvs= _con.execute("SELECT name FROM servers ORDER BY name").fetchall()
        _con.close()
    except Exception as _e:
        return html.Div(f"Reports error: {_e}", style={"padding":"20px","color":"#E24B4A"})

    _lt_v = int(sum(r[1] or 0 for r in _lag))
    _pd_v = sum(1 for r in _dp if r[6]=="Down")
    _pc_v = sum(1 for r in _dp if r[5]=="CRITICAL")
    _rv_p = round(_rv/910*100,1)
    _ag_d = sum(1 for r in _ag if r[1]=="Not Working")
    _ce_v = sum(1 for r in _cat if r[1]=="ERROR")
    _bj_t = sum(r[2] or 0 for r in _bj)
    _bj_o = sum(r[3] or 0 for r in _bj)
    _bj_f = sum(r[4] or 0 for r in _bj)
    _bj_r = round(_bj_o/max(_bj_t,1)*100,1)
    _date = _lag[0][4] if _lag else "—"
    _ts_p = sum(r[4] or 0 for r in _ts)
    _cat_avg = round(sum(r[2] or 0 for r in _cat)/max(len(_cat),1))

    _lag_j = _js.dumps([{"s":r[0].replace("cbkms",""),"t":r[1] or 0,"a":r[2] or 0,"d":r[3] or 0} for r in _lag])
    _dp_j  = _js.dumps([{"s":r[0].replace("cbkms",""),"p":r[1],"u":r[2] or 0,"tot":r[3] or 0,"pct":r[4] or 0,"h":r[5] or "","st":r[6] or ""} for r in _dp])
    _ts_j  = _js.dumps([{"s":r[0].replace("cbkms",""),"tb":r[1] or 0,"d":r[2] or 0,"w":r[3] or 0,"pend":r[4] or 0} for r in _ts])
    _ag_j  = _js.dumps([{"s":r[0].replace("cbkms",""),"st":r[1] or "","ra":bool(r[2]),"wk":bool(r[3]),"mo":bool(r[4]),"yr":bool(r[5]),"img":r[6] or 0} for r in _ag])
    _cat_j = _js.dumps([{"s":r[0].replace("cbkms",""),"st":r[1] or "","sc":r[2] or 0,"reason":r[3] or ""} for r in _cat])
    _bj_j  = _js.dumps([{"s":r[0].replace("cbkms",""),"sch":r[1] or "","tot":r[2] or 0,"ok":r[3] or 0,"fail":r[4] or 0,"rate":r[5] or 0} for r in _bj])
    _lt_j  = _js.dumps([[r[0],int(r[1] or 0)] for r in _lt])
    _rt_j  = _js.dumps([[r[0],float(r[1] or 0)] for r in _rt])
    _srv_o = "".join(f'<option value="{r[0].replace("cbkms","")}">{r[0].replace("cbkms","").upper()}</option>' for r in _srvs)

    # KPI color helpers
    def _c(v,hi,lo): return "#A32D2D" if v>hi else "#854F0B" if v>lo else "#3B6D11"
    def _bc(v,hi,lo): return "#E24B4A" if v>hi else "#EF9F27" if v>lo else "#639922"

    _lag_c  = _c(_lt_v,50000,10000)
    _lag_bc = _bc(_lt_v,50000,10000)
    _pd_c   = "#A32D2D" if _pd_v>0 else "#3B6D11"
    _pd_bc  = "#E24B4A" if _pd_v>0 else "#639922"
    _rv_c   = "#A32D2D" if _rv_p>90 else "#854F0B" if _rv_p>70 else "#185FA5"
    _rv_bc  = "#E24B4A" if _rv_p>90 else "#EF9F27" if _rv_p>70 else "#185FA5"
    _ag_c   = "#A32D2D" if _ag_d>0 else "#3B6D11"
    _ag_bc  = "#E24B4A" if _ag_d>0 else "#639922"
    _ce_c   = "#A32D2D" if _ce_v>0 else "#3B6D11"
    _ce_bc  = "#E24B4A" if _ce_v>0 else "#639922"
    _bj_c   = "#A32D2D" if _bj_r<90 else "#3B6D11"
    _bj_bc  = "#E24B4A" if _bj_r<90 else "#639922"
    _ts_c   = "#A32D2D" if _ts_p>0 else "#3B6D11"
    _ts_bc  = "#E24B4A" if _ts_p>0 else "#639922"

    _h = (
        "<!DOCTYPE html><html><head><meta charset='utf-8'><style>"
        "*{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,-apple-system,sans-serif;}"
        "body{background:#f0f2f7;color:#1e293b;font-size:13px;}"
        ".topbar{background:#1A3C5E;color:#fff;padding:12px 20px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;}"
        ".topbar-title{font-size:14px;font-weight:600;}"
        ".topbar-meta{font-size:11px;color:#94a3b8;margin-top:2px;}"
        ".tabs{display:flex;gap:2px;padding:0 20px;background:#1A3C5E;}"
        ".tab{padding:8px 14px;font-size:11px;font-weight:500;color:#94a3b8;cursor:pointer;border-radius:6px 6px 0 0;border:none;background:transparent;}"
        ".tab.active{background:#f0f2f7;color:#1A3C5E;font-weight:600;}"
        ".content{padding:14px 20px;}"
        ".section{display:none;}.section.active{display:block;}"
        ".kg{display:grid;gap:10px;margin-bottom:14px;}"
        ".kpi{background:#fff;border:0.5px solid #e2e8f0;border-radius:10px;padding:12px 14px;}"
        ".kv{font-size:22px;font-weight:600;line-height:1;}"
        ".kl{font-size:10px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.4px;margin:4px 0 3px;}"
        ".ks{font-size:11px;font-weight:500;}"
        ".card{background:#fff;border:0.5px solid #e2e8f0;border-radius:10px;overflow:hidden;margin-bottom:12px;}"
        ".ch{padding:11px 16px;border-bottom:0.5px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;}"
        ".ct{font-size:12px;font-weight:500;}.cm{font-size:11px;color:#94a3b8;}"
        ".tw{overflow-x:auto;}"
        "table{width:100%;border-collapse:collapse;font-size:11px;}"
        "th{padding:7px 12px;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;font-weight:500;color:#64748b;background:#f8fafc;border-bottom:0.5px solid #e2e8f0;white-space:nowrap;}"
        "th.r{text-align:right;}th.c{text-align:center;}"
        "td{padding:7px 12px;border-bottom:0.5px solid #f8fafc;white-space:nowrap;}"
        "td.r{text-align:right;}td.c{text-align:center;}td.m{font-family:monospace;font-size:10px;color:#64748b;}"
        "tr:last-child td{border-bottom:none;}tr:hover td{background:#fafafa;}"
        ".pill{display:inline-block;font-size:10px;font-weight:500;padding:2px 8px;border-radius:20px;}"
        ".pr{background:#FCEBEB;color:#A32D2D;}.pa{background:#FAEEDA;color:#854F0B;}"
        ".pg{background:#EAF3DE;color:#3B6D11;}.pb{background:#E6F1FB;color:#185FA5;}.py{background:#f1f5f9;color:#64748b;}"
        ".tb{display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap;}"
        ".tbtn{padding:5px 12px;border-radius:6px;border:0.5px solid #e2e8f0;background:#fff;color:#475569;font-size:11px;cursor:pointer;font-weight:500;}"
        ".tbtn:hover{background:#f8fafc;}.tbtn.p{background:#1A3C5E;color:#fff;border-color:#1A3C5E;}"
        ".fr{display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap;}"
        ".fl{font-size:10px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.4px;}"
        "select{padding:5px 10px;border-radius:6px;border:0.5px solid #e2e8f0;background:#fff;font-size:11px;color:#334155;}"
        ".g2{display:grid;grid-template-columns:1fr 1fr;gap:12px;}"
        ".ar{display:flex;gap:10px;align-items:flex-start;padding:12px 16px;border-bottom:0.5px solid #f1f5f9;}"
        ".an{width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;flex-shrink:0;}"
        ".at{font-size:12px;font-weight:500;margin-bottom:3px;}.as{font-size:11px;color:#64748b;}"
        ".badge{font-size:9px;font-weight:600;padding:1px 6px;border-radius:4px;margin-right:5px;}"
        "</style></head><body>"
        f"<div class='topbar'><div><div class='topbar-title'>NBU Backup CTS — Reporting Centre</div>"
        f"<div class='topbar-meta'>{_date} · 14 master servers · live data</div></div>"
        f"<div style='display:flex;gap:8px;'><button class='tbtn' onclick='exportCSV()'>⬇ Export CSV</button>"
        f"<button class='tbtn p' onclick='printSection(\"sec-overview\")'>🖨 Print/PDF</button></div></div>"
        "<div class='tabs'>"
        "<button class='tab active' onclick='showTab(\"overview\",this)'>Overview</button>"
        "<button class='tab' onclick='showTab(\"lag\",this)'>Dup Queue</button>"
        "<button class='tab' onclick='showTab(\"pools\",this)'>Storage Pools</button>"
        "<button class='tab' onclick='showTab(\"vault\",this)'>Ext Airgap Vault</button>"
        "<button class='tab' onclick='showTab(\"airgap\",this)'>Int Airgap</button>"
        "<button class='tab' onclick='showTab(\"catalog\",this)'>Catalog</button>"
        "<button class='tab' onclick='showTab(\"backupjobs\",this)'>Backup Jobs</button>"
        "<button class='tab' onclick='showTab(\"alerts\",this)'>⚠ Action Items</button>"
        "</div><div class='content'>"
        # OVERVIEW
        "<div class='section active' id='sec-overview'>"
        f"<div class='kg' style='grid-template-columns:repeat(6,1fr);'>"
        f"<div class='kpi' style='border-left:3px solid {_lag_bc};'><div class='kv' style='color:{_lag_c};'>{_lt_v:,}</div><div class='kl'>Dup queue</div><div class='ks' style='color:#64748b;'>fleet images</div></div>"
        f"<div class='kpi' style='border-left:3px solid {_pd_bc};'><div class='kv' style='color:{_pd_c};'>{_pd_v}</div><div class='kl'>Pools down</div><div class='ks' style='color:#64748b;'>{_pc_v} critical</div></div>"
        f"<div class='kpi' style='border-left:3px solid {_rv_bc};'><div class='kv' style='color:{_rv_c};'>{_rv} TB</div><div class='kl'>Recovery vault</div><div class='ks' style='color:{_rv_c};'>{_rv_p}% of 910 TB</div></div>"
        f"<div class='kpi' style='border-left:3px solid {_ag_bc};'><div class='kv' style='color:{_ag_c};'>{_ag_d}</div><div class='kl'>Airgap down</div><div class='ks' style='color:#64748b;'>{len(_ag)-_ag_d} working</div></div>"
        f"<div class='kpi' style='border-left:3px solid {_ce_bc};'><div class='kv' style='color:{_ce_c};'>{_ce_v}</div><div class='kl'>Catalog errors</div><div class='ks' style='color:#64748b;'>{len(_cat)-_ce_v} healthy</div></div>"
        f"<div class='kpi' style='border-left:3px solid {_bj_bc};'><div class='kv' style='color:{_bj_c};'>{_bj_r}%</div><div class='kl'>Job success</div><div class='ks' style='color:#64748b;'>{_bj_o:,}/{_bj_t:,}</div></div>"
        "</div>"
        "<div class='g2'>"
        "<div class='card'><div class='ch'><div class='ct'>📉 Dup queue — 14 day trend</div><div class='cm'>fleet total</div></div><div id='lag-chart' style='padding:12px 16px 8px;'></div></div>"
        "<div class='card'><div class='ch'><div class='ct'>💽 Recovery vault — 14 day trend</div><div class='cm'>TB used</div></div><div id='rv-chart' style='padding:12px 16px 8px;'></div></div>"
        "</div>"
        "<div class='card'><div class='ch'><div class='ct'>🌐 Fleet health matrix</div><div class='cm'>all 14 masters · latest data</div></div>"
        "<div class='tw'><table><thead><tr><th>Server</th><th class='r'>Dup queue</th><th class='r'>Δ 1d</th><th class='r'>Pools down</th><th class='c'>Airgap</th><th class='c'>Catalog</th><th class='r'>Health</th></tr></thead><tbody id='overview-tbody'></tbody></table></div></div>"
        "</div>"
        # LAG
        "<div class='section' id='sec-lag'>"
        "<div class='tb'><button class='tbtn' onclick=\"exportTableCSV('lag-tbody','duplication_queue.csv')\">⬇ CSV</button><button class='tbtn' onclick=\"printSection('sec-lag')\">🖨 Print/PDF</button></div>"
        f"<div class='card'><div class='ch'><div class='ct'>📉 Duplication queue — all servers</div><div class='cm'>{_date} · fleet: {_lt_v:,}</div></div>"
        "<div class='tw'><table><thead><tr><th>Server</th><th class='r'>Total</th><th class='r'>Above SLA</th><th class='r'>Δ 1d</th><th class='c'>Status</th></tr></thead><tbody id='lag-tbody'></tbody></table></div></div>"
        "</div>"
        # POOLS
        "<div class='section' id='sec-pools'>"
        "<div class='fr'><span class='fl'>Filter:</span>"
        "<select id='dp-filter' onchange='renderPools()'><option value='all'>All pools</option><option value='down'>Down only</option><option value='critical'>Critical only</option><option value='warning'>Warning+</option></select>"
        f"<select id='dp-server' onchange='renderPools()'><option value='all'>All servers</option>{_srv_o}</select>"
        "<button class='tbtn' onclick=\"exportTableCSV('dp-tbody','storage_pools.csv')\">⬇ CSV</button>"
        "<button class='tbtn' onclick=\"printSection('sec-pools')\">🖨 Print/PDF</button></div>"
        f"<div class='card'><div class='ch'><div class='ct'>💽 Storage pools</div><div class='cm' id='dp-meta'>{len(_dp)} pools · {_pd_v} down · {_pc_v} critical</div></div>"
        "<div class='tw'><table><thead><tr><th>Server</th><th>Pool</th><th class='r'>Used TB</th><th class='r'>Total TB</th><th class='r'>% Used</th><th class='c'>Health</th><th class='c'>Status</th></tr></thead><tbody id='dp-tbody'></tbody></table></div></div>"
        "</div>"
        # VAULT
        "<div class='section' id='sec-vault'>"
        "<div class='tb'><button class='tbtn' onclick=\"exportTableCSV('ts-tbody','ext_airgap.csv')\">⬇ CSV</button><button class='tbtn' onclick=\"printSection('sec-vault')\">🖨 Print/PDF</button></div>"
        f"<div class='kg' style='grid-template-columns:repeat(3,1fr);margin-bottom:12px;'>"
        f"<div class='kpi' style='border-left:3px solid {_rv_bc};'><div class='kv' style='color:#185FA5;'>{_rv} TB</div><div class='kl'>Vault used</div><div class='ks' style='color:{_rv_c};'>{_rv_p}% of 910 TB</div></div>"
        f"<div class='kpi' style='border-left:3px solid #639922;'><div class='kv'>{len(_ts)}</div><div class='kl'>Servers vaulting</div><div class='ks' style='color:#64748b;'>active replication</div></div>"
        f"<div class='kpi' style='border-left:3px solid {_ts_bc};'><div class='kv' style='color:{_ts_c};'>{_ts_p:,}</div><div class='kl'>Pending images</div><div class='ks' style='color:#64748b;'>dup not started</div></div>"
        "</div>"
        f"<div class='card'><div class='ch'><div class='ct'>🌐 External Airgap Vault</div><div class='cm'>{_rv} TB / 910 TB ({_rv_p}%)</div></div>"
        "<div class='tw'><table><thead><tr><th>Server</th><th class='r'>Vaulted TB</th><th class='r'>Dedup %</th><th class='r'>WORM days</th><th class='r'>Pending</th><th class='c'>Status</th></tr></thead><tbody id='ts-tbody'></tbody></table></div></div>"
        "</div>"
        # AIRGAP
        "<div class='section' id='sec-airgap'>"
        "<div class='tb'><button class='tbtn' onclick=\"exportTableCSV('ag-tbody','int_airgap.csv')\">⬇ CSV</button><button class='tbtn' onclick=\"printSection('sec-airgap')\">🖨 Print/PDF</button></div>"
        f"<div class='card'><div class='ch'><div class='ct'>🔒 Internal Airgap Vault</div><div class='cm'>{_ag_d} not working · {len(_ag)-_ag_d} healthy</div></div>"
        "<div class='tw'><table><thead><tr><th>Server</th><th class='c'>Status</th><th class='r'>Backlog</th><th class='c'>Repl</th><th class='c'>Weekly</th><th class='c'>Monthly</th><th class='c'>Yearly</th></tr></thead><tbody id='ag-tbody'></tbody></table></div></div>"
        "</div>"
        # CATALOG
        "<div class='section' id='sec-catalog'>"
        "<div class='tb'><button class='tbtn' onclick=\"exportTableCSV('cat-tbody','catalog.csv')\">⬇ CSV</button><button class='tbtn' onclick=\"printSection('sec-catalog')\">🖨 Print/PDF</button></div>"
        f"<div class='card'><div class='ch'><div class='ct'>📋 Catalog health</div><div class='cm'>{_ce_v} errors · avg score {_cat_avg}/100</div></div>"
        "<div class='tw'><table><thead><tr><th>Server</th><th class='c'>Status</th><th class='r'>Score</th><th>Anomaly</th></tr></thead><tbody id='cat-tbody'></tbody></table></div></div>"
        "</div>"
        # BACKUP JOBS
        "<div class='section' id='sec-backupjobs'>"
        "<div class='fr'><span class='fl'>Schedule:</span>"
        "<select id='bj-filter' onchange='renderBJ()'><option value='all'>All</option><option value='daily'>Daily</option><option value='weekly'>Weekly</option><option value='full'>Full</option></select>"
        "<button class='tbtn' onclick=\"exportTableCSV('bj-tbody','backup_jobs.csv')\">⬇ CSV</button>"
        "<button class='tbtn' onclick=\"printSection('sec-backupjobs')\">🖨 Print/PDF</button></div>"
        f"<div class='kg' style='grid-template-columns:repeat(4,1fr);margin-bottom:12px;'>"
        f"<div class='kpi' style='border-left:3px solid #185FA5;'><div class='kv'>{_bj_t:,}</div><div class='kl'>Total jobs</div></div>"
        f"<div class='kpi' style='border-left:3px solid #639922;'><div class='kv' style='color:#3B6D11;'>{_bj_o:,}</div><div class='kl'>Successful</div></div>"
        f"<div class='kpi' style='border-left:3px solid #E24B4A;'><div class='kv' style='color:#A32D2D;'>{_bj_f:,}</div><div class='kl'>Failed</div></div>"
        f"<div class='kpi' style='border-left:3px solid {_bj_bc};'><div class='kv' style='color:{_bj_c};'>{_bj_r}%</div><div class='kl'>Success rate</div></div>"
        "</div>"
        f"<div class='card'><div class='ch'><div class='ct'>📊 Backup jobs by server</div><div class='cm' id='bj-meta'>{_bj_t:,} total · {_bj_f:,} failed</div></div>"
        "<div class='tw'><table><thead><tr><th>Server</th><th>Schedule</th><th class='r'>Total</th><th class='r'>Success</th><th class='r'>Failed</th><th class='r'>Rate</th><th class='c'>Status</th></tr></thead><tbody id='bj-tbody'></tbody></table></div></div>"
        "</div>"
        # ALERTS
        "<div class='section' id='sec-alerts'>"
        "<div class='tb'><button class='tbtn' onclick=\"printSection('sec-alerts')\">🖨 Print/PDF</button></div>"
        "<div class='card'><div class='ch'><div class='ct'>⚠ Action items — prioritised</div><div class='cm'>auto-generated from live fleet data</div></div><div id='alerts-body'></div></div>"
        "</div>"
        "</div>" # content
        "<script>"
        f"var LAG={_lag_j};var DP={_dp_j};var TS={_ts_j};var AG={_ag_j};var CAT={_cat_j};var BJ={_bj_j};"
        f"var LT={_lt_j};var RT={_rt_j};"
        "function showTab(n,b){document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));document.getElementById('sec-'+n).classList.add('active');b.classList.add('active');renderAll();}"
        "function pill(t,c){return '<span class=\"pill '+c+'\">'+t+'</span>';}"
        "function sp(s){if(!s)return pill('—','py');var u=s.toUpperCase();if(u==='CRITICAL'||u==='DOWN'||u==='ERROR'||u==='NOT WORKING')return pill(s,'pr');if(u==='WARNING'||u==='ANOMALY')return pill(s,'pa');if(u==='OK'||u==='SUCCESS'||u==='WORKING'||u==='COMPLETED')return pill(s,'pg');return pill(s,'pb');}"
        "function ck(v){return v?'<span style=\"color:#3B6D11;font-weight:600;\">✓</span>':'<span style=\"color:#A32D2D;\">✗</span>';}"
        "function drawChart(id,data,color){var el=document.getElementById(id);if(!el||!data.length)return;var vals=data.map(r=>r[1]);var mx=Math.max(...vals)||1;var bars=data.map(function(r){var h=Math.max(4,Math.round(r[1]/mx*56));var d=r[0].slice(5);return '<div style=\"flex:1;display:flex;flex-direction:column;align-items:center;\"><div title=\"'+r[0]+': '+r[1]+'\" style=\"width:100%;height:'+h+'px;background:'+color+';border-radius:2px 2px 0 0;\"></div><div style=\"font-size:8px;color:#94a3b8;margin-top:2px;\">'+d+'</div></div>';}).join('');el.innerHTML='<div style=\"display:flex;align-items:flex-end;gap:2px;height:80px;\">'+bars+'</div>';}"
        "function renderOverview(){var pdMap={};DP.forEach(function(r){if(r.st==='Down')pdMap[r.s]=(pdMap[r.s]||0)+1;});var catMap={};CAT.forEach(function(r){catMap[r.s]={st:r.st,sc:r.sc};});var agMap={};AG.forEach(function(r){agMap[r.s]=r;});var html=LAG.map(function(r){var pd=pdMap[r.s]||0;var cat=catMap[r.s]||{};var ag=agMap[r.s]||{};var h=100-Math.round((r.t>50000?40:r.t>10000?20:0)+(pd>0?20:0)+(ag.st==='Not Working'?20:0)+(cat.st==='ERROR'?20:0));var hc=h>=80?'#3B6D11':h>=60?'#854F0B':'#A32D2D';var dlt=r.d>0?'<span style=\"color:#A32D2D;\">+'+r.d.toLocaleString()+'</span>':r.d<0?'<span style=\"color:#3B6D11;\">'+r.d.toLocaleString()+'</span>':'—';return '<tr><td class=\"m\" style=\"font-weight:500;\">'+r.s.toUpperCase()+'</td><td class=\"r\" style=\"font-weight:500;color:'+(r.t>30000?'#A32D2D':r.t>10000?'#854F0B':'#334155')+'\">'+r.t.toLocaleString()+'</td><td class=\"r\">'+dlt+'</td><td class=\"r\">'+(pd>0?'<span style=\"color:#A32D2D;font-weight:600;\">'+pd+'</span>':'<span style=\"color:#3B6D11;\">0</span>')+'</td><td class=\"c\">'+(ag.st?sp(ag.st):'—')+'</td><td class=\"c\">'+(cat.st?sp(cat.st):'—')+'</td><td class=\"r\" style=\"font-weight:600;color:'+hc+';\">'+h+'/100</td></tr>';}).join('');document.getElementById('overview-tbody').innerHTML=html;}"
        "function renderLag(){var html=LAG.map(function(r){var dlt=r.d>0?'<span style=\"color:#A32D2D;\">+'+r.d.toLocaleString()+'</span>':r.d<0?'<span style=\"color:#3B6D11;\">'+r.d.toLocaleString()+'</span>':'—';var st=r.t>30000?pill('CRITICAL','pr'):r.t>10000?pill('WARNING','pa'):pill('OK','pg');return '<tr style=\"background:'+(r.t>50000?'#FCEBEB':r.t>10000?'#FAEEDA':'#fff')+'\"><td class=\"m\" style=\"font-weight:500;\">'+r.s.toUpperCase()+'</td><td class=\"r\" style=\"font-weight:600;color:'+(r.t>30000?'#A32D2D':r.t>10000?'#854F0B':'#334155')+'\">'+r.t.toLocaleString()+'</td><td class=\"r\">'+r.a.toLocaleString()+'</td><td class=\"r\">'+dlt+'</td><td class=\"c\">'+st+'</td></tr>';}).join('');document.getElementById('lag-tbody').innerHTML=html;}"
        "function renderPools(){var filt=document.getElementById('dp-filter').value;var srv=document.getElementById('dp-server').value;var data=DP.filter(function(r){if(srv!=='all'&&r.s!==srv)return false;if(filt==='down')return r.st==='Down';if(filt==='critical')return r.h==='CRITICAL';if(filt==='warning')return r.h==='CRITICAL'||r.h==='WARNING';return true;});var html=data.map(function(r){var hc=r.h==='CRITICAL'?'#A32D2D':r.h==='WARNING'?'#854F0B':'#3B6D11';var sc=r.st==='Down'?'#A32D2D':'#3B6D11';return '<tr style=\"background:'+(r.h==='CRITICAL'?'#FCEBEB':r.st==='Down'?'#fff0f0':r.h==='WARNING'?'#FAEEDA':'#fff')+'\"><td class=\"m\" style=\"font-weight:500;\">'+r.s.toUpperCase()+'</td><td style=\"font-size:10px;color:#64748b;\">'+r.p+'</td><td class=\"r\">'+r.u+' TB</td><td class=\"r\">'+r.tot+' TB</td><td class=\"r\" style=\"font-weight:600;color:'+hc+';\">'+r.pct+'%</td><td class=\"c\" style=\"color:'+hc+';font-weight:500;\">'+r.h+'</td><td class=\"c\" style=\"color:'+sc+';font-weight:500;\">'+r.st+'</td></tr>';}).join('');document.getElementById('dp-tbody').innerHTML=html;document.getElementById('dp-meta').textContent=data.length+' pools · '+data.filter(r=>r.st==='Down').length+' down · '+data.filter(r=>r.h==='CRITICAL').length+' critical';}"
        "function renderVault(){var html=TS.map(function(r){var dc=r.d<70?'#A32D2D':r.d<80?'#854F0B':'#3B6D11';var pc=r.pend>0?'<span style=\"color:#854F0B;font-weight:600;\">'+r.pend.toLocaleString()+'</span>':'<span style=\"color:#3B6D11;\">0</span>';return '<tr style=\"background:'+(r.d<70?'#FAEEDA':'#fff')+'\"><td class=\"m\" style=\"font-weight:500;\">'+r.s.toUpperCase()+'</td><td class=\"r\">'+r.tb+' TB</td><td class=\"r\" style=\"font-weight:600;color:'+dc+';\">'+r.d+'%</td><td class=\"r\">'+r.w+'d</td><td class=\"r\">'+pc+'</td><td class=\"c\">'+(r.d>=80?pill('OK','pg'):r.d>=70?pill('LOW DEDUP','pa'):pill('CRITICAL','pr'))+'</td></tr>';}).join('');document.getElementById('ts-tbody').innerHTML=html;}"
        "function renderAirgap(){var html=AG.map(function(r){var sc=r.st==='Not Working'?'#A32D2D':'#3B6D11';return '<tr style=\"background:'+(r.st==='Not Working'?'#FCEBEB':'#fff')+'\"><td class=\"m\" style=\"font-weight:500;\">'+r.s.toUpperCase()+'</td><td class=\"c\" style=\"color:'+sc+';font-weight:500;\">'+r.st+'</td><td class=\"r\" style=\"color:'+(r.img>100?'#A32D2D':'#334155')+';font-weight:'+(r.img>0?'600':'400')+';\">'+r.img.toLocaleString()+'</td><td class=\"c\">'+(r.ra?'<span style=\"color:#3B6D11;font-weight:600;\">Active</span>':'<span style=\"color:#94a3b8;\">Idle</span>')+'</td><td class=\"c\">'+ck(r.wk)+'</td><td class=\"c\">'+ck(r.mo)+'</td><td class=\"c\">'+ck(r.yr)+'</td></tr>';}).join('');document.getElementById('ag-tbody').innerHTML=html;}"
        "function renderCatalog(){var html=CAT.map(function(r){var sc=r.sc>=80?'#3B6D11':r.sc>=60?'#854F0B':'#A32D2D';return '<tr style=\"background:'+(r.st==='ERROR'?'#FCEBEB':'#fff')+'\"><td class=\"m\" style=\"font-weight:500;\">'+r.s.toUpperCase()+'</td><td class=\"c\">'+sp(r.st)+'</td><td class=\"r\" style=\"font-weight:600;color:'+sc+';\">'+r.sc+'/100</td><td style=\"font-size:10px;color:#64748b;\">'+(r.reason||'—')+'</td></tr>';}).join('');document.getElementById('cat-tbody').innerHTML=html;}"
        "function renderBJ(){var filt=document.getElementById('bj-filter').value;var data=BJ.filter(r=>filt==='all'||r.sch.toLowerCase().includes(filt));var html=data.map(function(r){var rc=r.rate>=95?'#3B6D11':r.rate>=80?'#854F0B':'#A32D2D';var fc=r.fail>0?'<span style=\"color:#A32D2D;font-weight:600;\">'+r.fail.toLocaleString()+'</span>':'<span style=\"color:#3B6D11;\">0</span>';var st=r.rate>=95?pill('OK','pg'):r.rate>=80?pill('WARNING','pa'):pill('FAILED','pr');return '<tr style=\"background:'+(r.fail>100?'#FCEBEB':r.fail>0?'#FAEEDA':'#fff')+'\"><td class=\"m\" style=\"font-weight:500;\">'+r.s.toUpperCase()+'</td><td>'+r.sch+'</td><td class=\"r\">'+r.tot.toLocaleString()+'</td><td class=\"r\" style=\"color:#3B6D11;\">'+r.ok.toLocaleString()+'</td><td class=\"r\">'+fc+'</td><td class=\"r\" style=\"font-weight:600;color:'+rc+';\">'+r.rate+'%</td><td class=\"c\">'+st+'</td></tr>';}).join('');document.getElementById('bj-tbody').innerHTML=html;}"
        "function renderAlerts(){var alerts=[];var lt=LAG.reduce((a,r)=>a+r.t,0);var agd=AG.filter(r=>r.st==='Not Working');var dpd=DP.filter(r=>r.st==='Down');var dpc=DP.filter(r=>r.h==='CRITICAL');var cte=CAT.filter(r=>r.st==='ERROR');if(agd.length>0)alerts.push({sev:'CRITICAL',c:'#A32D2D',bg:'#FCEBEB',title:'Fix internal airgap — '+agd.length+' server(s) not working',sub:'Affected: '+agd.map(r=>r.s.toUpperCase()).join(', '),steps:['Run nbstlutil on each server','Check SLP and air-gap connectivity']});if(dpd.length>0)alerts.push({sev:'CRITICAL',c:'#A32D2D',bg:'#FCEBEB',title:'Recover '+dpd.length+' Down storage pool(s)',sub:'Backup jobs will fail silently on Down pools',steps:['nbdevquery -listdp','Redirect policies to healthy pools','Check media server connectivity']});if(lt>50000)alerts.push({sev:'CRITICAL',c:'#A32D2D',bg:'#FCEBEB',title:'Dup backlog critical — '+lt.toLocaleString()+' images',sub:'Top: '+LAG[0].s.toUpperCase()+' '+LAG[0].t.toLocaleString()+' images',steps:['Fix pools/airgap — queue reduces automatically','Check STU throughput']});if(dpc.length>0)alerts.push({sev:'CRITICAL',c:'#A32D2D',bg:'#FCEBEB',title:dpc.length+' pool(s) at CRITICAL capacity',sub:'Above 85% — backup jobs may fail',steps:['Expand pool or add disk units','Expire images via bpexpdate']});if(cte.length>0)alerts.push({sev:'WARNING',c:'#854F0B',bg:'#FAEEDA',title:'Catalog error on '+cte.length+' server(s)',sub:'Affected: '+cte.map(r=>r.s.toUpperCase()).join(', '),steps:['Check catalog backup policy','Verify disk space on destination']});if(!alerts.length){document.getElementById('alerts-body').innerHTML='<div style=\"padding:20px;color:#3B6D11;font-weight:500;\">✅ No critical action items — fleet healthy.</div>';return;}var html=alerts.map(function(a,i){var sl=a.steps.map(s=>'<li style=\"margin:3px 0;font-size:11px;color:#475569;\">'+s+'</li>').join('');return '<div class=\"ar\"><div class=\"an\" style=\"background:'+a.bg+';color:'+a.c+';\">'+(i+1)+'</div><div style=\"flex:1;\"><div class=\"at\"><span class=\"badge\" style=\"background:'+a.bg+';color:'+a.c+';\">'+a.sev+'</span>'+a.title+'</div><div class=\"as\">'+a.sub+'</div><ul style=\"margin:6px 0 0 16px;padding:0;\">'+sl+'</ul></div></div>';}).join('');document.getElementById('alerts-body').innerHTML=html;}"
        "function exportTableCSV(tbodyId,filename){var rows=[];var tb=document.getElementById(tbodyId);if(!tb)return;tb.querySelectorAll('tr').forEach(function(tr){rows.push(Array.from(tr.querySelectorAll('td')).map(td=>'\"'+td.innerText.replace(/\"/g,'\"\"')+'\"').join(','));});var a=document.createElement('a');a.href='data:text/csv;charset=utf-8,'+encodeURIComponent(rows.join('\\n'));a.download=filename;a.click();}"
        "function exportCSV(){var a=document.querySelector('.section.active');if(!a)return;var tb=a.querySelector('tbody');if(tb)exportTableCSV(tb.id,'nbu_report.csv');}"
        "function printSection(id){var c=document.getElementById(id).innerHTML;var w=window.open('','_blank');w.document.write('<html><head><title>NBU Report</title><style>body{font-family:system-ui;font-size:12px;}table{width:100%;border-collapse:collapse;}th,td{padding:6px 10px;border:1px solid #e2e8f0;font-size:11px;}th{background:#f8fafc;font-weight:600;}.pill{padding:2px 6px;border-radius:4px;font-size:10px;}</style></head><body>'+c+'</body></html>');w.document.close();w.focus();w.print();}"
        "function renderAll(){renderOverview();renderLag();renderPools();renderVault();renderAirgap();renderCatalog();renderBJ();renderAlerts();drawChart('lag-chart',LT,'#4A90D9');drawChart('rv-chart',RT,'#185FA5');}"
        "renderAll();"
        "</script></body></html>"
    )

    return html.Div([
        html.Iframe(
            srcDoc=_h,
            style={"width":"100%","border":"none","height":"2800px","display":"block"}
        )
    ], style={"padding":"0"})


# ── SLP Monitor tab ───────────────────────────────────────────────────────────
def tab_slp():
    """SLP Monitor — expandable server cards with individual SLP control."""
    import sqlite3 as _sq, json as _js

    try:
        con = _sq.connect(DB_UNIFIED)
        latest = con.execute("SELECT MAX(checked_at) FROM slp_status").fetchone()[0] or "—"
        summary = con.execute("""
            SELECT s.server_name, s.active_slps, s.inactive_slps, s.total_copies,
                   ROUND(s.total_size_mb/1048576.0,1) as size_tb,
                   s.not_started_copies, s.in_process_copies, s.ssh_status
            FROM slp_status s
            INNER JOIN (
                SELECT server_name, MAX(checked_at) as mc
                FROM slp_status GROUP BY server_name
            ) latest ON s.server_name=latest.server_name
                     AND s.checked_at=latest.mc
            ORDER BY s.inactive_slps DESC, s.active_slps DESC
        """).fetchall()
        inactive_detail = con.execute("""
            SELECT d.server_name, d.slp_name, d.copies,
                   ROUND(d.size_mb/1024.0,1) as size_gb
            FROM slp_detail d
            INNER JOIN (
                SELECT server_name, MAX(checked_at) as mc
                FROM slp_detail GROUP BY server_name
            ) dl ON d.server_name=dl.server_name AND d.checked_at=dl.mc
            INNER JOIN (
                SELECT server_name, MAX(checked_at) as mc, inactive_slps
                FROM slp_status GROUP BY server_name
            ) ss ON d.server_name=ss.server_name
            WHERE d.state='inactive'
            AND ss.inactive_slps > 0
            ORDER BY d.server_name, d.copies DESC
        """).fetchall()
        con.close()
    except Exception as e:
        return html.Div(f"SLP data error: {e}",
                        style={"padding":"20px","color":"#E24B4A"})

    inact_map = {}
    for r in inactive_detail:
        if r[0] not in inact_map: inact_map[r[0]] = []
        inact_map[r[0]].append({"name":r[1],"copies":r[2] or 0,"gb":float(r[3] or 0)})

    total_inactive = sum(r[2] or 0 for r in summary)
    total_active   = sum(r[1] or 0 for r in summary)
    total_copies   = sum(r[3] or 0 for r in summary)
    servers_warn   = sum(1 for r in summary if (r[2] or 0) > 0)
    warn_bc = "#E24B4A" if total_inactive > 0 else "#639922"
    warn_c  = "#A32D2D" if total_inactive > 0 else "#3B6D11"

    cards_data = []
    for r in summary:
        cards_data.append({
            "full": r[0],
            "short": r[0].replace("cbkms","").upper(),
            "act":   r[1] or 0,
            "inact": r[2] or 0,
            "copies":r[3] or 0,
            "tb":    float(r[4] or 0),
            "ns":    r[5] or 0,
            "ip":    r[6] or 0,
            "ssh":   r[7] or "OK",
            "slps":  inact_map.get(r[0],[])
        })
    cards_j = _js.dumps(cards_data)

    alert_html = ""
    if total_inactive > 0:
        names = ", ".join(
            f"{r[0].replace('cbkms','').upper()}({r[2]})"
            for r in inactive_detail[:5]
        )
        alert_html = (
            "<div class='ab'>"
            "<span style='font-size:18px;'>&#9888;</span>"
            "<div><div style='font-size:13px;font-weight:600;color:#A32D2D;'>"
            + str(total_inactive) +
            " Inactive SLP(s) with pending work across " +
            str(servers_warn) + " server(s)</div>"
            "<div style='font-size:11px;color:#854F0B;margin-top:2px;'>"
            + names + "</div></div></div>"
        )

    kpi_html = (
        "<div class='kg' style='grid-template-columns:repeat(5,1fr);'>"
        "<div class='kpi' style='border-left:3px solid " + warn_bc + ";'>"
        "<div class='kv' style='color:" + warn_c + ";'>" + str(total_inactive) + "</div>"
        "<div class='kl'>Inactive SLPs</div>"
        "<div class='ks' style='color:" + warn_c + ";'>" + ("needs action" if total_inactive>0 else "all active") + "</div></div>"
        "<div class='kpi' style='border-left:3px solid #639922;'>"
        "<div class='kv' style='color:#3B6D11;'>" + str(total_active) + "</div>"
        "<div class='kl'>Active SLPs</div>"
        "<div class='ks' style='color:#64748b;'>across 14 servers</div></div>"
        "<div class='kpi' style='border-left:3px solid #185FA5;'>"
        "<div class='kv'>" + f"{total_copies:,}" + "</div>"
        "<div class='kl'>Total copies</div>"
        "<div class='ks' style='color:#64748b;'>pending processing</div></div>"
        "<div class='kpi' style='border-left:3px solid " + warn_bc + ";'>"
        "<div class='kv' style='color:" + warn_c + ";'>" + str(servers_warn) + "</div>"
        "<div class='kl'>Servers with issues</div>"
        "<div class='ks' style='color:#64748b;'>" + str(14-servers_warn) + " healthy</div></div>"
        "<div class='kpi' style='border-left:3px solid #185FA5;'>"
        "<div class='kv' style='font-size:14px;'>" + latest[:10] + "</div>"
        "<div class='kl'>Last checked</div>"
        "<div class='ks' style='color:#64748b;'>every 8h via cron</div></div>"
        "</div>"
    )

    _h = (
        "<!DOCTYPE html><html><head><meta charset='utf-8'><style>"
        "*{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,-apple-system,sans-serif;}"
        "body{background:#f0f2f7;color:#1e293b;padding:16px 20px;font-size:13px;}"
        ".kg{display:grid;gap:10px;margin-bottom:14px;}"
        ".kpi{background:#fff;border:0.5px solid #e2e8f0;border-radius:10px;padding:12px 14px;}"
        ".kv{font-size:22px;font-weight:600;line-height:1;}"
        ".kl{font-size:10px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.4px;margin:4px 0 3px;}"
        ".ks{font-size:11px;font-weight:500;}"
        ".card{background:#fff;border:0.5px solid #e2e8f0;border-radius:10px;overflow:hidden;margin-bottom:8px;}"
        ".ch{padding:10px 16px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;user-select:none;}"
        ".ch:hover{background:#fafafa;}"
        ".cb{display:none;border-top:0.5px solid #f1f5f9;}"
        ".cb.open{display:block;}"
        ".metrics{display:grid;grid-template-columns:repeat(5,1fr);background:#f8fafc;border-bottom:0.5px solid #f1f5f9;}"
        ".met{padding:8px 12px;text-align:center;border-right:0.5px solid #f1f5f9;}"
        ".met:last-child{border-right:none;}"
        ".mv{font-size:16px;font-weight:600;line-height:1;}"
        ".ml{font-size:9px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.3px;margin-top:3px;}"
        ".tw{overflow-x:auto;}"
        "table{width:100%;border-collapse:collapse;font-size:11px;}"
        "th{padding:6px 12px;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;font-weight:500;color:#64748b;background:#f8fafc;border-bottom:0.5px solid #e2e8f0;}"
        "th.r{text-align:right;}th.c{text-align:center;}"
        "td{padding:7px 12px;border-bottom:0.5px solid #f8fafc;}"
        "td.r{text-align:right;}td.c{text-align:center;}"
        "tr:last-child td{border-bottom:none;}tr:hover td{background:#fafafa;}"
        ".pill{display:inline-block;font-size:10px;font-weight:500;padding:2px 8px;border-radius:20px;}"
        ".pr{background:#FCEBEB;color:#A32D2D;}.pg{background:#EAF3DE;color:#3B6D11;}"
        ".btn{padding:4px 10px;border-radius:6px;border:none;font-size:10px;font-weight:500;cursor:pointer;margin:1px;}"
        ".ba{background:#EAF3DE;color:#3B6D11;}.bi{background:#FCEBEB;color:#A32D2D;}"
        ".bs{padding:3px 8px;font-size:9px;}"
        ".eb{background:none;border:none;cursor:pointer;font-size:12px;color:#64748b;padding:4px 8px;border-radius:4px;}"
        ".eb:hover{background:#f1f5f9;}"
        ".ab{background:#FCEBEB;border:0.5px solid #E24B4A;border-radius:10px;padding:12px 16px;margin-bottom:14px;display:flex;align-items:center;gap:10px;}"
        ".tbtn{padding:5px 12px;border-radius:6px;border:0.5px solid #e2e8f0;background:#fff;color:#475569;font-size:11px;cursor:pointer;font-weight:500;}"
        "#toast{position:fixed;top:16px;right:16px;padding:10px 16px;border-radius:8px;font-size:12px;font-weight:500;display:none;z-index:999;color:#fff;}"
        "</style></head><body>"
        "<div style='display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;'>"
        "<div><div style='font-size:15px;font-weight:600;'>SLP Monitor</div>"
        "<div style='font-size:11px;color:#94a3b8;margin-top:2px;'>Last sync: " + latest + " | 14 masters | syncs every 8h</div></div>"
        "<div style='display:flex;gap:8px;'>"
        "<button class='tbtn' onclick='expandAll()'>&#9660; Expand all</button>"
        "<button class='tbtn' onclick='collapseAll()'>&#9650; Collapse all</button>"
        "<button class='tbtn' onclick='emailStatus(event)'>&#128231; Email Status</button>"
        "<button class='tbtn' onclick='window.print()'>&#128438; Print/PDF</button>"
        "</div></div>"
        + alert_html + kpi_html +
        "<div style='font-size:13px;font-weight:500;margin-bottom:8px;'>Master server SLP status — click row to expand</div>"
        "<div id='cards'></div>"
        "<div id='toast'></div>"
        "<script>"
        "var C=" + cards_j + ";"
        "function toast(m,ok){var t=document.getElementById('toast');t.textContent=m;t.style.background=ok?'#1A5C2A':'#A32D2D';t.style.display='block';setTimeout(function(){t.style.display='none';},4000);}"
        "function act(srv,slp,action,btn,msg){var o=btn.textContent;btn.disabled=true;btn.textContent='...';fetch('/slp-action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({server:srv,slp:slp,action:action})}).then(function(r){return r.json();}).then(function(d){if(d.ok){toast(msg,true);setTimeout(function(){location.reload();},2000);}else{btn.disabled=false;btn.textContent=o;toast('Error: '+d.error,false);}}).catch(function(){btn.disabled=false;btn.textContent=o;toast('Network error',false);});}"
        "function mkCard(c,i){var bc=c.inact>0?'#E24B4A':'#639922';var sp=c.inact>0?'<span class=\"pill pr\">'+c.inact+' INACTIVE</span>':'<span class=\"pill pg\">ALL ACTIVE</span>';var tot=c.act+c.inact;var sr='';if(c.slps&&c.slps.length>0){sr='<div class=\"tw\"><table><thead><tr><th>SLP Name</th><th class=\"r\">Copies</th><th class=\"r\">Size GB</th><th class=\"c\">State</th><th class=\"c\">Action</th></tr></thead><tbody>';c.slps.forEach(function(s){var sn=s.name.replace(/'/g,\"\\\\'\");sr+='<tr style=\"background:#FCEBEB;\"><td style=\"font-size:11px;\">'+s.name+'</td><td class=\"r\" style=\"color:#A32D2D;font-weight:600;\">'+s.copies.toLocaleString()+'</td><td class=\"r\">'+s.gb.toFixed(1)+' GB</td><td class=\"c\"><span class=\"pill pr\">INACTIVE</span></td><td class=\"c\"><button class=\"btn ba bs\" onclick=\"act(\\''+c.full+'\\',\\''+sn+'\\',\\'active\\',this,\\'Activated\\');\">&#9654; Activate</button></td></tr>';});sr+='</tbody></table></div>';}else if(c.inact>0){sr='<div style=\"padding:12px 16px;font-size:11px;color:#94a3b8;\">Names load after next sync</div>';}else{sr='<div style=\"padding:12px 16px;font-size:11px;color:#3B6D11;\">&#10003; All '+tot+' SLPs active</div>';}return'<div class=\"card\" id=\"card-'+i+'\" style=\"border-left:3px solid '+bc+'\"><div class=\"ch\" onclick=\"tog('+i+')\"><div style=\"display:flex;align-items:center;gap:10px;\"><span style=\"font-size:13px;font-weight:500;\">'+c.short+'</span><span style=\"font-size:10px;color:#94a3b8;\">'+c.full+'</span>'+sp+'</div><div style=\"display:flex;align-items:center;gap:6px;\"><span style=\"font-size:11px;color:#64748b;\">'+tot+' SLPs · '+c.copies.toLocaleString()+' copies</span><button class=\"btn bi bs\" onclick=\"event.stopPropagation();if(confirm(\\'Stop ALL SLPs on '+c.short+'?\\'))act(\\''+c.full+'\\',\\'__ALL__\\',\\'inactive\\',this,\\'All stopped\\')\">&#9646;&#9646; Stop</button><button class=\"btn ba bs\" onclick=\"event.stopPropagation();if(confirm(\\'Start ALL SLPs on '+c.short+'?\\'))act(\\''+c.full+'\\',\\'__ALL__\\',\\'active\\',this,\\'All started\\')\">&#9654; Start</button><span class=\"eb\" id=\"e-'+i+'\">&#9660;</span></div></div><div class=\"cb\" id=\"b-'+i+'\"><div class=\"metrics\"><div class=\"met\"><div class=\"mv\" style=\"color:#3B6D11;\">'+c.act+'</div><div class=\"ml\">Active</div></div><div class=\"met\"><div class=\"mv\" style=\"color:'+(c.inact>0?'#A32D2D':'#3B6D11')+';\">'+c.inact+'</div><div class=\"ml\">Inactive</div></div><div class=\"met\"><div class=\"mv\">'+c.copies.toLocaleString()+'</div><div class=\"ml\">Copies</div></div><div class=\"met\"><div class=\"mv\">'+c.ns.toLocaleString()+'</div><div class=\"ml\">Not started</div></div><div class=\"met\"><div class=\"mv\">'+c.ip.toLocaleString()+'</div><div class=\"ml\">In process</div></div></div>'+sr+'</div></div>';}"
        "function tog(i){var b=document.getElementById('b-'+i);var e=document.getElementById('e-'+i);if(b.classList.contains('open')){b.classList.remove('open');e.innerHTML='&#9660;';}else{b.classList.add('open');e.innerHTML='&#9650;';}}"
        "function expandAll(){C.forEach(function(c,i){document.getElementById('b-'+i).classList.add('open');document.getElementById('e-'+i).innerHTML='&#9650;';});}"
        "function collapseAll(){C.forEach(function(c,i){document.getElementById('b-'+i).classList.remove('open');document.getElementById('e-'+i).innerHTML='&#9660;';});}"
        "var h='';C.forEach(function(c,i){h+=mkCard(c,i);});document.getElementById('cards').innerHTML=h;"
        "C.forEach(function(c,i){if(c.inact>0){document.getElementById('b-'+i).classList.add('open');document.getElementById('e-'+i).innerHTML='&#9650;';}});"
        "function emailStatus(ev){var btn=ev.target;var orig=btn.textContent;btn.disabled=true;btn.textContent='Sending...';fetch('/slp-status-email',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).then(function(r){return r.json();}).then(function(d){toast(d.ok?(d.msg||'Email sent!'):'Error: '+d.error,d.ok);btn.disabled=false;btn.textContent=orig;}).catch(function(){toast('Network error',false);btn.disabled=false;btn.textContent=orig;});}"
        "</script></body></html>"
    )

    return html.Div([
        html.Iframe(
            srcDoc=_h,
            style={"width":"100%","border":"none","height":"2200px","display":"block"}
        )
    ], style={"padding":"0"})



def _register_auth_routes(app):
    server = app.server
    server.secret_key = _SECRET_KEY
    from flask import jsonify



    # Patch Dash's _setup_server to not crash on layout=None during pre-request
    import dash._validate as _dv
    _orig_vl = _dv.validate_layout
    def _safe_vl(layout, layout_value):
        try: _orig_vl(layout, layout_value)
        except Exception: pass
    _dv.validate_layout = _safe_vl

    @server.route("/login", methods=["GET","POST"])
    def login():
        ip = _req.remote_addr
        if _req.method == "POST":
            # Rate limit check
            limited, wait = _is_rate_limited(ip)
            if limited:
                _audit("RATE_LIMITED", ip=ip)
                return _login_page(f"Too many failed attempts. Try again in {wait}s.")
            u = _req.form.get("username","").strip()
            p = _req.form.get("password","")
            if _auth_user(u, p):
                _clear_fail(ip)
                token = _create_session(u, ip)
                _sess[_TOKEN_KEY]    = token
                _sess[_SESSION_KEY]  = u
                _sess[_LAST_SEEN_KEY] = __import__("time").time()
                _sess.permanent      = True
                _audit("LOGIN_OK", u, ip)
                return _redir("/")
            else:
                locked = _record_fail(ip)
                _audit("LOGIN_FAIL", u, ip,
                       f"locked={locked}")
                msg = (f"Account locked for {_LOCK_SECS//60} min after too many attempts."
                       if locked else "Invalid username or password.")
                return _login_page(msg)
        if _is_logged_in():
            return _redir("/")
        return _login_page()

    @server.route("/logout")
    def logout():
        token  = _sess.get(_TOKEN_KEY)
        user   = _sess.get(_SESSION_KEY,"unknown")
        reason = _req.args.get("reason","manual")
        _destroy_session(token)
        _sess.clear()
        _audit("LOGOUT", user, _req.remote_addr, f"reason={reason}")
        return _login_page(
            "You have been signed out." if reason=="manual"
            else "Session expired due to inactivity.")

    @server.route("/slp-action", methods=["POST"])
    def slp_action():
        """Activate or inactivate SLP operations via SSH."""
        from flask import request as _req, jsonify as _json
        import subprocess as _sp
        try:
            data    = _req.get_json()
            server  = data.get("server","")
            slp     = data.get("slp","")
            action  = data.get("action","active")
            NBSTL   = "/usr/openv/netbackup/bin/admincmd/nbstlutil"

            if not server or action not in ("active","inactive"):
                return _json({"ok":False,"error":"Invalid parameters"})

            # Security: whitelist servers
            allowed = ["cpcinp1cbkms","cpcinp2cbkms","cpcind1cbkms","cpcind2cbkms",
                       "cazinp1cbkms","cazusp1cbkms","cgcukp1cbkms","cocinp1cbkms",
                       "cpcchp1cbkms","cpcphp1cbkms","cpcfrp1cbkms","cpcgep1cbkms",
                       "cpceup1cbkms","cpcusp1cbkms"]
            if server not in allowed:
                return _json({"ok":False,"error":"Server not allowed"})

            NBSTL = "/usr/openv/netbackup/bin/admincmd/nbstlutil"
            # Sanitize inputs
            safe_srv = server.replace(";","").replace("&","").replace("|","")
            if slp == "__ALL__":
                # Loop through all SLP names and activate/inactivate each
                _sq = "'"
                _cmd = (
                    "/usr/openv/netbackup/bin/admincmd/nbstl 2>/dev/null | "
                    "while read slpname; do "
                    f"  /usr/openv/netbackup/bin/admincmd/nbstlutil {action} "
                    f"  -lifecycle {_sq}$slpname{_sq} -M {safe_srv} 2>/dev/null; "
                    "done; echo DONE"
                )
                ssh_args = ["ssh","-q","-o","ConnectTimeout=30",
                           "-o","StrictHostKeyChecking=no",
                           "-o","BatchMode=yes",
                           safe_srv, _cmd]
            else:
                safe_slp = slp.replace(";","").replace("&","").replace("|","").replace("`","").replace('"',"").replace("'","")
                ssh_args = ["ssh","-q","-o","ConnectTimeout=30",
                           "-o","StrictHostKeyChecking=no",
                           "-o","BatchMode=yes",
                           safe_srv,
                           f"{NBSTL} {action} -lifecycle {safe_slp} -M {safe_srv}"]

            r = _sp.run(ssh_args, stdout=_sp.PIPE, stderr=_sp.PIPE, timeout=60)
            out = r.stdout.decode("utf-8","replace")
            err = r.stderr.decode("utf-8","replace")

            if r.returncode == 0:
                logger.info(f"SLP {action}: server={server} slp={slp} — OK")
                # Trigger immediate re-sync for this server only
                try:
                    import threading as _th, sys as _sys
                    _sys.path.insert(0, '/usr/nbu-cts-v2/scripts')
                    import importlib as _il
                    _sm = _il.import_module('sync_slp')
                    import sqlite3 as _sl3
                    from datetime import datetime as _dt
                    def _resync():
                        try:
                            _con = _sl3.connect('/usr/nbu-cts-v2/db/nbu_unified.db')
                            _now = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
                            _sm.sync_server(server, _con, _now)
                            _con.commit()
                            _con.close()
                            logger.info(f"Re-sync complete for {server} after SLP {action}")
                        except Exception as _re:
                            logger.warning(f"Re-sync failed for {server}: {_re}")
                    _th.Thread(target=_resync, daemon=True).start()
                except Exception as _se:
                    logger.warning(f"Re-sync trigger failed: {_se}")
                return _json({"ok":True,"output":out})
            else:
                logger.warning(f"SLP {action}: server={server} slp={slp} — FAILED: {err}")
                return _json({"ok":False,"error":err[:200] or f"Exit code {r.returncode}"})

        except Exception as e:
            logger.error(f"SLP action error: {e}")
            return _json({"ok":False,"error":str(e)})

    @server.route("/slp-status-email", methods=["POST"])
    def slp_status_email():
        """Send SLP status report email to team."""
        from flask import jsonify as _json
        try:
            import sqlite3 as _sq, sys as _sys3
            from datetime import datetime as _dt3
            _sys3.path.insert(0,'/usr/nbu-cts-v2')
            from nbu_report_mailer import send_report_email as _send_email2
            con = _sq.connect(DB_UNIFIED)
            rows = con.execute("""
                SELECT s.server_name,s.active_slps,s.inactive_slps,
                       s.total_copies,ROUND(s.total_size_mb/1048576.0,1),
                       s.checked_at
                FROM slp_status s
                INNER JOIN (SELECT server_name,MAX(checked_at) mc
                            FROM slp_status GROUP BY server_name) l
                ON s.server_name=l.server_name AND s.checked_at=l.mc
                ORDER BY s.inactive_slps DESC, s.active_slps DESC
            """).fetchall()
            inact = con.execute("""
                SELECT d.server_name,d.slp_name,d.copies
                FROM slp_detail d
                INNER JOIN (SELECT server_name,MAX(checked_at) mc
                            FROM slp_detail GROUP BY server_name) l
                ON d.server_name=l.server_name AND d.checked_at=l.mc
                INNER JOIN (SELECT server_name,inactive_slps FROM slp_status s2
                            WHERE checked_at=(SELECT MAX(checked_at) FROM slp_status s3
                                             WHERE s3.server_name=s2.server_name)) ss
                ON d.server_name=ss.server_name
                WHERE d.state='inactive' AND ss.inactive_slps>0
                ORDER BY d.copies DESC
            """).fetchall()
            con.close()
            now_str = _dt3.now().strftime("%d-%b-%Y %H:%M IST")
            total_inact = sum(r[2] or 0 for r in rows)
            total_act   = sum(r[1] or 0 for r in rows)
            total_cop   = sum(r[3] or 0 for r in rows)
            sc = "#A32D2D" if total_inact>0 else "#3B6D11"
            sb = "#FCEBEB" if total_inact>0 else "#EAF3DE"
            sl = f"{total_inact} INACTIVE SLPs — Action Required" if total_inact>0 else "✓ All SLPs Active"
            srv_rows = ""
            for r in rows:
                ic="#A32D2D" if (r[2] or 0)>0 else "#3B6D11"
                bg="#FCEBEB" if (r[2] or 0)>0 else "#fff"
                st="WARNING" if (r[2] or 0)>0 else "OK"
                stc="#A32D2D" if (r[2] or 0)>0 else "#3B6D11"
                stb="#FCEBEB" if (r[2] or 0)>0 else "#EAF3DE"
                srv_rows += (
                    f"<tr style='background:{bg};border-bottom:1px solid #f1f5f9;'>"
                    f"<td style='padding:8px 12px;font-weight:500;font-family:monospace;font-size:12px;'>{r[0].replace('cbkms','').upper()}</td>"
                    f"<td style='padding:8px 12px;text-align:right;color:#3B6D11;'>{r[1] or 0}</td>"
                    f"<td style='padding:8px 12px;text-align:right;color:{ic};font-weight:{'600' if (r[2] or 0)>0 else '400'};'>{r[2] or 0}</td>"
                    f"<td style='padding:8px 12px;text-align:right;'>{(r[3] or 0):,}</td>"
                    f"<td style='padding:8px 12px;text-align:right;'>{r[4] or 0} TB</td>"
                    f"<td style='padding:8px 12px;text-align:center;'>"
                    f"<span style='background:{stb};color:{stc};font-size:10px;font-weight:600;padding:2px 8px;border-radius:20px;'>{st}</span></td>"
                    f"</tr>"
                )
            inact_html = ""
            if inact:
                ir = "".join(
                    f"<tr style='background:#FCEBEB;border-bottom:1px solid #fecaca;'>"
                    f"<td style='padding:7px 12px;font-weight:500;font-size:12px;'>{r[0].replace('cbkms','').upper()}</td>"
                    f"<td style='padding:7px 12px;font-size:11px;'>{r[1]}</td>"
                    f"<td style='padding:7px 12px;text-align:right;color:#A32D2D;font-weight:600;'>{(r[2] or 0):,}</td>"
                    f"</tr>"
                    for r in inact
                )
                inact_html = (
                    f"<div style='margin-top:20px;'>"
                    f"<div style='font-size:13px;font-weight:600;color:#A32D2D;margin-bottom:8px;'>⚠ Inactive SLPs requiring attention</div>"
                    f"<table style='width:100%;border-collapse:collapse;font-size:12px;'>"
                    f"<thead><tr style='background:#FCEBEB;'>"
                    f"<th style='padding:7px 12px;text-align:left;font-size:10px;text-transform:uppercase;color:#A32D2D;'>Server</th>"
                    f"<th style='padding:7px 12px;text-align:left;font-size:10px;text-transform:uppercase;color:#A32D2D;'>SLP Name</th>"
                    f"<th style='padding:7px 12px;text-align:right;font-size:10px;text-transform:uppercase;color:#A32D2D;'>Copies</th>"
                    f"</tr></thead><tbody>{ir}</tbody></table></div>"
                )
            html = (
                f"<div style='font-family:system-ui,-apple-system,sans-serif;max-width:700px;margin:0 auto;'>"
                f"<div style='background:#1A3C5E;padding:20px 24px;border-radius:10px 10px 0 0;'>"
                f"<div style='color:#fff;font-size:16px;font-weight:600;'>NBU Backup CTS — SLP Status Report</div>"
                f"<div style='color:#94a3b8;font-size:12px;margin-top:4px;'>{now_str} · 14 master servers</div>"
                f"</div>"
                f"<div style='background:#fff;border:1px solid #e2e8f0;padding:24px;border-radius:0 0 10px 10px;'>"
                f"<div style='background:{sb};border-left:4px solid {sc};padding:12px 16px;border-radius:6px;margin-bottom:20px;'>"
                f"<div style='font-size:14px;font-weight:600;color:{sc};'>{sl}</div>"
                f"<div style='font-size:12px;color:#475569;margin-top:2px;'>{total_act} active SLPs · {total_cop:,} total copies pending</div>"
                f"</div>"
                f"<table style='width:100%;border-collapse:collapse;font-size:12px;margin-bottom:8px;'>"
                f"<thead><tr style='background:#f8fafc;'>"
                f"<th style='padding:8px 12px;text-align:left;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;color:#64748b;'>Server</th>"
                f"<th style='padding:8px 12px;text-align:right;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;color:#64748b;'>Active</th>"
                f"<th style='padding:8px 12px;text-align:right;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;color:#64748b;'>Inactive</th>"
                f"<th style='padding:8px 12px;text-align:right;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;color:#64748b;'>Copies</th>"
                f"<th style='padding:8px 12px;text-align:right;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;color:#64748b;'>Size</th>"
                f"<th style='padding:8px 12px;text-align:center;font-size:10px;text-transform:uppercase;letter-spacing:0.4px;color:#64748b;'>Status</th>"
                f"</tr></thead><tbody>{srv_rows}</tbody></table>"
                f"{inact_html}"
                f"<div style='margin-top:20px;padding:12px 16px;background:#f8fafc;border-radius:6px;font-size:11px;color:#94a3b8;'>"
                f"Generated by NBU Backup CTS Dashboard · "
                f"<a href='https://CPCINCHPV186736.cts.com:8060' style='color:#185FA5;'>Open dashboard</a>"
                f"</div></div></div>"
            )
            recipients = open('/usr/nbu-cts-v2/scripts/digest_recipients.txt').read().strip().splitlines()
            subj = f"[NBU-CTS] SLP Status — {now_str} — {'⚠ '+str(total_inact)+' Inactive' if total_inact>0 else '✓ All Active'}"
            _send_email2(recipients, subj, html)
            logger.info(f"SLP status email sent to {recipients}")
            return _json({"ok":True,"msg":f"Email sent to {', '.join(recipients)}"})
        except Exception as e:
            logger.error(f"SLP status email error: {e}")
            return _json({"ok":False,"error":str(e)})

    @server.route("/heartbeat", methods=["POST"])
    def heartbeat():
        try:
            token = _sess.get(_TOKEN_KEY)
            user  = _validate_session(token)
            if user:
                return jsonify({"ok":True,"user":user})
            return jsonify({"ok":False,"redirect":"/logout?reason=idle"}), 401
        except Exception as _he:
            return jsonify({"ok":False,"error":str(_he)}), 500

    @server.before_request
    def _guard():
        p = _req.path
        free = ("/login","/logout","/heartbeat",
                "/_dash-component-suites","/assets","/_favicon",
                "/slp-action","/slp-status-email")
        if any(p.startswith(x) for x in free):
            return None
        if not _is_logged_in():
            if p.startswith("/_dash"):
                return jsonify({"error":"unauthorized","redirect":"/login"}), 401
            return _redir("/login")
        return None

    # Move _guard to front of before_request chain
    # so it runs before Dash's _setup_server validate_layout
    funcs = server.before_request_funcs.get(None, [])
    if funcs:
        guard_fn = funcs[-1]
        funcs.remove(guard_fn)
        funcs.insert(0, guard_fn)
        server.before_request_funcs[None] = funcs

_register_auth_routes(app)

# ── SSL setup ─────────────────────────────────────────────────────────────
SSL_CERT = "/usr/nbu-cts-v2/ssl/cert.pem"
SSL_KEY  = "/usr/nbu-cts-v2/ssl/key.pem"
try:
    import ssl as _ssl
    ctx_ssl = _ssl.SSLContext(_ssl.PROTOCOL_TLS_SERVER)
    ctx_ssl.load_cert_chain(SSL_CERT, SSL_KEY)
    ssl_args = {"ssl_context": ctx_ssl}
    logger.info(f"HTTPS enabled ({SSL_CERT})")
except Exception as _e:
    logger.warning(f"SSL skipped: {_e} — running HTTP")
    ssl_args = {}

app.run(host="0.0.0.0",port=PORT,debug=False,
         threaded=True,**ssl_args)


